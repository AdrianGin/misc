/* $Id: port563.c,v 1.22 1996/06/02 21:47:02 rich Exp $ */
#include "simcom.h"
#include "simdev.h"
#include "simusr.h"
#include "protocom.h"
#include "gsig563.h"

/* I don't much care whether these are defined in sys/types.h--LAW */
#define u_char unsigned char
#define u_int unsigned int
#define u_short unsigned short
#define u_long unsigned long

#define		PERIPH_NUM		(hsppd - &dv_var->periph[0])


extern struct dev_var *dv_var;
extern struct dt_var *dx_var;

#if FULLSIM
extern struct sev_var *sv_var;
extern struct st_var *sx_var;

static iorval (char *buf, struct sev_iolist *iop);
static int iopval (int periph, struct sev_evres *iod);

#endif

#if !ADSx
static u_long *hspr;	/* points to register values */
static struct dev_periph *hsppd;	/* points to current peripheral */
#endif /* !ADSx */
static struct dt_mperiph *hsppdt;	/* points to current peripheral type */

#if ADSx
static int hspmread (int periph, int regnum, unsigned long *retv);
static int hspmwrite (int regnum, int periph, unsigned long *regv);
#else
static int hspmread_b (int periph, int regn, u_long *retv);
static int hspmread_b302 (int periph, int regn, u_long *retv);
static int hspmwrite_b (int regn, int periph, u_long *regv);
static int hspmwrite_b302 (int regn, int periph, u_long *regv);
static int hspmread_c (int periph, int regn, u_long *retv);
static int hspmwrite_c (int regn, int periph, u_long *regv);
static void hspmcycle (int periph);
static int hspmsmwrite_b (int periph, u_long addr, u_long regv, int se);
static int hspmsmwrite_b302 (int periph, u_long addr, u_long regv, int se);
static int hspmsmwrite_c (int periph, u_long addr, u_long regv, int se);
static void hspmsmread_b (int periph, u_long addr, u_long *regv, int se);
static void hspmsmread_b302 (int periph, u_long addr, u_long *regv, int se);
static void hspmsmread_c (int periph, u_long addr, u_long *regv, int se);
static void hspmreset_b (int periph, int rstflag, int mode);
static void hspmreset_b302 (int periph, int rstflag, int mode);
static void hspmreset_c (int periph, int rstflag, int mode);

static int start_hspmsm (int periph);
static int reg_wf (int regn);
static int sm_read_b (int periph, int regn, u_long *regv, int se);
static int sm_write_b (int periph, int regn, u_long regv);
static int sm_read_b302 (int periph, int regn, u_long *regv, int se);
static int sm_write_b302 (int periph, int regn, u_long regv);
static int sm_read_c (int periph, int regn, u_long *regv, int se);
static int sm_write_c (int periph, int regn, u_long regv);
static int ex_reset_b ();
static int ex_reset_b302 ();
static int ex_reset_c ();
#endif /* ADSx */

#define NORM_FIELD(i)        ( (i) ? ((i)^((i) - 1))&(i) : 1 )

#define NOT_USED 0

/*
 * portb memory mapped registers offsets from the base address M_DCTR
 */
enum portb_registers_offsets
{
    OFF_DATH = M_DATH_563 - M_DCTR_563,
    OFF_DCTR = M_DCTR_563 - M_DCTR_563,
    OFF_DIRH = M_DIRH_563 - M_DCTR_563,
    OFF_PORTB_LAST
};

/*
 * portb of 56302/303 memory mapped registers offsets 
 * from the base address M_HCR_56302
 */
enum portb302_registers_offsets
{
    OFF_HDR = M_HDR_56302 - M_HCR_56302,
    OFF_HPCR = M_HPCR_56302 - M_HCR_56302,
    OFF_HDDR = M_HDDR_56302 - M_HCR_56302,
    OFF_PORTB302_LAST
};

/*
 * portc memory mapped registers offsets from the base address M_PCD
 */
enum portc_d_e_registers_offsets
{
    OFF_PORT_CONTROL = M_PCRC_563 - M_PDRC_563,
    OFF_PORT_DDR = M_PRRC_563 - M_PDRC_563,
    OFF_PORT_DATA = M_PDRC_563 - M_PDRC_563,
    OFF_PORTCDE_LAST
};

/*
 * Port_B registers. viewed to the user
 */
enum _portb_registers
{
    MR_DIRH,
    MR_DATH,
    MR_DCTR_PORT_CONTROL,
    HPORTBMAX			/* MAX NUMBER OF PORTB REGISTERS */
};

/*
 * Port_B of 56302/303 registers. viewed to the user
 */
enum _portb302_registers
{
    MR_HDDR,
    MR_HDR,
    MR_HPCR,
    HPORTB302MAX                   /* MAX NUMBER OF PORTB REGISTERS */
};

enum _portc_d_e_register_mapping
{
    MR_PORT_CONTROL,
    MR_PORT_DDR,
    MR_PORT_DATA,
    HPORTMAX
};

/*
 * Port_C registers. viewed to the user
 */
enum _portc_registers
{
    MR_PCRC,
    MR_PRRC,
    MR_PDRC,
    HPORTCMAX			/* MAX NUMBER OF PORTC REGISTERS */
};

/*
 * Port_D registers. viewed to the user
 */
enum _portd_registers
{
    MR_PCRD,
    MR_PRRD,
    MR_PDRD,
    HPORTDMAX			/* MAX NUMBER OF PORTD REGISTERS */
};

/*
 * Port_E registers. viewed to the user
 */
enum _porte_registers
{
    MR_PCRE,
    MR_PRRE,
    MR_PDRE,
    HPORTEMAX			/* MAX NUMBER OF PORTE REGISTERS */
};

/*
 * portb data structure
 */
struct portb_registers
{
    u_long
     MR_DIRH,
     MR_DATH,
     MR_DCTR_PORT_CONTROL,
     HPORTBMAX;
};

/*
 * portb of 56302/303 data structure
 */
struct portb302_registers
{
    u_long
    MR_HDDR,
    MR_HDR,
    MR_HPCR,
    HPORTB302MAX;
};


/*
 * portc data structure
 */
struct portc_registers
{
    u_long
     MR_PCRC,
     MR_PRRC,
     MR_PDRC,
     HPORTCMAX;
};

/*
 * portd data structure
 */
struct portd_registers
{
    u_long
     MR_PCRD,
     MR_PRRD,
     MR_PDRD,
     HPORTDMAX;
};

/*
 * porte data structure
 */
struct porte_registers
{
    u_long
     MR_PCRE,
     MR_PRRE,
     MR_PDRE,
     HPORTEMAX;
};

#if FULLSIM
#if !ADSx
static u_long *hspdf;	/* points to display flags */
static struct sev_periph *hspps;	/* points to current peripheral */
static struct st_periph *hsppst;	/* points to current peripheral type */
#endif /* !ADSx */

static struct st_disp
 dispf_b[] =
{				/* regxr,field width,position of = from left */
    {MR_DIRH, 32, 22},
    {MR_DATH, 15, 5},
    {-2, 0, 0}
};

static struct st_disp
dispf_b302[] =
{                          /* regxr,field width,position of = from left */
    {MR_HDDR, 11, 5},
    {MR_HDR, 11, 5},
    {MR_HPCR, 11, 5},
    {-2, 0, 0}
};


static struct st_disp
 dispf_c[] =
{				/* regxr,field width,position of = from left */
    {MR_PORT_CONTROL, 15, 5},
    {MR_PORT_DDR, 17, 7},
    {MR_PORT_DATA, 15, 5},
    {-2, 0, 0}
};

#endif

#if FULLSIM
static int 
iorval (buf, iop)
char *buf;
struct sev_iolist *iop;

{
    siml_scanradix (buf, iop, 0);
    return (1);
}

static int
iopval (periph, iod)		/* process a previously read  data value for timed input */
int periph;
struct sev_evres *iod;
{

    u_long portmask,
     portmask2;
    u_long xval,
     xval2;
    struct dev_xpdata *xpv,
    *xpv2;

    hsppdt = &dx_var->mperiph[periph];

    xpv = &dv_var->xportval[hsppdt->periphid.portindex].pc;
    xpv2 = &dv_var->xportval[hsppdt->periphid.portindex2].pc;

    portmask = hsppdt->periphid.portmask;
    portmask2 = hsppdt->periphid.portmask2;

    xval = iod->xval[0] & portmask;
    xval2 = (iod->xval[0] / NORM_FIELD (~(portmask))) & portmask2;

    xpv->ind &= ~portmask;
    xpv->ind |= xval & portmask;
#if !BLM
    xpv->inf = portmask;
#endif

    xpv2->ind &= ~portmask2;
    xpv2->ind |= xval2 & portmask2;
#if !BLM
    xpv2->inf = portmask2;
#endif
    return 0;
}

static char
*portio_hlp[] =
{
    "The DSP56300 port data value may be represented in hexadecimal,",
    "binary, decimal or floating point. The default input radix can be",
    "specified in the input command. Floating point input may be ",
    "expressed in the usual methods. For example, 0.5, 5e-1, and 5.0E-",
    "1 are all acceptable data input values. If a data value contains",
    "a decimal point, the data will be input as a floating point value,",
    "overriding the input radix specification. Likewise, a data value",
    "preceded by $ will always be input as hexadecimal, a value preceded",
    "by % will be input as binary, and a value preceded by ` will always",
    "be input as decimal.",
    "",
    "Untimed port input data values will be applied only if the port is",
    "configured as an input and the device performs a read operation on",
    "the port. In other words, the input file acts like a stack of input",
    "data; each successive data value is retrieved from the \"stack\" file",
    "when a read operation occurs.",
    "",
    "Timed port input data values are applied to the port at the",
    "specified relative time intervals (+time), or at the exact simulator",
    "cycle indicated by the timing information within the file. If the",
    "first timing information in the file is a relative value (+time)",
    "the simulator will wait until the first port read before applying",
    "the data value. Otherwise the data application occurs at the exact",
    "specified cycle.",
    "",
    "If a lower case letter t is placed in a data position of the input",
    "file, the user will be prompted for the next input data value.",
    "At the prompt the user may enter a new data value or just enter",
    "return to repeat the previous data value. Typing the escape key at",
    "the prompt simulates an end-of-file status.",
    "",
    "Storage of data to a port output file will occur any time a write",
    "operation occurs to the port. In the timed output mode, the ",
    "simulator cycle count and a data value are stored each time a word is",
    "written. In the untimed output mode, a single data value is stored",
    "each time a word is written. No tristate information is available",
    "in this simplified port output mode. Data bits associated with",
    "Port pins which are tristated or which have peripheral functions",
    "enabled will be represented by a zero.",
    "",
    "EXAMPLES",
    "",
    "The following untimed input file will cause the data sequence FFFF",
    "FF3F FD3C FFC3 to appear on Port B during consecutive port reads.",
    "",
    "FFFF FF3F FD3C FFC3",
    "",
    "The following untimed input file will cause the data sequence 7F",
    "00 to appear repeatedly on consecutive reads of Port C.",
    "",
    "(7F 00)",
    "",
    "The following timed input file will cause the data sequence 1555",
    "3333 to alternate on Port B at 10 cycle intervals.",
    "",
    "(+10 1555 +10 3333)",

    NULL
};

static
struct st_help_topic hlp_topics[] =
{
    {"portio", portio_hlp, "I/O file format for portb portc portd and porte", NULL},
};

static
struct st_help per_hlp =
{
    sizeof (hlp_topics) / sizeof (struct st_help_topic),	/* number of periphs */
    hlp_topics
};

public
struct st_periph sx_portb_563 =
{
  /* 
   * number of displayed register slots for display routine 
   */
    sizeof (dispf_b) / sizeof (struct st_disp),
  /* 
   * display parameters
   */
    &dispf_b[0],
    iorval,
    NULL,
    iopval,
    &per_hlp			/* on-line help for peripheral */
};

public
struct st_periph sx_portb_56302 =
{
  /*
   * number of displayed register slots for display routine
   */
    sizeof (dispf_b302) / sizeof (struct st_disp),
  /*
   * display parameters
   */
    &dispf_b302[0],
    NULL, /* iorval, */
    NULL,
    NULL, /* iopval, */
    &per_hlp                    /* on-line help for peripheral */
};

public
struct st_periph sx_portc_563 =
{
  /* 
   * number of displayed register slots for display routine 
   */
    sizeof (dispf_c) / sizeof (struct st_disp),
  /* 
   * display parameters
   */
    &dispf_c[0],
    NULL,
    NULL,
    NULL,
    &per_hlp			/* on-line help for peripheral */
};

#endif /* FULLSIM */

#if FULLSIM
static char
*hddr_hlp[] =
{
    "DSP Hi08/24 Port GPIO Direction Register.",
    NULL
},

*hdr_hlp[] =
{
    "DSP Hi08/24 Port GPIO Data Register.",
    NULL
},

*hpcr_hlp[] =
{
    "DSP Hi08/24 Port Control Register. ",
    "                         {H H H}  ",
    "     {H H H H H H}     {H H C A A H}",
    " {H H C D M A D R}   {H A R S 9 8 G}",
    " {A R S D U S S O}   {E E E E E E E}",
    " {P P P S X P P D} * {N N N N N N N}",
    NULL
},

*dirh_hlp[] =
{
    "DSP Host Port GPIO Direction 24-bit Register.",
    NULL
},

*dath_hlp[] =
{
    "DSP Host Port GPIO Data Register.",
    NULL
},

*pcrc_hlp[] =
{
    "DSP Port control register.",
    NULL
},

*prrc_hlp[] =
{
    "DSP Port direction register.",
    NULL
},

*pdrc_hlp[] =
{
    "DSP Port GPIO Data Register.",
    NULL
},

*pcrd_hlp[] =
{
    "DSP Port control register.",
    NULL
},

*prrd_hlp[] =
{
    "DSP Port direction register.",
    NULL
},

*pdrd_hlp[] =
{
    "DSP Port GPIO Data Register.",
    NULL
},

*pcre_hlp[] =
{
    "DSP Port control register.",
    NULL
},

*prre_hlp[] =
{
    "DSP Port direction register.",
    NULL
},

*pdre_hlp[] =
{
    "DSP Port GPIO Data Register.",
    NULL
};

#else
#define hddr_hlp NULL
#define hdr_hlp  NULL
#define hpcr_hlp  NULL
#define dirh_hlp NULL
#define dath_hlp NULL
#define pcrc_hlp NULL
#define prrc_hlp NULL
#define pdrc_hlp NULL
#define pcrd_hlp NULL
#define prrd_hlp NULL
#define pdrd_hlp NULL
#define pcre_hlp NULL
#define prre_hlp NULL
#define pdre_hlp NULL
#endif

#define A_REG8         (DSP_FA_SIZE8 | DSP_FA_WRD1)
#define A_REG16         (DSP_FA_SIZE16 | DSP_FA_WRD1)
#define A_REG24         (DSP_FA_SIZE24 | DSP_FA_WRD1)

#define A_REG8M        (A_REG8|DSP_FA_RENAB | DSP_FA_WENAB)
#define A_REG8RONLY    (A_REG8|DSP_FA_RENAB)
#define A_REG8WONLY    (A_REG8|DSP_FA_WENAB)

#define A_REG16M        (A_REG16|DSP_FA_RENAB | DSP_FA_WENAB)
#define A_REG16RONLY    (A_REG16|DSP_FA_RENAB)
#define A_REG16WONLY    (A_REG16|DSP_FA_WENAB)

#define A_REG24M        (A_REG24|DSP_FA_RENAB | DSP_FA_WENAB)
#define A_REG24RONLY    (A_REG24|DSP_FA_RENAB)
#define A_REG24WONLY    (A_REG24|DSP_FA_WENAB)

static
struct dt_regid regid_b[] =
{
    {"dirh", 0xffffffl, OFF_DIRH, DSP_DIAHEX, A_REG24M, dirh_hlp, MR_DIRH},
    {"dath", 0xffffffl, OFF_DATH, DSP_DIAHEX, A_REG24M, dath_hlp, MR_DATH},

};

static
struct dt_regid regid_b302[] =
{
    {"hddr", 0xffffl, OFF_HDDR, DSP_DIAHEX, A_REG16M, hddr_hlp, MR_HDDR},
    {"hdr", 0xffffl, OFF_HDR, DSP_DIAHEX, A_REG16M, hdr_hlp, MR_HDR},
    {"hpcr", 0xff7fl, OFF_HPCR, DSP_DIAHEX, A_REG16M, hpcr_hlp, MR_HPCR},

};

static
struct dt_regid regid_c[] =
{
  {"pcrc", 0x3fL, OFF_PORT_CONTROL, DSP_DIAHEX, A_REG8M | DSP_FA_WMULT, pcrc_hlp, MR_PCRC},
    {"prrc", 0x3fL, OFF_PORT_DDR, DSP_DIAHEX, A_REG8M, prrc_hlp, MR_PRRC},
    {"pdrc", 0x3fL, OFF_PORT_DATA, DSP_DIAHEX, A_REG8M, pdrc_hlp, MR_PDRC},
};

static
struct dt_regid regid_d[] =
{
  {"pcrd", 0x3fL, OFF_PORT_CONTROL, DSP_DIAHEX, A_REG8M | DSP_FA_WMULT, pcrd_hlp, MR_PCRD},
    {"prrd", 0x3fL, OFF_PORT_DDR, DSP_DIAHEX, A_REG8M, prrd_hlp, MR_PRRD},
    {"pdrd", 0x3fL, OFF_PORT_DATA, DSP_DIAHEX, A_REG8M, pdrd_hlp, MR_PDRD},
};

static
struct dt_regid regid_e[] =
{
    {"pcre", 0x7L, OFF_PORT_CONTROL, DSP_DIAHEX, A_REG8M | DSP_FA_WMULT, pcre_hlp, MR_PCRE},
    {"prre", 0x7L, OFF_PORT_DDR, DSP_DIAHEX, A_REG8M, prre_hlp, MR_PRRE},
    {"pdre", 0x7L, OFF_PORT_DATA, DSP_DIAHEX, A_REG8M, pdre_hlp, MR_PDRE},
};

#if ADSx
public
struct dt_periph dx_portb_563 =
{
    hspmread,
    hspmwrite,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /* 
   * number of registers 
   */
    1 + sizeof (struct portb_registers) / sizeof (long),
  /* 
   * number of registers names in regid  
   */
    sizeof (regid_b) / sizeof (struct dt_regid),
  /* 
   * describes regs. includes name,memory add,mask
   */
    &regid_b[0],
    NULL
};

public
struct dt_periph dx_portb_56302 =
{
    hspmread,
    hspmwrite,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /* 
   * number of registers 
   */
    1 + sizeof (struct portb302_registers) / sizeof (long),
  /* 
   * number of registers names in regid  
   */
    sizeof (regid_b302) / sizeof (struct dt_regid),
  /* 
   * describes regs. includes name,memory add,mask
   */
    &regid_b302[0],
    NULL
};

public
struct dt_periph dx_portc_563 =
{
    hspmread,
    hspmwrite,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /* 
   * number of registers 
   */
    HPORTMAX,			/* number of registers */
    sizeof (regid_c) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_c[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

public
struct dt_periph dx_portd_563 =
{
    hspmread,
    hspmwrite,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
    HPORTMAX,			/* number of registers */
    sizeof (regid_d) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_d[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

public
struct dt_periph dx_porte_563 =
{
    hspmread,
    hspmwrite,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
    HPORTMAX,			/* number of registers */
    sizeof (regid_e) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_e[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

static int
hspmread (int periph,
	  int regnum,
	  unsigned long *retv)	/* read reg */
{
    int error;
    unsigned long maddr;
    
    hsppdt = &dx_var->mperiph[periph];
    maddr = hsppdt->reg_addr + hsppdt->periph->regid[regnum].regxmem;

    error = dsp_rmem (dv_var->devindex, memory_map_x, maddr, retv);
    *retv &= hsppdt->periph->regid[regnum].maskval;

    return (error);
}

static int
hspmwrite (int periph,
	   int regnum,
	   unsigned long *regv)	/* write register with value */

{
    unsigned long maddr;
    
    hsppdt = &dx_var->mperiph[periph];
    maddr = hsppdt->reg_addr + hsppdt->periph->regid[regnum].regxmem;

    return (dsp_wmem (dv_var->devindex, memory_map_x, maddr, regv));
}

#else /* ADSx */

static int
hspmread_b (int periph, int regn, u_long *retv)	/* read port reg */
{
    start_hspmsm (periph);		/* initialize globals */
    sm_read_b (periph, regn, retv, 0);
    return 1;
}

static int
hspmread_b302 (int periph, int regn, u_long *retv) /* read port reg */
{
    start_hspmsm (periph);              /* initialize globals */
    sm_read_b302 (periph, regn, retv, 0);
    return 1;
}

static int
hspmwrite_b (int periph, int regn, u_long *regv)	/* write register with value */
{
    start_hspmsm (periph);		/* initialize globals */
    sm_write_b (periph, regn, *regv);
    reg_wf (regn);
    return 1;
}

static int
hspmwrite_b302 (int periph, int regn, u_long *regv)        /* write register with value */
{
    start_hspmsm (periph);              /* initialize globals */
    sm_write_b302 (periph, regn, *regv);
    reg_wf (regn);
    return 1;
}

static int
hspmread_c (int periph, int regn, u_long *retv)	/* read port reg */
{
    start_hspmsm (periph);		/* initialize globals */
    sm_read_c (periph, regn, retv, 0);
    return 1;
}

static int
hspmwrite_c (int periph, int regn, u_long *regv)	/* write register with value */
{
    start_hspmsm (periph);		/* initialize globals */
    sm_write_c (periph, regn, *regv);
    reg_wf (regn);
    return 1;
}

static void
hspmcycle (int periph)		/* execute portb cycle */
{
    if (dv_var->gsig[DSPT_FAST_MODE_563] == 2)
        return;

    return;
}

static int
ex_reset_b ()
{
    /* these should be set to 0 in the individual peripheral modules */
    hspr[MR_DCTR_PORT_CONTROL] = 0l;
    hspr[MR_DIRH] = 0l;
    hspr[MR_DATH] = 0l;
    reg_wf (MR_DCTR_PORT_CONTROL);
    reg_wf (MR_DIRH);
    reg_wf (MR_DATH);
    return 0;
}

static int
ex_reset_b302 ()
{
    /* these should be set to 0 in the individual peripheral modules */
    hspr[MR_HPCR] = 0l;
    hspr[MR_HDDR] = 0l;
    hspr[MR_HDR] = 0l;
    reg_wf (MR_HPCR);
    reg_wf (MR_HDDR);
    reg_wf (MR_HDR);
    return 0;
}

static int 
ex_reset_c ()
{
    /* these should be set to 0 in the individual peripheral modules */
    hspr[MR_PORT_CONTROL] = hspr[MR_PORT_DDR] = hspr[MR_PORT_DATA] = 0l;
    reg_wf (MR_PORT_CONTROL);
    reg_wf (MR_PORT_DDR);
    reg_wf (MR_PORT_DATA);
    return 0;
}

static void
hspmreset_b (int periph, int rstflag, int mode)	
/* reset portb registers and portb interrupts */
/* rstflag 1 indicates reset, 0 indicates stop reset or pbc=0 reset */
{
    start_hspmsm (periph);		/* initialize globals */
    if (rstflag)
	ex_reset_b ();
    return;
}

static void
hspmreset_b302 (int periph, int rstflag, int mode)
/* reset portb registers and portb interrupts */
/* rstflag 1 indicates reset, 0 indicates stop reset or hpcr=0 reset */
{
    start_hspmsm (periph);              /* initialize globals */
    if (rstflag)
        ex_reset_b302 ();
    return;
}

static void 
hspmreset_c (int periph, int rstflag, int mode)	
/* reset portb registers and portb interrupts */
/* 1 indicates reset, 0 indicates stop reset or pbc=0 reset */
{

    start_hspmsm (periph);		/* initialize globals */
    if (rstflag)
	ex_reset_c ();
    return;
}

public
struct dt_periph dx_portb_563 =
{
    hspmread_b,
    hspmwrite_b,
    hspmsmread_b,
    hspmsmwrite_b,
    hspmcycle,
#if BLM
    NULL,	/* phase0 */
    NULL,	/* phase1 */
    NULL,	/* async */
#endif
    hspmreset_b,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /* 
   * number of registers 
   */
    1 + sizeof (struct portb_registers) / sizeof (long),
  /* 
   * number of registers names in regid  
   */
    sizeof (regid_b) / sizeof (struct dt_regid),
  /* 
   * describes regs. includes name,memory add,mask
   */
    &regid_b[0],
    NULL
};

public
struct dt_periph dx_portb_56302 =
{
    hspmread_b302,
    hspmwrite_b302,
    hspmsmread_b302,
    hspmsmwrite_b302,
    hspmcycle,
#if BLM
    NULL,       /* phase0 */
    hspmcycle,  /* phase1 */
    NULL,/* async */
#endif
    hspmreset_b302,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /*
   * number of registers
   */
    1 + sizeof (struct portb302_registers) / sizeof (long),
  /*
   * number of registers names in regid
   */
    sizeof (regid_b302) / sizeof (struct dt_regid),
  /*
   * describes regs. includes name,memory add,mask
   */
    &regid_b302[0]          /* describes regs. includes name,memory add,mask */
};


public
struct dt_periph dx_portc_563 =
{
    hspmread_c,
    hspmwrite_c,
    hspmsmread_c,
    hspmsmwrite_c,
    hspmcycle,
#if BLM
    NULL,	/* phase0 */
    NULL,	/* phase1 */
    NULL,	/* async */
#endif
    hspmreset_c,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
  /* 
   * number of registers 
   */
    HPORTMAX,			/* number of registers */
    sizeof (regid_c) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_c[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

public
struct dt_periph dx_portd_563 =
{
    hspmread_c,
    hspmwrite_c,
    hspmsmread_c,
    hspmsmwrite_c,
    hspmcycle,
#if BLM
    NULL,	/* phase0 */
    NULL,	/* phase1 */
    NULL,	/* async */
#endif
    hspmreset_c,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
    HPORTMAX,			/* number of registers */
    sizeof (regid_d) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_d[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

public
struct dt_periph dx_porte_563 =
{
    hspmread_c,
    hspmwrite_c,
    hspmsmread_c,
    hspmsmwrite_c,
    hspmcycle,
#if BLM
    NULL,	/* phase0 */
    NULL,	/* phase1 */
    NULL,	/* async */
#endif
    hspmreset_c,
    NULL,
    NULL,
    DSP_IO_VALID | DSP_IO_STACK | DSP_IO_ENABLED,
    HPORTMAX,			/* number of registers */
    sizeof (regid_e) / sizeof (struct dt_regid),	/* number of registers names in regid  */
    &regid_e[0],		/* describes regs. includes name,memory add,mask */
    NULL
};

static int
start_hspmsm (int periph)
{

#if FULLSIM
    hspps = &sv_var->periph[periph];
    hsppst = sx_var->periph[periph];
    hspdf = hspps->regattr;
#endif
    hsppd = &dv_var->periph[periph];
    hsppdt = &dx_var->mperiph[periph];
    hspr = hsppd->regval;
    return 0;
}

static int
hspmsmwrite_b (int periph, u_long addr, u_long regv, int se)
/* se side effects flag. 1=do side effects. */
{
    int    regn;

    start_hspmsm (periph);

    switch ((int) (addr - dx_var->mperiph[periph].reg_addr))
    {
    case OFF_DATH:
	regn = MR_DATH;
	break;
    case OFF_DCTR:
	regn = MR_DCTR_PORT_CONTROL;
	break;
    case OFF_DIRH:
	regn = MR_DIRH;
	break;
    default:
	return 0;
    }
    sm_write_b (periph, regn, regv);
    return 0;
}

static int
hspmsmwrite_b302 (int periph, u_long addr, u_long regv, int se)
/* se side effects flag. 1=do side effects. */
{
    int    regn;

    start_hspmsm (periph);

    switch ((int) (addr - dx_var->mperiph[periph].reg_addr))
    {
    case OFF_HDR:
        regn = MR_HDR;
        break;
    case OFF_HPCR:
        regn = MR_HPCR;
        break;
    case OFF_HDDR:
        regn = MR_HDDR;
        break;
    default:
        return 0;
    }
    sm_write_b302 (periph, regn, regv);
    return 0;
}

static int
hspmsmwrite_c (int periph, u_long addr, u_long regv, int se)
/* se - side effects flag. 1=do side effects. */
{

    int regn;

    start_hspmsm (periph);

    switch ((int) (addr - dx_var->mperiph[periph].reg_addr))
    {
    case OFF_PORT_CONTROL:
	regn = MR_PCRC;
	break;
    case OFF_PORT_DDR:
	regn = MR_PRRC;
	break;
    case OFF_PORT_DATA:
	regn = MR_PDRC;
	break;
    default:
	return 0;
    }
    sm_write_c (periph, regn, regv);
    return 0;
}

static void
hspmsmread_b (int periph, u_long addr, u_long *regv, int se)
/* se side effects flag. 1=do side effects. */
{
    u_long	base_portb_addr; 	/* start address of io register bank */
    int		regn;

    start_hspmsm (periph);
    base_portb_addr = dx_var->mperiph[periph].reg_addr; 

    switch ((int) (addr - base_portb_addr))
    {
    case OFF_DATH:
	regn = MR_DATH;
	break;
    case OFF_DIRH:
	regn = MR_DIRH;
	break;
    case OFF_DCTR:
/* Value is returned by host here is only copy of DCTR */
        return;
    default:
	return;
    }

    sm_read_b (periph, regn, regv, se);
    return;
}

static void
hspmsmread_b302 (int periph, u_long addr, u_long *regv, int se)
/* se side effects flag. 1=do side effects. */
{
    u_long      base_portb_addr;        /* start address of io register bank */    int         regn;

    start_hspmsm (periph);
    base_portb_addr = dx_var->mperiph[periph].reg_addr;

    switch ((int) (addr - base_portb_addr))
    {
    case OFF_HDR:
        regn = MR_HDR;
        break;
    case OFF_HDDR:
        regn = MR_HDDR;
        break;
    case OFF_HPCR:
        regn = MR_HPCR;
        break;
    default:
        return;
    }

    sm_read_b302 (periph, regn, regv, se);
    return;
}

static void 
hspmsmread_c (int periph, u_long addr, u_long *regv, int se)
/* se side effects flag. 1=do side effects. */
{
    int regn;

    start_hspmsm (periph);

    switch ((int) (addr - dx_var->mperiph[periph].reg_addr))
    {
    case OFF_PORT_CONTROL:
	regn = MR_PCRC;
	break;
    case OFF_PORT_DDR:
	regn = MR_PRRC;
	break;
    case OFF_PORT_DATA:
	regn = MR_PDRC;
	break;
    default:
	return;
    }
    sm_read_c (periph, regn, regv, se);
    return;
}

static int
reg_wf (int regn)
{

    if (regn < hsppdt->periph->numdregs) /* check for displayable register */
    { 
        hspr[regn] &= hsppdt->periph->regid[regn].maskval;

#if FULLSIM
        hspdf[regn] |= (DSP_BRSWRITE | DSP_DISWRITE);
        if (hspdf[regn] & (DSP_VA_OFILE | DSP_VA_TOFILE))
            siml_iowreg (PERIPH_NUM, (int) regn);

        if (hsppdt->periph->regid[regn].fixedattr & (DSP_FA_RENAB | DSP_FA_WENAB))
        {
            u_long maddr = hsppdt->periph->regid[regn].regxmem + hsppdt->reg_addr;
            siml_xmemflag (maddr);
        }
#endif
    }
    return 0;
}

static u_long
get_gpio_map (void)
/* This function called from sm_write_b and sm_write_c  
 *
 * It returns mask of host port pins
 * (bank1) configured as GPIO 
 * It defined by the selected mode in DCTR
 */
{
    static u_long mask_table[] = 
    {
        0x00000000l,	/* Terminate and Reset */
        0x00000000l,	/* PCI */
        0x00700000l,	/* Gen Bus */
        0x00000000l,	/* Enhanced Gen Bus */

        0x00ffffffl,	/* GPIO */
        0x00000000l,	/* Self Configuration */
        0x00000000l,	/* Reserved */
        0x00000000l,	/* Reserved */
    };
    
    int mode = 0x7 & (hspr[MR_DCTR_PORT_CONTROL] >> 20);

    return mask_table[mode];

}

#define GPIO_PORTB1_START_BIT (16)

static int
sm_write_b (int periph, int regn, u_long regv)
/* pb0..pb49 
 * portb1 - pb16..32,pb49 (18 bits)
 * portb  - pb0..pb15,pb33..pb48 (32 bits)
 * GPIO   - pb0..pb23  (24 bits)
 *
 * |     <- GPIO ->       |
 *	     1111111111222222222233333333334444444444 	
 * 01234567890123456789012345678901234567890123456789
 * | <- portb ->  |  <- portb1 ->  |  <- portb ->  |^
 *						    |
 *					    portb1 -|
 */
{
/* gpio pins belongs to portb */

    struct dt_mperiph *cp = &dx_var->mperiph[periph]; /* current peripheral */
    int pindex		= cp->periphid.portindex;
    int pindex2		= cp->periphid.portindex2;
    u_long portmask 	= cp->periphid.portmask;
    u_long portmask2 	= cp->periphid.portmask2;
    struct dev_xpdata *xpv = &dv_var->xportval[pindex].pc;
    struct dev_xpdata *xpv2 = &dv_var->xportval[pindex2].pc;


    u_long portval = 0;
    u_long mask2 = 0;
    u_long mask3 = 0;

    hspr[regn] = regv;

#if FULLSIM
    if (regn != MR_DCTR_PORT_CONTROL)
	hspdf[regn] |= (DSP_BRSWRITE | DSP_DISWRITE);
#endif

/* 
 * active GPIO (non-peripheral) pins 
 */
    mask2 = get_gpio_map() & portmask;
    /* mask of host portb pins configured as GPIO */
    if (mask2)
    {
	mask3 = mask2 & hspr[MR_DIRH] & portmask;	/* port output pins */
	xpv->outf &= ~mask2;
	xpv->outf |= mask3;
	xpv->outd &= ~mask2;
	xpv->outd |= portval |= (hspr[MR_DATH] & portmask) & mask3;
    }
    mask2 = (get_gpio_map() >> GPIO_PORTB1_START_BIT) & portmask2;
    /* mask of host portb1 pins configured as GPIO */
    if (mask2)
    {
	mask3 = mask2 & (hspr[MR_DIRH]>>GPIO_PORTB1_START_BIT);	/* port output pins */
	xpv2->outf &= ~mask2;
	xpv2->outf |= mask3;
	xpv2->outd &= ~mask2;
	xpv2->outd |= (hspr[MR_DATH]>>GPIO_PORTB1_START_BIT) & mask3;
        portval |= (hspr[MR_DATH] & (mask3<<GPIO_PORTB1_START_BIT));
    }
#if FULLSIM 
        if (mask3)
            siml_iowperiph (periph, &portval, 0l);
#endif

    return 0;
}

static int
sm_read_b (int periph, int regn, u_long *regv, int se)
/* only  regn = MR_DATH and regn = MR_DIRH are processed
 * in this function
 */
{

    struct dt_mperiph *cp = &dx_var->mperiph[periph];	/* current peripheral */
    int pindex = cp->periphid.portindex;
    int pindex2 = cp->periphid.portindex2;
    u_long portmask = cp->periphid.portmask;
    u_long portmask2 = cp->periphid.portmask2;
    struct dev_xpdata *xpv = &dv_var->xportval[pindex].pc;
    struct dev_xpdata *xpv2 = &dv_var->xportval[pindex2].pc;
    u_long mask_input_gpio_pin; /* pins configured as gpio inpit */

    mask_input_gpio_pin = get_gpio_map()  &  (~hspr[MR_DIRH]);

    switch(regn) {
    case MR_DATH:
#if FULLSIM           
        if (se && mask_input_gpio_pin) 
        {
            struct sev_evres iod;

            if (siml_iorperiph (periph, &iod))
            {
                /* 
                 *  read port from stack input file 
                 */
                xpv->ind &= ~portmask;
                xpv->ind |= iod.xval[0] & portmask;
#if !BLM
                xpv->inf = portmask;
#endif
                xpv2->ind &= ~portmask2;
                xpv2->ind |= (iod.xval[0]>>GPIO_PORTB1_START_BIT) & portmask2;
#if !BLM
                xpv2->inf = portmask2;
#endif

            }
        }
#endif  /* FULLSIM*/
        
        /* get output and non-GPIO pins from DATH */
        *regv = ~mask_input_gpio_pin  &  
                 hspr[MR_DATH] & 
                 (portmask | (portmask2<<GPIO_PORTB1_START_BIT));
        *regv |= (xpv->ind | xpv2->ind<<GPIO_PORTB1_START_BIT) & mask_input_gpio_pin;
        
        return 0;
    case MR_DIRH:
        *regv = hspr[regn];
        return 0;
    default:
        return 0;
    }
} /* sm_read_b */

#define  M_HGEN       (1<<0)          /* Hi08/24 Port GPIO Enable */
#define  M_HA8EN      (1<<1)          /* Hi08/24 Address 8 Enable */
#define  M_HA9EN      (1<<2)          /* Hi08/24 Address 9 Enable */
#define  M_HCSEN      (1<<3)          /* Hi08/24 Chip Select Enable */
#define  M_HREN       (1<<4)          /* Hi08/24 Request Enable */
#define  M_HAEN       (1<<5)          /* Hi08/24 Acknowledge Enable */
#define  M_HEN        (1<<6)          /* Hi08/24 Enable */
#define  M_HROD       (1<<8)          /* Hi08/24 Request Open Drain mode */
#define  M_HDSP       (1<<9)          /* Hi08/24 Data Strobe Polarity */
#define  M_HASP       (1<<10)         /* Hi08/24 Address Strobe Polarity */
#define  M_HMUX       (1<<11)         /* Hi08/24 Multiplexed bus select */
#define  M_HDDS       (1<<12)         /* Hi08/24 Double/Single Strobe select */
#define  M_HCSP       (1<<13)         /* Hi08/24 Chip Select Polarity */
#define  M_HRP        (1<<14)         /* Hi08/24 Request Polarity Polarity */
#define  M_HAP        (1<<15)         /* Hi08/24 Acknowledge Polarity */

static int
sm_write_b302 (int periph, int regn, u_long regv)
{

    int k,
     pindex;
    unsigned long newval,
     maddr;
    struct dt_mperiph *mp;
    unsigned long mask2,
     mask3,mask4;
    unsigned long maskval = hsppdt->periph->regid[regn].maskval;
    unsigned long mr_port_control;

    unsigned long portval;
    struct dev_xpdata *xpv;

    mr_port_control = hspr[MR_HPCR];
    newval = 0l;
    mp = &dx_var->mperiph[periph];
    pindex = mp->periphid.portindex;
    maddr = mp->reg_addr + mp->periph->regid[regn].regxmem;
    for (k = 0; k < dx_var->numperiph; k++)
    {
	mp = &dx_var->mperiph[k];
	if ((mp->periphid.portindex == pindex) &&
	    mp->port_control_mask)
	{
	    newval |= (*(mp->periph->xwritef)) (k, maddr, regv, 1);
	}
    }

    xpv = &dv_var->xportval[pindex].pc;
    hspr[regn] = newval;	/* local expanded copy */
#if FULLSIM
    hspdf[regn] |= (DSP_BRSWRITE | DSP_DISWRITE);
#endif
    /* find active GPIO pins */
    mask4 = 0;
    if(mr_port_control & M_HGEN){
        if(mr_port_control & M_HEN){ 
            if(mr_port_control & M_HMUX){ 
                if(!(mr_port_control & M_HA8EN)){ 
                    mask4 |= (1<<9);
                }
                if(!(mr_port_control & M_HA9EN)){ 
                    mask4 |= (1<<10);
                }
            }
            if(!(mr_port_control & M_HCSEN)){ 
                mask4 |= (1<<13);
            }
            if(!(mr_port_control & M_HREN)){ 
                mask4 |= (1<<14);
                mask4 |= (1<<15);
            }        
            if(!(mr_port_control & M_HAEN)){ 
                mask4 |= (1<<15);
            }        
        }
        else /* all pins are GPIO */
        {
            mask4 = ~0;
        }
    }
    else{ /* GPIO non active */
        mask4 = 0;
    }
    
    mask2 = mask4 & maskval;
    if (mask2)
    {
	mask3 = mask2 & hspr[MR_HDDR];	/* port output pins */
	xpv->outf &= ~mask2;
	xpv->outf |= mask3;
	xpv->outd &= ~mask2;
	xpv->outd |= portval = hspr[MR_HDR] & mask3;
#if FULLSIM
	if (mask3)
	    siml_iowperiph (periph, &portval, 0l);
	if (hspdf[regn] & (DSP_VA_OFILE | DSP_VA_TOFILE))
	{
	    int periphnum;
	    periphnum = hsppdt - &dx_var->mperiph[0];
	    siml_iowreg (periphnum ,regn);
	}
#endif
    }
    return 0;
}

static int
sm_read_b302 (int periph, int regn, u_long *regv, int se)
/* only  regn = MR_HDR and regn = MR_HDDR are processed
 * in this function
 */
{

    struct dt_mperiph *cp = &dx_var->mperiph[periph];	/* current peripheral */
    int pindex = cp->periphid.portindex;
    u_long portmask = cp->periphid.portmask;
    struct dev_xpdata *xpv = &dv_var->xportval[pindex].pc;
    u_long mask_input_gpio_pin; /* pins configured as gpio inpit */

    mask_input_gpio_pin =  portmask & (~hspr[MR_HDDR]);

    switch(regn) {
    case MR_HDR:
#if FULLSIM           
        if (se && mask_input_gpio_pin) 
        {
            struct sev_evres iod;

            if (siml_iorperiph (periph, &iod))
            {
                /* 
                 *  read port from stack input file 
                 */
                xpv->ind &= ~portmask;
                xpv->ind |= iod.xval[0] & portmask;
#if !BLM
                xpv->inf = portmask;
#endif

            }
        }
#endif  /* FULLSIM*/
        
        /* get output and non-GPIO pins from HDR */
        *regv = ~mask_input_gpio_pin  &  
                 hspr[MR_HDR] & 
                 (portmask);
        *regv |= (xpv->ind) & mask_input_gpio_pin;
        
        return 0;
    case MR_HDDR:
    case MR_HPCR:
        *regv = hspr[regn];
        return 0;
    default:
        return 0;
    }
} /* sm_read_b302 */


static int
sm_write_c (int periph, int regn, u_long regv)
{

    struct dt_mperiph *cp = &dx_var->mperiph[periph]; /* current peripheral */
    int pindex		= cp->periphid.portindex;
    u_long portmask 	= cp->periphid.portmask;
    struct dev_xpdata *xpv = &dv_var->xportval[pindex].pc;

    u_long mask2;
    u_long mask3;
    u_long portval;

    hspr[regn] = regv;
#if FULLSIM
    hspdf[regn] |= (DSP_BRSWRITE | DSP_DISWRITE);
#endif
    mask2 = (~hspr[MR_PORT_CONTROL]) & portmask;	/* active (non-peripheral) pins */
    if (mask2)
    {
	mask3 = mask2 & hspr[MR_PORT_DDR];	/* port output pins */
	xpv->outf &= ~mask2;
	xpv->outf |= mask3;
	xpv->outd &= ~mask2;
	xpv->outd |= portval = hspr[MR_PORT_DATA] & mask3;
#if FULLSIM 
	if (mask3)
	    siml_iowperiph (periph, &portval, 0l);
#endif
    }
    return 0;
}

static int
sm_read_c (int periph, int regn, u_long *regv, int se)
{

    struct dt_mperiph *cp = &dx_var->mperiph[periph];	/* current peripheral */
    int pindex = cp->periphid.portindex;
    u_long portmask = cp->periphid.portmask;
    struct dev_xpdata *xpv = &dv_var->xportval[pindex].pc;
    u_long mask_input_gpio_pin; /* pins configured as gpio inpit */

    mask_input_gpio_pin = (~hspr[MR_PORT_CONTROL]) & (~hspr[MR_PORT_DDR]) & portmask;

    switch(regn) {
    case MR_PORT_DATA:
#if FULLSIM           
        if (se && mask_input_gpio_pin) 
        {
            struct sev_evres iod;
            
            if (siml_iorperiph (periph, &iod))
            {
                /* 
                 *  read port from stack input file 
                 */
                xpv->ind &= ~portmask;
                xpv->ind |= iod.xval[0] & portmask;
#if !BLM
                xpv->inf = portmask;
#endif
            }
        }
#endif  /* FULLSIM*/
        
        /* get output and non-GPIO pins from DATH */
        *regv = ~mask_input_gpio_pin  &  hspr[MR_PORT_DATA]  &  portmask;
        *regv |= (xpv->ind) & mask_input_gpio_pin & portmask;
        return 0;
        
    case MR_PORT_CONTROL:
    case MR_PORT_DDR:
        *regv = hspr[regn];
        return 0;
        
    default:
        return 0;
    }
}
    
#endif /* ADSx */
