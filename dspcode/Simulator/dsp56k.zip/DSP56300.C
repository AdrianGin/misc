/* $Id: dsp56300.c,v 1.29 1996/09/04 15:15:38 jay Exp $ */
#include "simcom.h"
#include "simdev.h"
#include "simusr.h"
#include "gsig563.h"
#include "core563.h"

/*
 *
 *	.---------------. ffffff
 *	|   RESERVED	|
 *	+---------------+ ff0000
 *	|		|
 *	|		|
 *	|		|
 *	|		|
 *	|		|
 *	+---------------+ 001000	X2
 *	|		|
 *	|  PRAM/ICACHE	|
 *	|		|
 *	+---------------+ 000c00	X1
 *	|		|
 *	|    PRAM 	|
 *	|		|
 *	`---------------' 000000	X0
 *
 * The definitions below follow the equations:
 *	DSP_PI_SIZE_56301 = X1-X0
 *	DSP_IC_SIZE_56301 = X2-X1
 */

#define DSP_PI_SIZE_56301 ICACHE_BASE_ADDR	/* size of on-chip program memory */
#define DSP_PI_SIZE_56305 ICACHE_BASE_ADDR_56305	/* size of on-chip program memory */
#define DSP_IC_SIZE_56301 ICACHE_SIZE	/* size of pi which can be used as icache */
#define DSP_IC_SIZE_56305 ICACHE_SIZE /* size of pi which can be used as icache */

#define DSP_PF_SIZE_56301 (DSP_IC_SIZE_56301 / ICACHE_N_SECTORS)
#define DSP_PF_SIZE_56305 (DSP_IC_SIZE_56305 / ICACHE_N_SECTORS)
#define DSP_PT_SIZE_56301 (ICACHE_N_SECTORS * 4)
#define DSP_PT_SIZE_56305 (ICACHE_N_SECTORS * 4)

#define DSP_XI_SIZE_56301 2048	/* size of on-chip X memory */
#define DSP_XI_SIZE_56305 0xf00
#define DSP_YI_SIZE_56301 2048	/* size of on-chip Y memory */
#define DSP_YI_SIZE_56305 2048

#define DSP_PR_SIZE_56301 64	/* size of on-chip bootstrap rom */
#define DSP_PR_SIZE_56305 64  /* size of on-chip bootstrap rom */
#define DSP_OSR_SIZE_56301 1536	/* size of RTOS rom */
#define DSP_XR_SIZE_56301 1536	/* (= 0x5FF) size of on-chip X data rom */
#define	DSP_XP_SIZE_56301 128	/* size of on-chip x peripheral memory */
#define DSP_XP_SIZE_56305 128   /* size of on-chip x peripheral memory */
#define DSP_YR_SIZE_56301 1536	/* (= 0x5FF) size of on-chip Y data rom */
#define DSP_YR_SIZE_56305 3072  /* 3k (= 0xBFF) size of on-chip Y data rom */
#define DSP_LI_SIZE_56301 2048	/* size of on-chip data mem */

extern struct dt_periph
 dx_core_563,
 dx_core_56301b,
 dx_core_56302,
 dx_core_56305,
#if !ADSx    
 dx_csim_563,
 dx_csim_56301b,
 dx_csim_56302,
 dx_csim_56305,
#endif    
 dx_host_563,
 dx_host_56302,
 dx_ssi_563,
 dx_sci_563,
 dx_portb_563,
 dx_portb_56302,
 dx_portc_563,
 dx_portd_563,
 dx_porte_563,
 dx_timer_563,
 dx_prescaler_563,
 dx_count_563,
 dx_vcop_56305,
 dx_fcop_56305,
 dx_ccop_56305;


#if ADSx
extern struct dt_periph dx_once_563;
extern struct dt_periph dx_jtag_563;
#endif 

/*
 * Dont forget to update sx_periph_563[] when changing dx_periph_563[]!!
 *
 *
 * MBASE is the base address for the peripheral's memory mapped registers.
 * IBASE is the base interrupt vector address for the peripheral.
 * In both cases the base is the LOWEST address.
 */
#define		MBASE_CORE		0x000000
#define		MBASE_HOST		M_DCTR_563
#define		MBASE_SSI0		M_RSMB0_563
#define		MBASE_SSI1		M_RSMB1_563
#define		MBASE_SCI		M_SSR_563
#define		MBASE_PORTB		M_DCTR_563
#define		MBASE_PORTC		M_PDRC_563
#define		MBASE_PORTD		M_PDRD_563
#define		MBASE_PORTE		M_PDRE_563
#define		MBASE_PRESCALER		M_TPCR_563
#define		MBASE_TIMER0		M_TCR0_563
#define		MBASE_TIMER1		M_TCR1_563
#define		MBASE_TIMER2		M_TCR2_563

#define		MCONT_HOST		M_DCTR_563
#define		MCONT_SSI0		M_RSMB0_563
#define		MCONT_SSI1		M_RSMB1_563
#define		MCONT_SCI		M_SCCR_563
#define		MCONT_PORTB		M_DCTR_563
#define		MCONT_PORTC		M_PCRC_563
#define		MCONT_PORTD		M_PCRD_563
#define		MCONT_PORTE		M_PCRE_563

#define		IBASE_CORE		0x000000
#define		IBASE_HOST		I_HPTT_563
#define		IBASE_SSI0		I_SI0RD_563
#define		IBASE_SSI1		I_SI1RD_563
#define		IBASE_SCI		I_SCIRD_563
#define		IBASE_TIMER0		I_TIM0C_563
#define		IBASE_TIMER1		I_TIM1C_563
#define		IBASE_TIMER2		I_TIM2C_563

static
struct dt_mperiph dx_periph_56301[] =
{
    {
	{"core", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_core_563, "", 0, 0x3ff, 0xf},
#if !ADSx    
    {
	{"csim", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_csim_563, "", 0, 0, 0},
#endif    
    {
	{"host", DSP_PORT_B, 0xffffffffL, DSP_PORT_B1, 0x3ffffL},
	MBASE_PORTB, 0x700000L, MBASE_HOST, IBASE_HOST, 0l, 0x3L, &dx_host_563, "", 0l, 0xf0000000l,0},
    {
	{"ssi0", DSP_PORT_C, 0x3fL},
	MBASE_PORTC, 0x3fL, MBASE_SSI0, IBASE_SSI0, 0l, 0x0cL, &dx_ssi_563, "0", 2L, 0xc00,0xc00},
    {
	{"ssi1", DSP_PORT_D, 0x3fL},
	MBASE_PORTD, 0x3fl, MBASE_SSI1, IBASE_SSI1, 0l, 0x30L, &dx_ssi_563, "1", 4L, 0x3000,0x3000},
    {
	{"sci", DSP_PORT_E, 0x7L},
	MBASE_PORTE, 0x7l, MBASE_SCI, IBASE_SCI, 0l, 0xc0L, &dx_sci_563, "", 6L, 0xc000,0xc000},
    {
	{"portb", DSP_PORT_B, 0xffffL, DSP_PORT_B1, 0xffL},
      MCONT_PORTB, 0x0L, MBASE_PORTB, 0l, 0l, 0l, &dx_portb_563, "", 0, 0, 0},
    {
	{"portc", DSP_PORT_C, 0x3fL},
      MCONT_PORTC, 0x0L, MBASE_PORTC, 0l, 0l, 0l, &dx_portc_563, "", 0, 0 ,0},
    {
	{"portd", DSP_PORT_D, 0x3fL},
      MCONT_PORTD, 0x0L, MBASE_PORTD, 0l, 0l, 0l, &dx_portd_563, "", 0, 0, 0},
    {
	{"porte", DSP_PORT_E, 0x7L},
     MCONT_PORTE, 0x0L, MBASE_PORTE, 0l, 0l, 0l, &dx_porte_563, "", 0l, 0, 0},

   /*
    * NOTE: the DSP_PS_OFFSET constant in gsig563.h should get the entry-index
    *       of the prescaler peripheral in this record */
    {
	{"prescaler", 0, 0},
	MBASE_PRESCALER, 0l, MBASE_PRESCALER, 0l, 0l, 0x300L, &dx_prescaler_563, "", 0, 0, 0},
    {
	{"timer0", DSP_PORT_M, DSPT_PIM_TIO0_563},
	MBASE_TIMER0, 0l, MBASE_TIMER0, IBASE_TIMER0, 0l, 0x300L, &dx_timer_563, "0", 0x8L, 0x10000, 0},
    {
	{"timer1", DSP_PORT_M, DSPT_PIM_TIO1_563},
	MBASE_TIMER1, 0l, MBASE_TIMER1, IBASE_TIMER1, 0l, 0x300L, &dx_timer_563, "1", 0x8L, 0x20000, 0},
    {
	{"timer2", DSP_PORT_M, DSPT_PIM_TIO2_563},
	MBASE_TIMER2, 0l, MBASE_TIMER2, IBASE_TIMER2, 0l, 0x300L, &dx_timer_563, "2", 0x8L, 0x40000, 0},
#if ADSx
    {
        {"once", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_once_563, "", 0, 0, 0},
    {
        {"jtag", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_jtag_563, "", 0, 0, 0},
#endif    
    {
	{"count", 0, 0L},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_count_563, "", 0, 0, 0},
};
static
struct dt_mperiph dx_periph_56301b[] =
{
    {
	{"core", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_core_56301b, "", 0, 0x3ff, 0xf},
#if !ADSx    
    {
	{"csim", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_csim_56301b, "", 0, 0, 0},
#endif    
    {
	{"host", DSP_PORT_B, 0xffffffffL, DSP_PORT_B1, 0x3ffffL},
	MBASE_PORTB, 0x700000L, MBASE_HOST, IBASE_HOST, 0l, 0x3L, &dx_host_563, "", 0l, 0xf0000000l,0},
    {
	{"ssi0", DSP_PORT_C, 0x3fL},
	MBASE_PORTC, 0x3fL, MBASE_SSI0, IBASE_SSI0, 0l, 0x0cL, &dx_ssi_563, "0", 2L, 0xc00,0xc00},
    {
	{"ssi1", DSP_PORT_D, 0x3fL},
	MBASE_PORTD, 0x3fl, MBASE_SSI1, IBASE_SSI1, 0l, 0x30L, &dx_ssi_563, "1", 4L, 0x3000,0x3000},
    {
	{"sci", DSP_PORT_E, 0x7L},
	MBASE_PORTE, 0x7l, MBASE_SCI, IBASE_SCI, 0l, 0xc0L, &dx_sci_563, "", 6L, 0xc000,0xc000},
    {
	{"portb", DSP_PORT_B, 0xffffL, DSP_PORT_B1, 0xffL},
      MCONT_PORTB, 0x0L, MBASE_PORTB, 0l, 0l, 0l, &dx_portb_563, "", 0, 0, 0},
    {
	{"portc", DSP_PORT_C, 0x3fL},
      MCONT_PORTC, 0x0L, MBASE_PORTC, 0l, 0l, 0l, &dx_portc_563, "", 0, 0 ,0},
    {
	{"portd", DSP_PORT_D, 0x3fL},
      MCONT_PORTD, 0x0L, MBASE_PORTD, 0l, 0l, 0l, &dx_portd_563, "", 0, 0, 0},
    {
	{"porte", DSP_PORT_E, 0x7L},
     MCONT_PORTE, 0x0L, MBASE_PORTE, 0l, 0l, 0l, &dx_porte_563, "", 0l, 0, 0},

   /*
    * NOTE: the DSP_PS_OFFSET constant in gsig563.h should get the entry-index
    *       of the prescaler peripheral in this record */
    {
	{"prescaler", 0, 0},
	MBASE_PRESCALER, 0l, MBASE_PRESCALER, 0l, 0l, 0x300L, &dx_prescaler_563, "", 0, 0, 0},
    {
	{"timer0", DSP_PORT_M, DSPT_PIM_TIO0_563},
	MBASE_TIMER0, 0l, MBASE_TIMER0, IBASE_TIMER0, 0l, 0x300L, &dx_timer_563, "0", 0x8L, 0x10000, 0},
    {
	{"timer1", DSP_PORT_M, DSPT_PIM_TIO1_563},
	MBASE_TIMER1, 0l, MBASE_TIMER1, IBASE_TIMER1, 0l, 0x300L, &dx_timer_563, "1", 0x8L, 0x20000, 0},
    {
	{"timer2", DSP_PORT_M, DSPT_PIM_TIO2_563},
	MBASE_TIMER2, 0l, MBASE_TIMER2, IBASE_TIMER2, 0l, 0x300L, &dx_timer_563, "2", 0x8L, 0x40000, 0},
#if ADSx
    {
        {"once", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_once_563, "", 0, 0, 0},
    {
        {"jtag", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_jtag_563, "", 0, 0, 0},
#endif    
    {
	{"count", 0, 0L},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_count_563, "", 0, 0, 0},
};

static
struct dt_mperiph dx_periph_56302[] =
{
    {
	{"core", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_core_56302, "", 0, 0x3ff,0xf},
#if !ADSx    
    {
	{"csim", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_csim_56302, "", 0, 0,0},
#endif    
    {
	{"host", DSP_PORT_B, 0xffffL},
	M_HCR_56302, 0xffff, M_HCR_56302, I_HRDF_56302, 0l, 0x3L, &dx_host_56302, "", 0l, 0x180000,0x180000},
    {
	{"ssi0", DSP_PORT_C, 0x3fL},
	MBASE_PORTC, 0x3fL, MBASE_SSI0, IBASE_SSI0, 0l, 0x0cL, &dx_ssi_563, "0", 2L, 0xc00, 0xc00},
    {
	{"ssi1", DSP_PORT_D, 0x3fL},
	MBASE_PORTD, 0x3fl, MBASE_SSI1, IBASE_SSI1, 0l, 0x30L, &dx_ssi_563, "1", 4L, 0x3000,0x3000},
    {
	{"sci", DSP_PORT_E, 0x7L},
	MBASE_PORTE, 0x7l, MBASE_SCI, IBASE_SCI, 0l, 0xc0L, &dx_sci_563, "", 6L, 0xc000,0xc000},
    {
	{"portb", DSP_PORT_B, 0xffffL},
      M_HCR_56302, 0x0L, M_HCR_56302, 0l, 0l, 0l, &dx_portb_56302, "", 0, 0 ,0},
    {
	{"portc", DSP_PORT_C, 0x3fL},
      MCONT_PORTC, 0x0L, MBASE_PORTC, 0l, 0l, 0l, &dx_portc_563, "", 0, 0, 0},
    {
	{"portd", DSP_PORT_D, 0x3fL},
      MCONT_PORTD, 0x0L, MBASE_PORTD, 0l, 0l, 0l, &dx_portd_563, "", 0, 0,0},
    {
	{"porte", DSP_PORT_E, 0x7L},
     MCONT_PORTE, 0x0L, MBASE_PORTE, 0l, 0l, 0l, &dx_porte_563, "", 0, 0, 0},

   /*
    * NOTE: the DSP_PS_OFFSET constant in gsig563.h should get the entry-index
    *       of the prescaler peripheral in this record */
    {
	{"prescaler", 0, 0},
	MBASE_PRESCALER, 0l, MBASE_PRESCALER, 0l, 0l, 0x300L, &dx_prescaler_563, "", 0l, 0, 0},
    {
	{"timer0", DSP_PORT_M, DSPT_PIM_TIO0_563},
	MBASE_TIMER0, 0l, MBASE_TIMER0, IBASE_TIMER0, 0l, 0x300L, &dx_timer_563, "0", 0x8L, 0x10000 ,0},
    {
	{"timer1", DSP_PORT_M, DSPT_PIM_TIO1_563},
	MBASE_TIMER1, 0l, MBASE_TIMER1, IBASE_TIMER1, 0l, 0x300L, &dx_timer_563, "1", 0x8L, 0x20000, 0},
    {
	{"timer2", DSP_PORT_M, DSPT_PIM_TIO2_563},
	MBASE_TIMER2, 0l, MBASE_TIMER2, IBASE_TIMER2, 0l, 0x300L, &dx_timer_563, "2", 0x8L, 0x40000, 0},
#if ADSx
    {
        {"once", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_once_563, "", 0, 0, 0},
    {
        {"jtag", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_jtag_563, "", 0, 0, 0},
#endif    
    {
	{"count", 0, 0L},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_count_563, "", 0, 0, 0},
};

struct dt_mperiph dx_periph_56305[] =
{
    {
	{"core", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_core_56305, "", 0, 0, 0, 0},
#if !ADSx
    {
	{"csim", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_csim_56305, "", 0, 0, 0, 0},
#endif
    {
	{"host", DSP_PORT_B, 0xffffffffL, DSP_PORT_B1, 0x3ffffL},
	MBASE_PORTB, 0x700000L, MBASE_HOST, IBASE_HOST, 0l, 0x3L, &dx_host_563, "", 0l, 0xf0000000l, 0xf0000000l, 0},
    {
	{"ssi0", DSP_PORT_C, 0x3fL},
	MBASE_PORTC, 0x3fL, MBASE_SSI0, IBASE_SSI0, 0l, 0x0cL, &dx_ssi_563, "0", 2L, 0xc00l, 0xc00l, 0},
    {
	{"ssi1", DSP_PORT_D, 0x3fL},
	MBASE_PORTD, 0x3fl, MBASE_SSI1, IBASE_SSI1, 0l, 0x30L, &dx_ssi_563, "1", 4L, 0x3000l,  0x3000l,0},
    {
	{"sci", DSP_PORT_E, 0x7L},
	MBASE_PORTE, 0x7l, MBASE_SCI, IBASE_SCI, 0l, 0xc0L, &dx_sci_563, "", 6L, 0xc000l, 0xc000l, 0},
    {
	{"portb", DSP_PORT_B, 0xffffL, DSP_PORT_B1, 0xffL},
      MCONT_PORTB, 0x0L, MBASE_PORTB, 0l, 0l, 0l, &dx_portb_563, "", 0, 0l, 0,0},
    {
	{"portc", DSP_PORT_C, 0x3fL},
      MCONT_PORTC, 0x0L, MBASE_PORTC, 0l, 0l, 0l, &dx_portc_563, "", 0, 0l, 0,0},
    {
	{"portd", DSP_PORT_D, 0x3fL},
      MCONT_PORTD, 0x0L, MBASE_PORTD, 0l, 0l, 0l, &dx_portd_563, "", 0, 0l, 0,0},
    {
	{"porte", DSP_PORT_E, 0x7L},
     MCONT_PORTE, 0x0L, MBASE_PORTE, 0l, 0l, 0l, &dx_porte_563, "", 0l, 0l,0,0,},

   /*
    * NOTE: the DSP_PS_OFFSET constant in gsig563.h should get the entry-index
    *       of the prescaler peripheral in this record */
    {
	{"prescaler", 0, 0},
	MBASE_PRESCALER, 0l, MBASE_PRESCALER, 0l, 0l, 0x300L, &dx_prescaler_563, "", 0l, 0l,0,0,},
    {
	{"timer0", DSP_PORT_M, DSPT_PIM_TIO0_563},
	MBASE_TIMER0, 0l, MBASE_TIMER0, IBASE_TIMER0, 0l, 0x300L, &dx_timer_563, "0", 0x8L, 0x10000L, 0x10000L, 0},
    {
	{"timer1", DSP_PORT_M, DSPT_PIM_TIO1_563},
	MBASE_TIMER1, 0l, MBASE_TIMER1, IBASE_TIMER1, 0l, 0x300L, &dx_timer_563, "1", 0x8L, 0x20000L, 0x20000L, 0},
    {
	{"timer2", DSP_PORT_M, DSPT_PIM_TIO2_563},
	MBASE_TIMER2, 0l, MBASE_TIMER2, IBASE_TIMER2, 0l, 0x300L, &dx_timer_563, "2", 0x8L, 0x40000L, 0x40000L, 0},
#if ADSx
    {
	{"once", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_once_563, "", 0, 0, 0,0},
    {
	{"jtag", 0, 0L}, 0l, 0l, 0l, 0l, 0l, 0l, &dx_jtag_563, "", 0, 0, 0,0},
#endif

    {
	{ "vcop", DSP_PORT_M, 0x0L, DSP_PORT_M, 0x0L } ,
	0L, 0L, YM_VDR_56305, I_VCOP_DREQ_56305, 0l,
	0x3000L,			/* mask value for bits used in ipr register */
	&dx_vcop_56305, "",
	12L,			/* int_mask_shift  in IPR */
	0x1e00000, /* DMA request sources spec1.2 4-12 */
	0x1e00000,
	1},
    {
	{ "ccop", DSP_PORT_M, 0x0L, DSP_PORT_M, 0x0L } ,
	0L, 0L, YM_CDFR_56305, I_CCOP_INFE_56305, 0l,
	0xc000L,
	&dx_ccop_56305, "", 
	14l,
	0x6000000,
	0x6000000,
	1},
    {
	{ "fcop", DSP_PORT_M, 0x0L, DSP_PORT_M, 0x0L } ,
	0L, 0L, YM_KDIR_56305, I_FCOP_DIBE_56305, 0l,
	0xc00L,
	&dx_fcop_56305, "", 
	10l,
	0x180000,
	0x180000,
	1},
    {
	/* name , portindex, portmask, portindex2, portmask2 */
	{"count", 0, 0L},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_count_563, "", 0, 0, 0, 0},
    };

static
struct dt_mperiph dx_periph_563blm[] =
{
    {
	{"core", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_core_563, "", 0, 0x3ff, 0xf},
#if !ADSx    
    {
	{"csim", DSP_PORT_M, 0xffffffL},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_csim_563, "", 0, 0, 0},
#endif    
    {
	{"count", 0, 0L},
	0l, 0l, 0l, 0l, 0l, 0l, &dx_count_563, "", 0, 0, 0},
};

static
struct dt_xpin xpin_56301[] =	/* includes pin name and possible second name */
{
    {"reset", NULL, NULL, DSP_PORT_M, DSPT_PIM_RESET_563, DSP56301},
    {"moda", "irqa", NULL, DSP_PORT_M, DSPT_PIM_MODA_563, DSP56301},
    {"modb", "irqb", NULL, DSP_PORT_M, DSPT_PIM_MODB_563, DSP56301},
    {"modc", "irqc", NULL, DSP_PORT_M, DSPT_PIM_MODC_563, DSP56301},
    {"modd", "irqd", NULL, DSP_PORT_M, DSPT_PIM_MODD_563, DSP56301},
    {"aa0", "ras0", NULL, DSP_PORT_M, DSPT_PIM_AA0_563, DSP56301},
    {"aa1", "ras1", NULL, DSP_PORT_M, DSPT_PIM_AA1_563, DSP56301},
    {"aa2", "ras2", NULL, DSP_PORT_M, DSPT_PIM_AA2_563, DSP56301},
    {"aa3", "ras3", NULL, DSP_PORT_M, DSPT_PIM_AA3_563, DSP56301},
    {"rd", NULL, NULL, DSP_PORT_M, DSPT_PIM_RD_563, DSP56301},
    {"wr", NULL, NULL, DSP_PORT_M, DSPT_PIM_WR_563, DSP56301},
    {"ta", NULL, NULL, DSP_PORT_M, DSPT_PIM_TA_563, DSP56301},
    {"br", NULL, NULL, DSP_PORT_M, DSPT_PIM_BR_563, DSP56301},
    {"bg", NULL, NULL, DSP_PORT_M, DSPT_PIM_BG_563, DSP56301},
    {"bb", NULL, NULL, DSP_PORT_M, DSPT_PIM_BB_563, DSP56301},
    {"bl", NULL, NULL, DSP_PORT_M, DSPT_PIM_BL_563, DSP56301},
    {"bs", NULL, NULL, DSP_PORT_M, DSPT_PIM_BS_563, DSP56301},
    {"cas", NULL, NULL, DSP_PORT_M, DSPT_PIM_CAS_563, DSP56301},
    {"bclk", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_563, DSP56301},

    /* PLL pins, not implemented */
    {"extal", NULL, NULL, DSP_PORT_X, DSPT_PIM_EXTAL_563, DSP56301},
    {"xtal", NULL, NULL, DSP_PORT_X, DSPT_PIM_XTAL_563, DSP56301},
    {"pcap", NULL, NULL, DSP_PORT_X, DSPT_PIM_PCAP_563, DSP56301},
    {"clkout", NULL, NULL, DSP_PORT_X, DSPT_PIM_CLKOUT_563, DSP56301},
    /* Note that nmi is in PORTM, not PORTX */
    {"pinit", "nmi", NULL, DSP_PORT_M, DSPT_PIM_NMI_563, DSP56301},

    /* OnCE pins, not implemented */
    {"de", NULL, NULL, DSP_PORT_X, DSPT_PIM_DE_563, DSP56301},
    {"trst", NULL, NULL, DSP_PORT_X, DSPT_PIM_TRST_563, DSP56301},
    {"tck", NULL, NULL, DSP_PORT_X, DSPT_PIM_TCK_563, DSP56301},

    {"tdi", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDI_563, DSP56301},
    {"tdo", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDO_563, DSP56301},
    {"tms", NULL, NULL, DSP_PORT_X, DSPT_PIM_TMS_563, DSP56301},

    /* Timers */
    {"tio0", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO0_563, DSP56301},
    {"tio1", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO1_563, DSP56301},
    {"tio2", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO2_563, DSP56301},

    /* SCI */
    {"pe2", "sclk", NULL, DSP_PORT_E, DSP_BIT_2, DSP56301},
    {"pe1", "txd", NULL, DSP_PORT_E, DSP_BIT_1, DSP56301},
    {"pe0", "rxd", NULL, DSP_PORT_E, DSP_BIT_0, DSP56301},

    /* SSI1 */
    {"pd5", "std1", NULL, DSP_PORT_D, DSP_BIT_5, DSP56301},
    {"pd4", "srd1", NULL, DSP_PORT_D, DSP_BIT_4, DSP56301},
    {"pd3", "sck1", NULL, DSP_PORT_D, DSP_BIT_3, DSP56301},
    {"pd2", "sc12", NULL, DSP_PORT_D, DSP_BIT_2, DSP56301},
    {"pd1", "sc11", NULL, DSP_PORT_D, DSP_BIT_1, DSP56301},
    {"pd0", "sc10", NULL, DSP_PORT_D, DSP_BIT_0, DSP56301},

    /* SSI0 */
    {"pc5", "std0", NULL, DSP_PORT_C, DSP_BIT_5, DSP56301},
    {"pc4", "srd0", NULL, DSP_PORT_C, DSP_BIT_4, DSP56301},
    {"pc3", "sck0", NULL, DSP_PORT_C, DSP_BIT_3, DSP56301},
    {"pc2", "sc02", NULL, DSP_PORT_C, DSP_BIT_2, DSP56301},
    {"pc1", "sc01", NULL, DSP_PORT_C, DSP_BIT_1, DSP56301},
    {"pc0", "sc00", NULL, DSP_PORT_C, DSP_BIT_0, DSP56301},

   /*
    *      | PCI      | UNIVERSAL
    *      | Bus      | Bus 
    */
    {"pb49", "hrst",  "hrst",  DSP_PORT_B1, DSP_BIT_17, DSP56301},
    {"pb48", "had31", "hd23",  DSP_PORT_B, DSP_BIT_31, DSP56301},
    {"pb47", "had30", "hd22", DSP_PORT_B, DSP_BIT_30, DSP56301},
    {"pb46", "had29", "hd21", DSP_PORT_B, DSP_BIT_29, DSP56301},
    {"pb45", "had28", "hd20", DSP_PORT_B, DSP_BIT_28, DSP56301},
    {"pb44", "had27", "hd19", DSP_PORT_B, DSP_BIT_27, DSP56301},
    {"pb43", "had26", "hd18", DSP_PORT_B, DSP_BIT_26, DSP56301},
    {"pb42", "had25", "hd17", DSP_PORT_B, DSP_BIT_25, DSP56301},
    {"pb41", "had24", "hd16", DSP_PORT_B, DSP_BIT_24, DSP56301},
    {"pb40", "had23", "hd15", DSP_PORT_B, DSP_BIT_23, DSP56301},
    {"pb39", "had22", "hd14", DSP_PORT_B, DSP_BIT_22, DSP56301},
    {"pb38", "had21", "hd13", DSP_PORT_B, DSP_BIT_21, DSP56301},
    {"pb37", "had20", "hd12", DSP_PORT_B, DSP_BIT_20, DSP56301},
    {"pb36", "had19", "hd11", DSP_PORT_B, DSP_BIT_19, DSP56301},
    {"pb35", "had18", "hd10", DSP_PORT_B, DSP_BIT_18, DSP56301},
    {"pb34", "had17", "hd9",  DSP_PORT_B, DSP_BIT_17, DSP56301},
    {"pb33", "had16", "hd8",  DSP_PORT_B, DSP_BIT_16, DSP56301},
    {"pb32", "hclk",   NULL,  DSP_PORT_B1, DSP_BIT_16, DSP56301},
    {"pb31", "hframe", NULL,  DSP_PORT_B1, DSP_BIT_15, DSP56301},
    {"pb30", "hidsel", "hrd", DSP_PORT_B1, DSP_BIT_14, DSP56301},
    {"pb29", "hstop",  "hwr", DSP_PORT_B1, DSP_BIT_13, DSP56301},
    {"pb28", "hserr",  "hirq", DSP_PORT_B1, DSP_BIT_12, DSP56301},
    {"pb27", "hreq",   "hta", DSP_PORT_B1, DSP_BIT_11, DSP56301},
    {"pb26", "hgnt",   "haen", DSP_PORT_B1, DSP_BIT_10, DSP56301},
    {"pb25", "hperr",  "hdrq", DSP_PORT_B1, DSP_BIT_9, DSP56301},
    {"pb24", "hpar",   "hdak", DSP_PORT_B1, DSP_BIT_8, DSP56301},
    {"pb23", "hlock",  "hbs", DSP_PORT_B1, DSP_BIT_7, DSP56301},
    {"pb22", "hdevsel","hsak", DSP_PORT_B1, DSP_BIT_6, DSP56301},
    {"pb21", "hirdy",  "hdbdr", DSP_PORT_B1, DSP_BIT_5, DSP56301},
    {"pb20", "htrdy", "hdben", DSP_PORT_B1, DSP_BIT_4, DSP56301},
    {"pb19", "hc3",    NULL,  DSP_PORT_B1, DSP_BIT_3, DSP56301},
    {"pb18", "hc2",    "ha2", DSP_PORT_B1, DSP_BIT_2, DSP56301},
    {"pb17", "hc1",    "ha1", DSP_PORT_B1, DSP_BIT_1, DSP56301},
    {"pb16", "hc0",    "ha0", DSP_PORT_B1, DSP_BIT_0, DSP56301},
    {"pb15", "had15",  "hd7", DSP_PORT_B, DSP_BIT_15, DSP56301},
    {"pb14", "had14",  "hd6", DSP_PORT_B, DSP_BIT_14, DSP56301},
    {"pb13", "had13",  "hd5", DSP_PORT_B, DSP_BIT_13, DSP56301},
    {"pb12", "had12",  "hd4", DSP_PORT_B, DSP_BIT_12, DSP56301},
    {"pb11", "had11",  "hd3", DSP_PORT_B, DSP_BIT_11, DSP56301},
    {"pb10", "had10",  "hd2", DSP_PORT_B, DSP_BIT_10, DSP56301},
    {"pb9", "had9",    "hd1", DSP_PORT_B, DSP_BIT_9, DSP56301},
    {"pb8", "had8",    "hd0", DSP_PORT_B, DSP_BIT_8, DSP56301},
    {"pb7", "had7",    "ha10", DSP_PORT_B, DSP_BIT_7, DSP56301},
    {"pb6", "had6",    "ha9", DSP_PORT_B, DSP_BIT_6, DSP56301},
    {"pb5", "had5",    "ha8", DSP_PORT_B, DSP_BIT_5, DSP56301},
    {"pb4", "had4",    "ha7", DSP_PORT_B, DSP_BIT_4, DSP56301},
    {"pb3", "had3",    "ha6", DSP_PORT_B, DSP_BIT_3, DSP56301},
    {"pb2", "had2",    "ha5", DSP_PORT_B, DSP_BIT_2, DSP56301},
    {"pb1", "had1",    "ha4", DSP_PORT_B, DSP_BIT_1, DSP56301},
    {"pb0", "had0",    "ha3", DSP_PORT_B, DSP_BIT_0, DSP56301},

    {"pa23", "a23", NULL, DSP_PORT_A, DSP_BIT_23, DSP56301},
    {"pa22", "a22", NULL, DSP_PORT_A, DSP_BIT_22, DSP56301},
    {"pa21", "a21", NULL, DSP_PORT_A, DSP_BIT_21, DSP56301},
    {"pa20", "a20", NULL, DSP_PORT_A, DSP_BIT_20, DSP56301},
    {"pa19", "a19", NULL, DSP_PORT_A, DSP_BIT_19, DSP56301},
    {"pa18", "a18", NULL, DSP_PORT_A, DSP_BIT_18, DSP56301},
    {"pa17", "a17", NULL, DSP_PORT_A, DSP_BIT_17, DSP56301},
    {"pa16", "a16", NULL, DSP_PORT_A, DSP_BIT_16, DSP56301},
    {"pa15", "a15", NULL, DSP_PORT_A, DSP_BIT_15, DSP56301},
    {"pa14", "a14", NULL, DSP_PORT_A, DSP_BIT_14, DSP56301},
    {"pa13", "a13", NULL, DSP_PORT_A, DSP_BIT_13, DSP56301},
    {"pa12", "a12", NULL, DSP_PORT_A, DSP_BIT_12, DSP56301},
    {"pa11", "a11", NULL, DSP_PORT_A, DSP_BIT_11, DSP56301},
    {"pa10", "a10", NULL, DSP_PORT_A, DSP_BIT_10, DSP56301},
    {"pa9", "a9", NULL, DSP_PORT_A, DSP_BIT_9, DSP56301},
    {"pa8", "a8", NULL, DSP_PORT_A, DSP_BIT_8, DSP56301},
    {"pa7", "a7", NULL, DSP_PORT_A, DSP_BIT_7, DSP56301},
    {"pa6", "a6", NULL, DSP_PORT_A, DSP_BIT_6, DSP56301},
    {"pa5", "a5", NULL, DSP_PORT_A, DSP_BIT_5, DSP56301},
    {"pa4", "a4", NULL, DSP_PORT_A, DSP_BIT_4, DSP56301},
    {"pa3", "a3", NULL, DSP_PORT_A, DSP_BIT_3, DSP56301},
    {"pa2", "a2", NULL, DSP_PORT_A, DSP_BIT_2, DSP56301},
    {"pa1", "a1", NULL, DSP_PORT_A, DSP_BIT_1, DSP56301},
    {"pa0", "a0", NULL, DSP_PORT_A, DSP_BIT_0, DSP56301},

    {"d23", NULL, NULL, DSP_PORT_DATA, DSP_BIT_23, DSP56301},
    {"d22", NULL, NULL, DSP_PORT_DATA, DSP_BIT_22, DSP56301},
    {"d21", NULL, NULL, DSP_PORT_DATA, DSP_BIT_21, DSP56301},
    {"d20", NULL, NULL, DSP_PORT_DATA, DSP_BIT_20, DSP56301},
    {"d19", NULL, NULL, DSP_PORT_DATA, DSP_BIT_19, DSP56301},
    {"d18", NULL, NULL, DSP_PORT_DATA, DSP_BIT_18, DSP56301},
    {"d17", NULL, NULL, DSP_PORT_DATA, DSP_BIT_17, DSP56301},
    {"d16", NULL, NULL, DSP_PORT_DATA, DSP_BIT_16, DSP56301},
    {"d15", NULL, NULL, DSP_PORT_DATA, DSP_BIT_15, DSP56301},
    {"d14", NULL, NULL, DSP_PORT_DATA, DSP_BIT_14, DSP56301},
    {"d13", NULL, NULL, DSP_PORT_DATA, DSP_BIT_13, DSP56301},
    {"d12", NULL, NULL, DSP_PORT_DATA, DSP_BIT_12, DSP56301},
    {"d11", NULL, NULL, DSP_PORT_DATA, DSP_BIT_11, DSP56301},
    {"d10", NULL, NULL, DSP_PORT_DATA, DSP_BIT_10, DSP56301},
    {"d9", NULL, NULL, DSP_PORT_DATA, DSP_BIT_9, DSP56301},
    {"d8", NULL, NULL, DSP_PORT_DATA, DSP_BIT_8, DSP56301},
    {"d7", NULL, NULL, DSP_PORT_DATA, DSP_BIT_7, DSP56301},
    {"d6", NULL, NULL, DSP_PORT_DATA, DSP_BIT_6, DSP56301},
    {"d5", NULL, NULL, DSP_PORT_DATA, DSP_BIT_5, DSP56301},
    {"d4", NULL, NULL, DSP_PORT_DATA, DSP_BIT_4, DSP56301},
    {"d3", NULL, NULL, DSP_PORT_DATA, DSP_BIT_3, DSP56301},
    {"d2", NULL, NULL, DSP_PORT_DATA, DSP_BIT_2, DSP56301},
    {"d1", NULL, NULL, DSP_PORT_DATA, DSP_BIT_1, DSP56301},
    {"d0", NULL, NULL, DSP_PORT_DATA, DSP_BIT_0, DSP56301},

};
static
struct dt_xpin xpin_56301b[] =	/* includes pin name and possible second name */
{
    {"reset", NULL, NULL, DSP_PORT_M, DSPT_PIM_RESET_563, DSP56301B},
    {"moda", "irqa", NULL, DSP_PORT_M, DSPT_PIM_MODA_563, DSP56301B},
    {"modb", "irqb", NULL, DSP_PORT_M, DSPT_PIM_MODB_563, DSP56301B},
    {"modc", "irqc", NULL, DSP_PORT_M, DSPT_PIM_MODC_563, DSP56301B},
    {"modd", "irqd", NULL, DSP_PORT_M, DSPT_PIM_MODD_563, DSP56301B},
    {"aa0", "ras0", NULL, DSP_PORT_M, DSPT_PIM_AA0_563, DSP56301B},
    {"aa1", "ras1", NULL, DSP_PORT_M, DSPT_PIM_AA1_563, DSP56301B},
    {"aa2", "ras2", NULL, DSP_PORT_M, DSPT_PIM_AA2_563, DSP56301B},
    {"aa3", "ras3", NULL, DSP_PORT_M, DSPT_PIM_AA3_563, DSP56301B},
    {"rd", NULL, NULL, DSP_PORT_M, DSPT_PIM_RD_563, DSP56301B},
    {"wr", NULL, NULL, DSP_PORT_M, DSPT_PIM_WR_563, DSP56301B},
    {"ta", NULL, NULL, DSP_PORT_M, DSPT_PIM_TA_563, DSP56301B},
    {"br", NULL, NULL, DSP_PORT_M, DSPT_PIM_BR_563, DSP56301B},
    {"bg", NULL, NULL, DSP_PORT_M, DSPT_PIM_BG_563, DSP56301B},
    {"bb", NULL, NULL, DSP_PORT_M, DSPT_PIM_BB_563, DSP56301B},
    {"bl", NULL, NULL, DSP_PORT_M, DSPT_PIM_BL_563, DSP56301B},
    {"bs", NULL, NULL, DSP_PORT_M, DSPT_PIM_BS_563, DSP56301B},
    {"cas", NULL, NULL, DSP_PORT_M, DSPT_PIM_CAS_563, DSP56301B},
    {"bclk", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_563, DSP56301B},
    {"bclk_", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_NOT_563, DSP56301B},
    {"qcim_", NULL, NULL, DSP_PORT_M, DSPT_PIM_QCIM_563, DSP56301B},
    {"qncim_", NULL, NULL, DSP_PORT_M, DSPT_PIM_QNCIM_563, DSP56301B},

    /* PLL pins, not implemented */
    {"extal", NULL, NULL, DSP_PORT_X, DSPT_PIM_EXTAL_563, DSP56301B},
    {"xtal", NULL, NULL, DSP_PORT_X, DSPT_PIM_XTAL_563, DSP56301B},
    {"pcap", NULL, NULL, DSP_PORT_X, DSPT_PIM_PCAP_563, DSP56301B},
    {"clkout", NULL, NULL, DSP_PORT_X, DSPT_PIM_CLKOUT_563, DSP56301B},
    /* Note that nmi is in PORTM, not PORTX */
    {"pinit", "nmi", NULL, DSP_PORT_M, DSPT_PIM_NMI_563, DSP56301B},

    /* OnCE pins, not implemented */
    {"de", NULL, NULL, DSP_PORT_X, DSPT_PIM_DE_563, DSP56301B},
    {"trst", NULL, NULL, DSP_PORT_X, DSPT_PIM_TRST_563, DSP56301B},
    {"tck", NULL, NULL, DSP_PORT_X, DSPT_PIM_TCK_563, DSP56301B},

    {"tdi", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDI_563, DSP56301B},
    {"tdo", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDO_563, DSP56301B},
    {"tms", NULL, NULL, DSP_PORT_X, DSPT_PIM_TMS_563, DSP56301B},

    /* Timers */
    {"tio0", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO0_563, DSP56301B},
    {"tio1", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO1_563, DSP56301B},
    {"tio2", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO2_563, DSP56301B},

    /* SCI */
    {"pe2", "sclk", NULL, DSP_PORT_E, DSP_BIT_2, DSP56301B},
    {"pe1", "txd", NULL, DSP_PORT_E, DSP_BIT_1, DSP56301B},
    {"pe0", "rxd", NULL, DSP_PORT_E, DSP_BIT_0, DSP56301B},

    /* SSI1 */
    {"pd5", "std1", NULL, DSP_PORT_D, DSP_BIT_5, DSP56301B},
    {"pd4", "srd1", NULL, DSP_PORT_D, DSP_BIT_4, DSP56301B},
    {"pd3", "sck1", NULL, DSP_PORT_D, DSP_BIT_3, DSP56301B},
    {"pd2", "sc12", NULL, DSP_PORT_D, DSP_BIT_2, DSP56301B},
    {"pd1", "sc11", NULL, DSP_PORT_D, DSP_BIT_1, DSP56301B},
    {"pd0", "sc10", NULL, DSP_PORT_D, DSP_BIT_0, DSP56301B},

    /* SSI0 */
    {"pc5", "std0", NULL, DSP_PORT_C, DSP_BIT_5, DSP56301B},
    {"pc4", "srd0", NULL, DSP_PORT_C, DSP_BIT_4, DSP56301B},
    {"pc3", "sck0", NULL, DSP_PORT_C, DSP_BIT_3, DSP56301B},
    {"pc2", "sc02", NULL, DSP_PORT_C, DSP_BIT_2, DSP56301B},
    {"pc1", "sc01", NULL, DSP_PORT_C, DSP_BIT_1, DSP56301B},
    {"pc0", "sc00", NULL, DSP_PORT_C, DSP_BIT_0, DSP56301B},

   /*
    *      | PCI      | UNIVERSAL
    *      | Bus      | Bus 
    */
    {"pb49", "hrst",  "hrst",  DSP_PORT_B1, DSP_BIT_17, DSP56301B},
    {"pb48", "had31", "hd23",  DSP_PORT_B, DSP_BIT_31, DSP56301B},
    {"pb47", "had30", "hd22", DSP_PORT_B, DSP_BIT_30, DSP56301B},
    {"pb46", "had29", "hd21", DSP_PORT_B, DSP_BIT_29, DSP56301B},
    {"pb45", "had28", "hd20", DSP_PORT_B, DSP_BIT_28, DSP56301B},
    {"pb44", "had27", "hd19", DSP_PORT_B, DSP_BIT_27, DSP56301B},
    {"pb43", "had26", "hd18", DSP_PORT_B, DSP_BIT_26, DSP56301B},
    {"pb42", "had25", "hd17", DSP_PORT_B, DSP_BIT_25, DSP56301B},
    {"pb41", "had24", "hd16", DSP_PORT_B, DSP_BIT_24, DSP56301B},
    {"pb40", "had23", "hd15", DSP_PORT_B, DSP_BIT_23, DSP56301B},
    {"pb39", "had22", "hd14", DSP_PORT_B, DSP_BIT_22, DSP56301B},
    {"pb38", "had21", "hd13", DSP_PORT_B, DSP_BIT_21, DSP56301B},
    {"pb37", "had20", "hd12", DSP_PORT_B, DSP_BIT_20, DSP56301B},
    {"pb36", "had19", "hd11", DSP_PORT_B, DSP_BIT_19, DSP56301B},
    {"pb35", "had18", "hd10", DSP_PORT_B, DSP_BIT_18, DSP56301B},
    {"pb34", "had17", "hd9",  DSP_PORT_B, DSP_BIT_17, DSP56301B},
    {"pb33", "had16", "hd8",  DSP_PORT_B, DSP_BIT_16, DSP56301B},
    {"pb32", "hclk",   NULL,  DSP_PORT_B1, DSP_BIT_16, DSP56301B},
    {"pb31", "hframe", NULL,  DSP_PORT_B1, DSP_BIT_15, DSP56301B},
    {"pb30", "hidsel", "hrd", DSP_PORT_B1, DSP_BIT_14, DSP56301B},
    {"pb29", "hstop",  "hwr", DSP_PORT_B1, DSP_BIT_13, DSP56301B},
    {"pb28", "hserr",  "hirq", DSP_PORT_B1, DSP_BIT_12, DSP56301B},
    {"pb27", "hreq",   "hta", DSP_PORT_B1, DSP_BIT_11, DSP56301B},
    {"pb26", "hgnt",   "haen", DSP_PORT_B1, DSP_BIT_10, DSP56301B},
    {"pb25", "hperr",  "hdrq", DSP_PORT_B1, DSP_BIT_9, DSP56301B},
    {"pb24", "hpar",   "hdak", DSP_PORT_B1, DSP_BIT_8, DSP56301B},
    {"pb23", "hlock",  "hbs", DSP_PORT_B1, DSP_BIT_7, DSP56301B},
    {"pb22", "hdevsel","hsak", DSP_PORT_B1, DSP_BIT_6, DSP56301B},
    {"pb21", "hirdy",  "hdbdr", DSP_PORT_B1, DSP_BIT_5, DSP56301B},
    {"pb20", "htrdy", "hdben", DSP_PORT_B1, DSP_BIT_4, DSP56301B},
    {"pb19", "hc3",    NULL,  DSP_PORT_B1, DSP_BIT_3, DSP56301B},
    {"pb18", "hc2",    "ha2", DSP_PORT_B1, DSP_BIT_2, DSP56301B},
    {"pb17", "hc1",    "ha1", DSP_PORT_B1, DSP_BIT_1, DSP56301B},
    {"pb16", "hc0",    "ha0", DSP_PORT_B1, DSP_BIT_0, DSP56301B},
    {"pb15", "had15",  "hd7", DSP_PORT_B, DSP_BIT_15, DSP56301B},
    {"pb14", "had14",  "hd6", DSP_PORT_B, DSP_BIT_14, DSP56301B},
    {"pb13", "had13",  "hd5", DSP_PORT_B, DSP_BIT_13, DSP56301B},
    {"pb12", "had12",  "hd4", DSP_PORT_B, DSP_BIT_12, DSP56301B},
    {"pb11", "had11",  "hd3", DSP_PORT_B, DSP_BIT_11, DSP56301B},
    {"pb10", "had10",  "hd2", DSP_PORT_B, DSP_BIT_10, DSP56301B},
    {"pb9", "had9",    "hd1", DSP_PORT_B, DSP_BIT_9, DSP56301B},
    {"pb8", "had8",    "hd0", DSP_PORT_B, DSP_BIT_8, DSP56301B},
    {"pb7", "had7",    "ha10", DSP_PORT_B, DSP_BIT_7, DSP56301B},
    {"pb6", "had6",    "ha9", DSP_PORT_B, DSP_BIT_6, DSP56301B},
    {"pb5", "had5",    "ha8", DSP_PORT_B, DSP_BIT_5, DSP56301B},
    {"pb4", "had4",    "ha7", DSP_PORT_B, DSP_BIT_4, DSP56301B},
    {"pb3", "had3",    "ha6", DSP_PORT_B, DSP_BIT_3, DSP56301B},
    {"pb2", "had2",    "ha5", DSP_PORT_B, DSP_BIT_2, DSP56301B},
    {"pb1", "had1",    "ha4", DSP_PORT_B, DSP_BIT_1, DSP56301B},
    {"pb0", "had0",    "ha3", DSP_PORT_B, DSP_BIT_0, DSP56301B},

    {"pa23", "a23", NULL, DSP_PORT_A, DSP_BIT_23, DSP56301B},
    {"pa22", "a22", NULL, DSP_PORT_A, DSP_BIT_22, DSP56301B},
    {"pa21", "a21", NULL, DSP_PORT_A, DSP_BIT_21, DSP56301B},
    {"pa20", "a20", NULL, DSP_PORT_A, DSP_BIT_20, DSP56301B},
    {"pa19", "a19", NULL, DSP_PORT_A, DSP_BIT_19, DSP56301B},
    {"pa18", "a18", NULL, DSP_PORT_A, DSP_BIT_18, DSP56301B},
    {"pa17", "a17", NULL, DSP_PORT_A, DSP_BIT_17, DSP56301B},
    {"pa16", "a16", NULL, DSP_PORT_A, DSP_BIT_16, DSP56301B},
    {"pa15", "a15", NULL, DSP_PORT_A, DSP_BIT_15, DSP56301B},
    {"pa14", "a14", NULL, DSP_PORT_A, DSP_BIT_14, DSP56301B},
    {"pa13", "a13", NULL, DSP_PORT_A, DSP_BIT_13, DSP56301B},
    {"pa12", "a12", NULL, DSP_PORT_A, DSP_BIT_12, DSP56301B},
    {"pa11", "a11", NULL, DSP_PORT_A, DSP_BIT_11, DSP56301B},
    {"pa10", "a10", NULL, DSP_PORT_A, DSP_BIT_10, DSP56301B},
    {"pa9", "a9", NULL, DSP_PORT_A, DSP_BIT_9, DSP56301B},
    {"pa8", "a8", NULL, DSP_PORT_A, DSP_BIT_8, DSP56301B},
    {"pa7", "a7", NULL, DSP_PORT_A, DSP_BIT_7, DSP56301B},
    {"pa6", "a6", NULL, DSP_PORT_A, DSP_BIT_6, DSP56301B},
    {"pa5", "a5", NULL, DSP_PORT_A, DSP_BIT_5, DSP56301B},
    {"pa4", "a4", NULL, DSP_PORT_A, DSP_BIT_4, DSP56301B},
    {"pa3", "a3", NULL, DSP_PORT_A, DSP_BIT_3, DSP56301B},
    {"pa2", "a2", NULL, DSP_PORT_A, DSP_BIT_2, DSP56301B},
    {"pa1", "a1", NULL, DSP_PORT_A, DSP_BIT_1, DSP56301B},
    {"pa0", "a0", NULL, DSP_PORT_A, DSP_BIT_0, DSP56301B},

    {"d23", NULL, NULL, DSP_PORT_DATA, DSP_BIT_23, DSP56301B},
    {"d22", NULL, NULL, DSP_PORT_DATA, DSP_BIT_22, DSP56301B},
    {"d21", NULL, NULL, DSP_PORT_DATA, DSP_BIT_21, DSP56301B},
    {"d20", NULL, NULL, DSP_PORT_DATA, DSP_BIT_20, DSP56301B},
    {"d19", NULL, NULL, DSP_PORT_DATA, DSP_BIT_19, DSP56301B},
    {"d18", NULL, NULL, DSP_PORT_DATA, DSP_BIT_18, DSP56301B},
    {"d17", NULL, NULL, DSP_PORT_DATA, DSP_BIT_17, DSP56301B},
    {"d16", NULL, NULL, DSP_PORT_DATA, DSP_BIT_16, DSP56301B},
    {"d15", NULL, NULL, DSP_PORT_DATA, DSP_BIT_15, DSP56301B},
    {"d14", NULL, NULL, DSP_PORT_DATA, DSP_BIT_14, DSP56301B},
    {"d13", NULL, NULL, DSP_PORT_DATA, DSP_BIT_13, DSP56301B},
    {"d12", NULL, NULL, DSP_PORT_DATA, DSP_BIT_12, DSP56301B},
    {"d11", NULL, NULL, DSP_PORT_DATA, DSP_BIT_11, DSP56301B},
    {"d10", NULL, NULL, DSP_PORT_DATA, DSP_BIT_10, DSP56301B},
    {"d9", NULL, NULL, DSP_PORT_DATA, DSP_BIT_9, DSP56301B},
    {"d8", NULL, NULL, DSP_PORT_DATA, DSP_BIT_8, DSP56301B},
    {"d7", NULL, NULL, DSP_PORT_DATA, DSP_BIT_7, DSP56301B},
    {"d6", NULL, NULL, DSP_PORT_DATA, DSP_BIT_6, DSP56301B},
    {"d5", NULL, NULL, DSP_PORT_DATA, DSP_BIT_5, DSP56301B},
    {"d4", NULL, NULL, DSP_PORT_DATA, DSP_BIT_4, DSP56301B},
    {"d3", NULL, NULL, DSP_PORT_DATA, DSP_BIT_3, DSP56301B},
    {"d2", NULL, NULL, DSP_PORT_DATA, DSP_BIT_2, DSP56301B},
    {"d1", NULL, NULL, DSP_PORT_DATA, DSP_BIT_1, DSP56301B},
    {"d0", NULL, NULL, DSP_PORT_DATA, DSP_BIT_0, DSP56301B},

};
static
struct dt_xpin xpin_56302[] =	/* includes pin name and possible second name */
{
    {"reset", NULL, NULL, DSP_PORT_M, DSPT_PIM_RESET_563, DSP56302|DSP56303},
    {"moda", "irqa", NULL, DSP_PORT_M, DSPT_PIM_MODA_563, DSP56302|DSP56303},
    {"modb", "irqb", NULL, DSP_PORT_M, DSPT_PIM_MODB_563, DSP56302|DSP56303},
    {"modc", "irqc", NULL, DSP_PORT_M, DSPT_PIM_MODC_563, DSP56302|DSP56303},
    {"modd", "irqd", NULL, DSP_PORT_M, DSPT_PIM_MODD_563, DSP56302|DSP56303},
    {"aa0", "ras0", NULL, DSP_PORT_M, DSPT_PIM_AA0_563, DSP56302|DSP56303},
    {"aa1", "ras1", NULL, DSP_PORT_M, DSPT_PIM_AA1_563, DSP56302|DSP56303},
    {"aa2", "ras2", NULL, DSP_PORT_M, DSPT_PIM_AA2_563, DSP56302|DSP56303},
    {"aa3", "ras3", NULL, DSP_PORT_M, DSPT_PIM_AA3_563, DSP56302|DSP56303},
    {"rd", NULL, NULL, DSP_PORT_M, DSPT_PIM_RD_563, DSP56302|DSP56303},
    {"wr", NULL, NULL, DSP_PORT_M, DSPT_PIM_WR_563, DSP56302|DSP56303},
    {"ta", NULL, NULL, DSP_PORT_M, DSPT_PIM_TA_563, DSP56302|DSP56303},
    {"br", NULL, NULL, DSP_PORT_M, DSPT_PIM_BR_563, DSP56302|DSP56303},
    {"bg", NULL, NULL, DSP_PORT_M, DSPT_PIM_BG_563, DSP56302|DSP56303},
    {"bb", NULL, NULL, DSP_PORT_M, DSPT_PIM_BB_563, DSP56302|DSP56303},
    {"cas", NULL, NULL, DSP_PORT_M, DSPT_PIM_CAS_563, DSP56302|DSP56303},
    {"bclk", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_563, DSP56302|DSP56303},
    {"bclk_", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_NOT_563, DSP56302|DSP56303},

    /* PLL pins, not implemented */
    {"extal", NULL, NULL, DSP_PORT_X, DSPT_PIM_EXTAL_563, DSP56302|DSP56303},
    {"xtal", NULL, NULL, DSP_PORT_X, DSPT_PIM_XTAL_563, DSP56302|DSP56303},
    {"pcap", NULL, NULL, DSP_PORT_X, DSPT_PIM_PCAP_563, DSP56302|DSP56303},
    {"clkout", NULL, NULL, DSP_PORT_X, DSPT_PIM_CLKOUT_563, DSP56302|DSP56303},
    /* Note that nmi is in PORTM, not PORTX */
    {"pinit", "nmi", NULL, DSP_PORT_M, DSPT_PIM_NMI_563, DSP56302|DSP56303},

    /* OnCE pins, not implemented */
    {"de", NULL, NULL, DSP_PORT_X, DSPT_PIM_DE_563, DSP56302|DSP56303},
    {"trst", NULL, NULL, DSP_PORT_X, DSPT_PIM_TRST_563, DSP56302|DSP56303},
    {"tck", NULL, NULL, DSP_PORT_X, DSPT_PIM_TCK_563, DSP56302|DSP56303},

    {"tdi", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDI_563, DSP56302|DSP56303},
    {"tdo", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDO_563, DSP56302|DSP56303},
    {"tms", NULL, NULL, DSP_PORT_X, DSPT_PIM_TMS_563, DSP56302|DSP56303},

    /* Timers */
    {"tio0", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO0_563, DSP56302|DSP56303},
    {"tio1", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO1_563, DSP56302|DSP56303},
    {"tio2", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO2_563, DSP56302|DSP56303},

    /* SCI */
    {"pe2", "sclk", NULL, DSP_PORT_E, DSP_BIT_2, DSP56302|DSP56303},
    {"pe1", "txd", NULL, DSP_PORT_E, DSP_BIT_1, DSP56302|DSP56303},
    {"pe0", "rxd", NULL, DSP_PORT_E, DSP_BIT_0, DSP56302|DSP56303},

    /* SSI1 */
    {"pd5", "std1", NULL, DSP_PORT_D, DSP_BIT_5, DSP56302|DSP56303},
    {"pd4", "srd1", NULL, DSP_PORT_D, DSP_BIT_4, DSP56302|DSP56303},
    {"pd3", "sck1", NULL, DSP_PORT_D, DSP_BIT_3, DSP56302|DSP56303},
    {"pd2", "sc12", NULL, DSP_PORT_D, DSP_BIT_2, DSP56302|DSP56303},
    {"pd1", "sc11", NULL, DSP_PORT_D, DSP_BIT_1, DSP56302|DSP56303},
    {"pd0", "sc10", NULL, DSP_PORT_D, DSP_BIT_0, DSP56302|DSP56303},

    /* SSI0 */
    {"pc5", "std0", NULL, DSP_PORT_C, DSP_BIT_5, DSP56302|DSP56303},
    {"pc4", "srd0", NULL, DSP_PORT_C, DSP_BIT_4, DSP56302|DSP56303},
    {"pc3", "sck0", NULL, DSP_PORT_C, DSP_BIT_3, DSP56302|DSP56303},
    {"pc2", "sc02", NULL, DSP_PORT_C, DSP_BIT_2, DSP56302|DSP56303},
    {"pc1", "sc01", NULL, DSP_PORT_C, DSP_BIT_1, DSP56302|DSP56303},
    {"pc0", "sc00", NULL, DSP_PORT_C, DSP_BIT_0, DSP56302|DSP56303},

    {"pb15", "hack",  "hrrq", DSP_PORT_B, DSP_BIT_15, DSP56302|DSP56303},
    {"pb14", "hreq",  "htrq", DSP_PORT_B, DSP_BIT_14, DSP56302|DSP56303},
    {"pb13", "hcs",   "ha10", DSP_PORT_B, DSP_BIT_13, DSP56302|DSP56303},
    {"pb12", "hds",   "hwr", DSP_PORT_B, DSP_BIT_12, DSP56302|DSP56303},
    {"pb11", "hrw",   "hrd", DSP_PORT_B, DSP_BIT_11, DSP56302|DSP56303},
    {"pb10", "ha2",   "ha9", DSP_PORT_B, DSP_BIT_10, DSP56302|DSP56303},
    {"pb9", "ha1",    "ha8", DSP_PORT_B, DSP_BIT_9, DSP56302|DSP56303},
    {"pb8", "ha0",    "has", DSP_PORT_B, DSP_BIT_8, DSP56302|DSP56303},
    {"pb7", "had7",    NULL, DSP_PORT_B, DSP_BIT_7, DSP56302|DSP56303},
    {"pb6", "had6",    NULL, DSP_PORT_B, DSP_BIT_6, DSP56302|DSP56303},
    {"pb5", "had5",    NULL, DSP_PORT_B, DSP_BIT_5, DSP56302|DSP56303},
    {"pb4", "had4",    NULL, DSP_PORT_B, DSP_BIT_4, DSP56302|DSP56303},
    {"pb3", "had3",    NULL, DSP_PORT_B, DSP_BIT_3, DSP56302|DSP56303},
    {"pb2", "had2",    NULL, DSP_PORT_B, DSP_BIT_2, DSP56302|DSP56303},
    {"pb1", "had1",    NULL, DSP_PORT_B, DSP_BIT_1, DSP56302|DSP56303},
    {"pb0", "had0",    NULL, DSP_PORT_B, DSP_BIT_0, DSP56302|DSP56303},

    {"pa17", "a17", NULL, DSP_PORT_A, DSP_BIT_17, DSP56302|DSP56303},
    {"pa16", "a16", NULL, DSP_PORT_A, DSP_BIT_16, DSP56302|DSP56303},
    {"pa15", "a15", NULL, DSP_PORT_A, DSP_BIT_15, DSP56302|DSP56303},
    {"pa14", "a14", NULL, DSP_PORT_A, DSP_BIT_14, DSP56302|DSP56303},
    {"pa13", "a13", NULL, DSP_PORT_A, DSP_BIT_13, DSP56302|DSP56303},
    {"pa12", "a12", NULL, DSP_PORT_A, DSP_BIT_12, DSP56302|DSP56303},
    {"pa11", "a11", NULL, DSP_PORT_A, DSP_BIT_11, DSP56302|DSP56303},
    {"pa10", "a10", NULL, DSP_PORT_A, DSP_BIT_10, DSP56302|DSP56303},
    {"pa9", "a9", NULL, DSP_PORT_A, DSP_BIT_9, DSP56302|DSP56303},
    {"pa8", "a8", NULL, DSP_PORT_A, DSP_BIT_8, DSP56302|DSP56303},
    {"pa7", "a7", NULL, DSP_PORT_A, DSP_BIT_7, DSP56302|DSP56303},
    {"pa6", "a6", NULL, DSP_PORT_A, DSP_BIT_6, DSP56302|DSP56303},
    {"pa5", "a5", NULL, DSP_PORT_A, DSP_BIT_5, DSP56302|DSP56303},
    {"pa4", "a4", NULL, DSP_PORT_A, DSP_BIT_4, DSP56302|DSP56303},
    {"pa3", "a3", NULL, DSP_PORT_A, DSP_BIT_3, DSP56302|DSP56303},
    {"pa2", "a2", NULL, DSP_PORT_A, DSP_BIT_2, DSP56302|DSP56303},
    {"pa1", "a1", NULL, DSP_PORT_A, DSP_BIT_1, DSP56302|DSP56303},
    {"pa0", "a0", NULL, DSP_PORT_A, DSP_BIT_0, DSP56302|DSP56303},

    {"d23", NULL, NULL, DSP_PORT_DATA, DSP_BIT_23, DSP56302|DSP56303},
    {"d22", NULL, NULL, DSP_PORT_DATA, DSP_BIT_22, DSP56302|DSP56303},
    {"d21", NULL, NULL, DSP_PORT_DATA, DSP_BIT_21, DSP56302|DSP56303},
    {"d20", NULL, NULL, DSP_PORT_DATA, DSP_BIT_20, DSP56302|DSP56303},
    {"d19", NULL, NULL, DSP_PORT_DATA, DSP_BIT_19, DSP56302|DSP56303},
    {"d18", NULL, NULL, DSP_PORT_DATA, DSP_BIT_18, DSP56302|DSP56303},
    {"d17", NULL, NULL, DSP_PORT_DATA, DSP_BIT_17, DSP56302|DSP56303},
    {"d16", NULL, NULL, DSP_PORT_DATA, DSP_BIT_16, DSP56302|DSP56303},
    {"d15", NULL, NULL, DSP_PORT_DATA, DSP_BIT_15, DSP56302|DSP56303},
    {"d14", NULL, NULL, DSP_PORT_DATA, DSP_BIT_14, DSP56302|DSP56303},
    {"d13", NULL, NULL, DSP_PORT_DATA, DSP_BIT_13, DSP56302|DSP56303},
    {"d12", NULL, NULL, DSP_PORT_DATA, DSP_BIT_12, DSP56302|DSP56303},
    {"d11", NULL, NULL, DSP_PORT_DATA, DSP_BIT_11, DSP56302|DSP56303},
    {"d10", NULL, NULL, DSP_PORT_DATA, DSP_BIT_10, DSP56302|DSP56303},
    {"d9", NULL, NULL, DSP_PORT_DATA, DSP_BIT_9, DSP56302|DSP56303},
    {"d8", NULL, NULL, DSP_PORT_DATA, DSP_BIT_8, DSP56302|DSP56303},
    {"d7", NULL, NULL, DSP_PORT_DATA, DSP_BIT_7, DSP56302|DSP56303},
    {"d6", NULL, NULL, DSP_PORT_DATA, DSP_BIT_6, DSP56302|DSP56303},
    {"d5", NULL, NULL, DSP_PORT_DATA, DSP_BIT_5, DSP56302|DSP56303},
    {"d4", NULL, NULL, DSP_PORT_DATA, DSP_BIT_4, DSP56302|DSP56303},
    {"d3", NULL, NULL, DSP_PORT_DATA, DSP_BIT_3, DSP56302|DSP56303},
    {"d2", NULL, NULL, DSP_PORT_DATA, DSP_BIT_2, DSP56302|DSP56303},
    {"d1", NULL, NULL, DSP_PORT_DATA, DSP_BIT_1, DSP56302|DSP56303},
    {"d0", NULL, NULL, DSP_PORT_DATA, DSP_BIT_0, DSP56302|DSP56303},

};

static
struct dt_xpin xpin_56305[] =	/* includes pin name and possible second name */
{
    { "reset", NULL, NULL, DSP_PORT_M, DSPT_PIM_RESET_563, DSP56301 } ,
    { "moda", "irqa", NULL, DSP_PORT_M, DSPT_PIM_MODA_563, DSP56301 } ,
    { "modb", "irqb", NULL, DSP_PORT_M, DSPT_PIM_MODB_563, DSP56301 } ,
    { "modc", "irqc", NULL, DSP_PORT_M, DSPT_PIM_MODC_563, DSP56301 },
    { "modd", "irqd", NULL, DSP_PORT_M, DSPT_PIM_MODD_563, DSP56301 } ,
    { "aa0", "ras0", NULL, DSP_PORT_M, DSPT_PIM_AA0_563, DSP56301 } ,
    { "aa1", "ras1", NULL, DSP_PORT_M, DSPT_PIM_AA1_563, DSP56301 } ,
    { "aa2", "ras2", NULL, DSP_PORT_M, DSPT_PIM_AA2_563, DSP56301 } ,
    { "aa3", "ras3", NULL, DSP_PORT_M, DSPT_PIM_AA3_563, DSP56301 } ,
    { "rd", NULL, NULL, DSP_PORT_M, DSPT_PIM_RD_563, DSP56301 } ,
    { "wr", NULL, NULL, DSP_PORT_M, DSPT_PIM_WR_563, DSP56301 } ,
    { "ta", NULL, NULL, DSP_PORT_M, DSPT_PIM_TA_563, DSP56301 } ,
    { "br", NULL, NULL, DSP_PORT_M, DSPT_PIM_BR_563, DSP56301 } ,
    { "bg", NULL, NULL, DSP_PORT_M, DSPT_PIM_BG_563, DSP56301 } ,
    { "bb", NULL, NULL, DSP_PORT_M, DSPT_PIM_BB_563, DSP56301 } ,
    { "bl", NULL, NULL, DSP_PORT_M, DSPT_PIM_BL_563, DSP56301 } ,
    { "bs", NULL, NULL, DSP_PORT_M, DSPT_PIM_BS_563, DSP56301 } ,
    { "cas", NULL, NULL, DSP_PORT_M, DSPT_PIM_CAS_563, DSP56301 } ,
    { "bclk", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_563, DSP56301 } ,
    { "bclk_", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_NOT_563, DSP56301 } ,
    { "qcim_", NULL, NULL, DSP_PORT_M, DSPT_PIM_QCIM_563, DSP56301},
    { "qncim_", NULL, NULL, DSP_PORT_M, DSPT_PIM_QNCIM_563, DSP56301},

    /* PLL pins, not implemented */
    { "extal", NULL, NULL, DSP_PORT_X, DSPT_PIM_EXTAL_563, DSP56301 } ,
    { "xtal", NULL, NULL, DSP_PORT_X, DSPT_PIM_XTAL_563, DSP56301 } ,
    { "pcap", NULL, NULL, DSP_PORT_X, DSPT_PIM_PCAP_563, DSP56301 } ,
    { "clkout", NULL, NULL, DSP_PORT_X, DSPT_PIM_CLKOUT_563, DSP56301 } ,
    /* Note that nmi is in PORTM, not PORTX */
    { "pinit", "nmi", NULL, DSP_PORT_M, DSPT_PIM_NMI_563, DSP56301 } ,

    /* OnCE pins, not implemented */
    { "de", NULL, NULL, DSP_PORT_X, DSPT_PIM_DE_563, DSP56301 } ,
    { "trst", NULL, NULL, DSP_PORT_X, DSPT_PIM_TRST_563, DSP56301 } ,
    { "tck", NULL, NULL, DSP_PORT_X, DSPT_PIM_TCK_563, DSP56301 } ,

    { "tdi", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDI_563, DSP56301 } ,
    { "tdo", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDO_563, DSP56301 } ,
    { "tms", NULL, NULL, DSP_PORT_X, DSPT_PIM_TMS_563, DSP56301 } ,

    /* Timers */
    { "tio0", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO0_563, DSP56301 } ,
    { "tio1", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO1_563, DSP56301 } ,
    { "tio2", NULL, NULL, DSP_PORT_M, DSPT_PIM_TIO2_563, DSP56301 } ,

    /* SCI */
    { "pe2", "sclk", NULL, DSP_PORT_E, DSP_BIT_2, DSP56301 } ,
    { "pe1", "txd", NULL, DSP_PORT_E, DSP_BIT_1, DSP56301 } ,
    { "pe0", "rxd", NULL, DSP_PORT_E, DSP_BIT_0, DSP56301 } ,

    /* SSI1 */
    { "pd5", "std1", NULL, DSP_PORT_D, DSP_BIT_5, DSP56301 } ,
    { "pd4", "srd1", NULL, DSP_PORT_D, DSP_BIT_4, DSP56301 } ,
    { "pd3", "sck1", NULL, DSP_PORT_D, DSP_BIT_3, DSP56301 } ,
    { "pd2", "sc12", NULL, DSP_PORT_D, DSP_BIT_2, DSP56301 } ,
    { "pd1", "sc11", NULL, DSP_PORT_D, DSP_BIT_1, DSP56301 } ,
    { "pd0", "sc10", NULL, DSP_PORT_D, DSP_BIT_0, DSP56301 } ,

    /* SSI0 */
    { "pc5", "std0", NULL, DSP_PORT_C, DSP_BIT_5, DSP56301 } ,
    { "pc4", "srd0", NULL, DSP_PORT_C, DSP_BIT_4, DSP56301 } ,
    { "pc3", "sck0", NULL, DSP_PORT_C, DSP_BIT_3, DSP56301 } ,
    { "pc2", "sc02", NULL, DSP_PORT_C, DSP_BIT_2, DSP56301 } ,
    { "pc1", "sc01", NULL, DSP_PORT_C, DSP_BIT_1, DSP56301 } ,
    { "pc0", "sc00", NULL, DSP_PORT_C, DSP_BIT_0, DSP56301 } ,

    /*
       *      | PCI      | UNIVERSAL
       *      | Bus      | Bus 
     */
    { "pb49", "hrst", "hrst", DSP_PORT_B1, DSP_BIT_17, DSP56301 } ,
    { "pb48", "had31", "hd23", DSP_PORT_B, DSP_BIT_31, DSP56301 } ,
    { "pb47", "had30", "hd22", DSP_PORT_B, DSP_BIT_30, DSP56301 } ,
    { "pb46", "had29", "hd21", DSP_PORT_B, DSP_BIT_29, DSP56301 } ,
    { "pb45", "had28", "hd20", DSP_PORT_B, DSP_BIT_28, DSP56301 } ,
    { "pb44", "had27", "hd19", DSP_PORT_B, DSP_BIT_27, DSP56301 } ,
    { "pb43", "had26", "hd18", DSP_PORT_B, DSP_BIT_26, DSP56301 } ,
    { "pb42", "had25", "hd17", DSP_PORT_B, DSP_BIT_25, DSP56301 } ,
    { "pb41", "had24", "hd16", DSP_PORT_B, DSP_BIT_24, DSP56301 } ,
    { "pb40", "had23", "hd15", DSP_PORT_B, DSP_BIT_23, DSP56301 } ,
    { "pb39", "had22", "hd14", DSP_PORT_B, DSP_BIT_22, DSP56301 } ,
    { "pb38", "had21", "hd13", DSP_PORT_B, DSP_BIT_21, DSP56301 } ,
    { "pb37", "had20", "hd12", DSP_PORT_B, DSP_BIT_20, DSP56301 } ,
    { "pb36", "had19", "hd11", DSP_PORT_B, DSP_BIT_19, DSP56301 } ,
    { "pb35", "had18", "hd10", DSP_PORT_B, DSP_BIT_18, DSP56301 } ,
    { "pb34", "had17", "hd9", DSP_PORT_B, DSP_BIT_17, DSP56301 } ,
    { "pb33", "had16", "hd8", DSP_PORT_B, DSP_BIT_16, DSP56301 } ,
    { "pb32", "hclk", NULL, DSP_PORT_B1, DSP_BIT_16, DSP56301 } ,
    { "pb31", "hframe", NULL, DSP_PORT_B1, DSP_BIT_15, DSP56301 } ,
    { "pb30", "hidsel", "hrd", DSP_PORT_B1, DSP_BIT_14, DSP56301 } ,
    { "pb29", "hstop", "hwr", DSP_PORT_B1, DSP_BIT_13, DSP56301 } ,
    { "pb28", "hserr", "hirq", DSP_PORT_B1, DSP_BIT_12, DSP56301 } ,
    { "pb27", "hreq", "hta", DSP_PORT_B1, DSP_BIT_11, DSP56301 } ,
    { "pb26", "hgnt", "haen", DSP_PORT_B1, DSP_BIT_10, DSP56301 } ,
    { "pb25", "hperr", "hdrq", DSP_PORT_B1, DSP_BIT_9, DSP56301 } ,
    { "pb24", "hpar", "hdak", DSP_PORT_B1, DSP_BIT_8, DSP56301 } ,
    { "pb23", "hlock", "hbs", DSP_PORT_B1, DSP_BIT_7, DSP56301 } ,
    { "pb22", "hdevsel", "hsak", DSP_PORT_B1, DSP_BIT_6, DSP56301 } ,
    { "pb21", "hirdy", "hdbdr", DSP_PORT_B1, DSP_BIT_5, DSP56301 } ,
    { "pb20", "htrdy", "hdben", DSP_PORT_B1, DSP_BIT_4, DSP56301 } ,
    { "pb19", "hc3", NULL, DSP_PORT_B1, DSP_BIT_3, DSP56301 } ,
    { "pb18", "hc2", "ha2", DSP_PORT_B1, DSP_BIT_2, DSP56301 } ,
    { "pb17", "hc1", "ha1", DSP_PORT_B1, DSP_BIT_1, DSP56301 } ,
    { "pb16", "hc0", "ha0", DSP_PORT_B1, DSP_BIT_0, DSP56301 } ,
    { "pb15", "had15", "hd7", DSP_PORT_B, DSP_BIT_15, DSP56301 } ,
    { "pb14", "had14", "hd6", DSP_PORT_B, DSP_BIT_14, DSP56301 } ,
    { "pb13", "had13", "hd5", DSP_PORT_B, DSP_BIT_13, DSP56301 } ,
    { "pb12", "had12", "hd4", DSP_PORT_B, DSP_BIT_12, DSP56301 } ,
    { "pb11", "had11", "hd3", DSP_PORT_B, DSP_BIT_11, DSP56301 } ,
    { "pb10", "had10", "hd2", DSP_PORT_B, DSP_BIT_10, DSP56301 } ,
    { "pb9", "had9", "hd1", DSP_PORT_B, DSP_BIT_9, DSP56301 } ,
    { "pb8", "had8", "hd0", DSP_PORT_B, DSP_BIT_8, DSP56301 } ,
    { "pb7", "had7", "ha10", DSP_PORT_B, DSP_BIT_7, DSP56301 } ,
    { "pb6", "had6", "ha9", DSP_PORT_B, DSP_BIT_6, DSP56301 } ,
    { "pb5", "had5", "ha8", DSP_PORT_B, DSP_BIT_5, DSP56301 } ,
    { "pb4", "had4", "ha7", DSP_PORT_B, DSP_BIT_4, DSP56301 } ,
    { "pb3", "had3", "ha6", DSP_PORT_B, DSP_BIT_3, DSP56301 } ,
    { "pb2", "had2", "ha5", DSP_PORT_B, DSP_BIT_2, DSP56301 } ,
    { "pb1", "had1", "ha4", DSP_PORT_B, DSP_BIT_1, DSP56301 } ,
    { "pb0", "had0", "ha3", DSP_PORT_B, DSP_BIT_0, DSP56301 } ,

    { "pa23", "a23", NULL, DSP_PORT_A, DSP_BIT_23, DSP56301 } ,
    { "pa22", "a22", NULL, DSP_PORT_A, DSP_BIT_22, DSP56301 } ,
    { "pa21", "a21", NULL, DSP_PORT_A, DSP_BIT_21, DSP56301 } ,
    { "pa20", "a20", NULL, DSP_PORT_A, DSP_BIT_20, DSP56301 } ,
    { "pa19", "a19", NULL, DSP_PORT_A, DSP_BIT_19, DSP56301 } ,
    { "pa18", "a18", NULL, DSP_PORT_A, DSP_BIT_18, DSP56301 } ,
    { "pa17", "a17", NULL, DSP_PORT_A, DSP_BIT_17, DSP56301 } ,
    { "pa16", "a16", NULL, DSP_PORT_A, DSP_BIT_16, DSP56301 } ,
    { "pa15", "a15", NULL, DSP_PORT_A, DSP_BIT_15, DSP56301 } ,
    { "pa14", "a14", NULL, DSP_PORT_A, DSP_BIT_14, DSP56301 } ,
    { "pa13", "a13", NULL, DSP_PORT_A, DSP_BIT_13, DSP56301 } ,
    { "pa12", "a12", NULL, DSP_PORT_A, DSP_BIT_12, DSP56301 } ,
    { "pa11", "a11", NULL, DSP_PORT_A, DSP_BIT_11, DSP56301 } ,
    { "pa10", "a10", NULL, DSP_PORT_A, DSP_BIT_10, DSP56301 } ,
    { "pa9", "a9", NULL, DSP_PORT_A, DSP_BIT_9, DSP56301 } ,
    { "pa8", "a8", NULL, DSP_PORT_A, DSP_BIT_8, DSP56301 } ,
    { "pa7", "a7", NULL, DSP_PORT_A, DSP_BIT_7, DSP56301 } ,
    { "pa6", "a6", NULL, DSP_PORT_A, DSP_BIT_6, DSP56301 } ,
    { "pa5", "a5", NULL, DSP_PORT_A, DSP_BIT_5, DSP56301 } ,
    { "pa4", "a4", NULL, DSP_PORT_A, DSP_BIT_4, DSP56301 } ,
    { "pa3", "a3", NULL, DSP_PORT_A, DSP_BIT_3, DSP56301 } ,
    { "pa2", "a2", NULL, DSP_PORT_A, DSP_BIT_2, DSP56301 } ,
    { "pa1", "a1", NULL, DSP_PORT_A, DSP_BIT_1, DSP56301 } ,
    { "pa0", "a0", NULL, DSP_PORT_A, DSP_BIT_0, DSP56301 } ,

    { "d23", NULL, NULL, DSP_PORT_DATA, DSP_BIT_23, DSP56301 } ,
    { "d22", NULL, NULL, DSP_PORT_DATA, DSP_BIT_22, DSP56301 } ,
    { "d21", NULL, NULL, DSP_PORT_DATA, DSP_BIT_21, DSP56301 } ,
    { "d20", NULL, NULL, DSP_PORT_DATA, DSP_BIT_20, DSP56301 } ,
    { "d19", NULL, NULL, DSP_PORT_DATA, DSP_BIT_19, DSP56301 } ,
    { "d18", NULL, NULL, DSP_PORT_DATA, DSP_BIT_18, DSP56301 } ,
    { "d17", NULL, NULL, DSP_PORT_DATA, DSP_BIT_17, DSP56301 } ,
    { "d16", NULL, NULL, DSP_PORT_DATA, DSP_BIT_16, DSP56301 } ,
    { "d15", NULL, NULL, DSP_PORT_DATA, DSP_BIT_15, DSP56301 } ,
    { "d14", NULL, NULL, DSP_PORT_DATA, DSP_BIT_14, DSP56301 } ,
    { "d13", NULL, NULL, DSP_PORT_DATA, DSP_BIT_13, DSP56301 } ,
    { "d12", NULL, NULL, DSP_PORT_DATA, DSP_BIT_12, DSP56301 } ,
    { "d11", NULL, NULL, DSP_PORT_DATA, DSP_BIT_11, DSP56301 } ,
    { "d10", NULL, NULL, DSP_PORT_DATA, DSP_BIT_10, DSP56301 } ,
    { "d9", NULL, NULL, DSP_PORT_DATA, DSP_BIT_9, DSP56301 } ,
    { "d8", NULL, NULL, DSP_PORT_DATA, DSP_BIT_8, DSP56301 } ,
    { "d7", NULL, NULL, DSP_PORT_DATA, DSP_BIT_7, DSP56301 } ,
    { "d6", NULL, NULL, DSP_PORT_DATA, DSP_BIT_6, DSP56301 } ,
    { "d5", NULL, NULL, DSP_PORT_DATA, DSP_BIT_5, DSP56301 } ,
    { "d4", NULL, NULL, DSP_PORT_DATA, DSP_BIT_4, DSP56301 } ,
    { "d3", NULL, NULL, DSP_PORT_DATA, DSP_BIT_3, DSP56301 } ,
    { "d2", NULL, NULL, DSP_PORT_DATA, DSP_BIT_2, DSP56301 } ,
    { "d1", NULL, NULL, DSP_PORT_DATA, DSP_BIT_1, DSP56301 } ,
    { "d0", NULL, NULL, DSP_PORT_DATA, DSP_BIT_0, DSP56301 } ,

};

static
struct dt_xpin xpin_563blm[] =	/* includes pin name and possible second name */
{
    {"reset", NULL, NULL, DSP_PORT_M, DSPT_PIM_RESET_563, DSP563BLM},
    {"moda", "irqa", NULL, DSP_PORT_M, DSPT_PIM_MODA_563, DSP563BLM},
    {"modb", "irqb", NULL, DSP_PORT_M, DSPT_PIM_MODB_563, DSP563BLM},
    {"modc", "irqc", NULL, DSP_PORT_M, DSPT_PIM_MODC_563, DSP563BLM},
    {"modd", "irqd", NULL, DSP_PORT_M, DSPT_PIM_MODD_563, DSP563BLM},
    {"aa0", "ras0", NULL, DSP_PORT_M, DSPT_PIM_AA0_563, DSP563BLM},
    {"aa1", "ras1", NULL, DSP_PORT_M, DSPT_PIM_AA1_563, DSP563BLM},
    {"aa2", "ras2", NULL, DSP_PORT_M, DSPT_PIM_AA2_563, DSP563BLM},
    {"aa3", "ras3", NULL, DSP_PORT_M, DSPT_PIM_AA3_563, DSP563BLM},
    {"rd", NULL, NULL, DSP_PORT_M, DSPT_PIM_RD_563, DSP563BLM},
    {"wr", NULL, NULL, DSP_PORT_M, DSPT_PIM_WR_563, DSP563BLM},
    {"ta", NULL, NULL, DSP_PORT_M, DSPT_PIM_TA_563, DSP563BLM},
    {"br", NULL, NULL, DSP_PORT_M, DSPT_PIM_BR_563, DSP563BLM},
    {"bg", NULL, NULL, DSP_PORT_M, DSPT_PIM_BG_563, DSP563BLM},
    {"bb", NULL, NULL, DSP_PORT_M, DSPT_PIM_BB_563, DSP563BLM},
    {"bl", NULL, NULL, DSP_PORT_M, DSPT_PIM_BL_563, DSP563BLM},
    {"bs", NULL, NULL, DSP_PORT_M, DSPT_PIM_BS_563, DSP563BLM},
    {"cas", NULL, NULL, DSP_PORT_M, DSPT_PIM_CAS_563, DSP563BLM},
    {"bclk", NULL, NULL, DSP_PORT_M, DSPT_PIM_BCLK_563, DSP563BLM},

    /* PLL pins, not implemented */
    {"extal", NULL, NULL, DSP_PORT_X, DSPT_PIM_EXTAL_563, DSP563BLM},
    {"xtal", NULL, NULL, DSP_PORT_X, DSPT_PIM_XTAL_563, DSP563BLM},
    {"pcap", NULL, NULL, DSP_PORT_X, DSPT_PIM_PCAP_563, DSP563BLM},
    {"clkout", NULL, NULL, DSP_PORT_X, DSPT_PIM_CLKOUT_563, DSP563BLM},
    /* Note that nmi is in PORTM, not PORTX */
    {"pinit", "nmi", NULL, DSP_PORT_M, DSPT_PIM_NMI_563, DSP563BLM},

    /* OnCE pins, not implemented */
    {"de", NULL, NULL, DSP_PORT_X, DSPT_PIM_DE_563, DSP563BLM},
    {"trst", NULL, NULL, DSP_PORT_X, DSPT_PIM_TRST_563, DSP563BLM},
    {"tck", NULL, NULL, DSP_PORT_X, DSPT_PIM_TCK_563, DSP563BLM},

    {"tdi", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDI_563, DSP563BLM},
    {"tdo", NULL, NULL, DSP_PORT_X, DSPT_PIM_TDO_563, DSP563BLM},
    {"tms", NULL, NULL, DSP_PORT_X, DSPT_PIM_TMS_563, DSP563BLM},

    {"pa23", "a23", NULL, DSP_PORT_A, DSP_BIT_23, DSP563BLM},
    {"pa22", "a22", NULL, DSP_PORT_A, DSP_BIT_22, DSP563BLM},
    {"pa21", "a21", NULL, DSP_PORT_A, DSP_BIT_21, DSP563BLM},
    {"pa20", "a20", NULL, DSP_PORT_A, DSP_BIT_20, DSP563BLM},
    {"pa19", "a19", NULL, DSP_PORT_A, DSP_BIT_19, DSP563BLM},
    {"pa18", "a18", NULL, DSP_PORT_A, DSP_BIT_18, DSP563BLM},
    {"pa17", "a17", NULL, DSP_PORT_A, DSP_BIT_17, DSP563BLM},
    {"pa16", "a16", NULL, DSP_PORT_A, DSP_BIT_16, DSP563BLM},
    {"pa15", "a15", NULL, DSP_PORT_A, DSP_BIT_15, DSP563BLM},
    {"pa14", "a14", NULL, DSP_PORT_A, DSP_BIT_14, DSP563BLM},
    {"pa13", "a13", NULL, DSP_PORT_A, DSP_BIT_13, DSP563BLM},
    {"pa12", "a12", NULL, DSP_PORT_A, DSP_BIT_12, DSP563BLM},
    {"pa11", "a11", NULL, DSP_PORT_A, DSP_BIT_11, DSP563BLM},
    {"pa10", "a10", NULL, DSP_PORT_A, DSP_BIT_10, DSP563BLM},
    {"pa9", "a9", NULL, DSP_PORT_A, DSP_BIT_9, DSP563BLM},
    {"pa8", "a8", NULL, DSP_PORT_A, DSP_BIT_8, DSP563BLM},
    {"pa7", "a7", NULL, DSP_PORT_A, DSP_BIT_7, DSP563BLM},
    {"pa6", "a6", NULL, DSP_PORT_A, DSP_BIT_6, DSP563BLM},
    {"pa5", "a5", NULL, DSP_PORT_A, DSP_BIT_5, DSP563BLM},
    {"pa4", "a4", NULL, DSP_PORT_A, DSP_BIT_4, DSP563BLM},
    {"pa3", "a3", NULL, DSP_PORT_A, DSP_BIT_3, DSP563BLM},
    {"pa2", "a2", NULL, DSP_PORT_A, DSP_BIT_2, DSP563BLM},
    {"pa1", "a1", NULL, DSP_PORT_A, DSP_BIT_1, DSP563BLM},
    {"pa0", "a0", NULL, DSP_PORT_A, DSP_BIT_0, DSP563BLM},

    {"d23", NULL, NULL, DSP_PORT_DATA, DSP_BIT_23, DSP563BLM},
    {"d22", NULL, NULL, DSP_PORT_DATA, DSP_BIT_22, DSP563BLM},
    {"d21", NULL, NULL, DSP_PORT_DATA, DSP_BIT_21, DSP563BLM},
    {"d20", NULL, NULL, DSP_PORT_DATA, DSP_BIT_20, DSP563BLM},
    {"d19", NULL, NULL, DSP_PORT_DATA, DSP_BIT_19, DSP563BLM},
    {"d18", NULL, NULL, DSP_PORT_DATA, DSP_BIT_18, DSP563BLM},
    {"d17", NULL, NULL, DSP_PORT_DATA, DSP_BIT_17, DSP563BLM},
    {"d16", NULL, NULL, DSP_PORT_DATA, DSP_BIT_16, DSP563BLM},
    {"d15", NULL, NULL, DSP_PORT_DATA, DSP_BIT_15, DSP563BLM},
    {"d14", NULL, NULL, DSP_PORT_DATA, DSP_BIT_14, DSP563BLM},
    {"d13", NULL, NULL, DSP_PORT_DATA, DSP_BIT_13, DSP563BLM},
    {"d12", NULL, NULL, DSP_PORT_DATA, DSP_BIT_12, DSP563BLM},
    {"d11", NULL, NULL, DSP_PORT_DATA, DSP_BIT_11, DSP563BLM},
    {"d10", NULL, NULL, DSP_PORT_DATA, DSP_BIT_10, DSP563BLM},
    {"d9", NULL, NULL, DSP_PORT_DATA, DSP_BIT_9, DSP563BLM},
    {"d8", NULL, NULL, DSP_PORT_DATA, DSP_BIT_8, DSP563BLM},
    {"d7", NULL, NULL, DSP_PORT_DATA, DSP_BIT_7, DSP563BLM},
    {"d6", NULL, NULL, DSP_PORT_DATA, DSP_BIT_6, DSP563BLM},
    {"d5", NULL, NULL, DSP_PORT_DATA, DSP_BIT_5, DSP563BLM},
    {"d4", NULL, NULL, DSP_PORT_DATA, DSP_BIT_4, DSP563BLM},
    {"d3", NULL, NULL, DSP_PORT_DATA, DSP_BIT_3, DSP563BLM},
    {"d2", NULL, NULL, DSP_PORT_DATA, DSP_BIT_2, DSP563BLM},
    {"d1", NULL, NULL, DSP_PORT_DATA, DSP_BIT_1, DSP563BLM},
    {"d0", NULL, NULL, DSP_PORT_DATA, DSP_BIT_0, DSP563BLM},

/* pmb */
    {"mcab0",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_0, DSP563BLM } ,
    {"mcab1",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_1, DSP563BLM } ,
    {"mcab2",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_2, DSP563BLM } ,
    {"mcab3",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_3, DSP563BLM } ,
    {"mcab4",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_4, DSP563BLM } ,
    {"mcab5",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_5, DSP563BLM } ,
    {"mcab6",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_6, DSP563BLM } ,
    {"mcab7",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_7, DSP563BLM } ,
    {"mcab8",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_8, DSP563BLM } ,
    {"mcab9",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_9, DSP563BLM } ,
    {"mcab10",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_10, DSP563BLM } ,
    {"mcab11",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_11, DSP563BLM } ,
    {"mcab12",NULL, NULL, DSP_PORT_MCAB, DSP_BIT_12, DSP563BLM } ,

    { "gdb23", NULL, NULL, DSP_PORT_GDB, DSP_BIT_23, DSP563BLM } ,
    { "gdb22", NULL, NULL, DSP_PORT_GDB, DSP_BIT_22, DSP563BLM } ,
    { "gdb21", NULL, NULL, DSP_PORT_GDB, DSP_BIT_21, DSP563BLM } ,
    { "gdb20", NULL, NULL, DSP_PORT_GDB, DSP_BIT_20, DSP563BLM } ,
    { "gdb19", NULL, NULL, DSP_PORT_GDB, DSP_BIT_19, DSP563BLM } ,
    { "gdb18", NULL, NULL, DSP_PORT_GDB, DSP_BIT_18, DSP563BLM } ,
    { "gdb17", NULL, NULL, DSP_PORT_GDB, DSP_BIT_17, DSP563BLM } ,
    { "gdb16", NULL, NULL, DSP_PORT_GDB, DSP_BIT_16, DSP563BLM } ,
    { "gdb15", NULL, NULL, DSP_PORT_GDB, DSP_BIT_15, DSP563BLM } ,
    { "gdb14", NULL, NULL, DSP_PORT_GDB, DSP_BIT_14, DSP563BLM } ,
    { "gdb13", NULL, NULL, DSP_PORT_GDB, DSP_BIT_13, DSP563BLM } ,
    { "gdb12", NULL, NULL, DSP_PORT_GDB, DSP_BIT_12, DSP563BLM } ,
    { "gdb11", NULL, NULL, DSP_PORT_GDB, DSP_BIT_11, DSP563BLM } ,
    { "gdb10", NULL, NULL, DSP_PORT_GDB, DSP_BIT_10, DSP563BLM } ,
    { "gdb9", NULL, NULL, DSP_PORT_GDB, DSP_BIT_9, DSP563BLM } ,
    { "gdb8", NULL, NULL, DSP_PORT_GDB, DSP_BIT_8, DSP563BLM } ,
    { "gdb7", NULL, NULL, DSP_PORT_GDB, DSP_BIT_7, DSP563BLM } ,
    { "gdb6", NULL, NULL, DSP_PORT_GDB, DSP_BIT_6, DSP563BLM } ,
    { "gdb5", NULL, NULL, DSP_PORT_GDB, DSP_BIT_5, DSP563BLM } ,
    { "gdb4", NULL, NULL, DSP_PORT_GDB, DSP_BIT_4, DSP563BLM } ,
    { "gdb3", NULL, NULL, DSP_PORT_GDB, DSP_BIT_3, DSP563BLM } ,
    { "gdb2", NULL, NULL, DSP_PORT_GDB, DSP_BIT_2, DSP563BLM } ,
    { "gdb1", NULL, NULL, DSP_PORT_GDB, DSP_BIT_1, DSP563BLM } ,
    { "gdb0", NULL, NULL, DSP_PORT_GDB, DSP_BIT_0, DSP563BLM } ,


    { "mdab11", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_11, DSP563BLM } ,
    { "mdab10", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_10, DSP563BLM } ,
    { "mdab9", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_9, DSP563BLM } ,
    { "mdab8", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_8, DSP563BLM } ,
    { "mdab7", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_7, DSP563BLM } ,
    { "mdab6", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_6, DSP563BLM } ,
    { "mdab5", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_5, DSP563BLM } ,
    { "mdab4", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_4, DSP563BLM } ,
    { "mdab3", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_3, DSP563BLM } ,
    { "mdab2", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_2, DSP563BLM } ,
    { "mdab1", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_1, DSP563BLM } ,
    { "mdab0", NULL, NULL, DSP_PORT_MDAB, DSP_BIT_0, DSP563BLM } ,


    { "mddbn23", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_23, DSP563BLM } ,
    { "mddbn22", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_22, DSP563BLM } ,
    { "mddbn21", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_21, DSP563BLM } ,
    { "mddbn20", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_20, DSP563BLM } ,
    { "mddbn19", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_19, DSP563BLM } ,
    { "mddbn18", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_18, DSP563BLM } ,
    { "mddbn17", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_17, DSP563BLM } ,
    { "mddbn16", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_16, DSP563BLM } ,
    { "mddbn15", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_15, DSP563BLM } ,
    { "mddbn14", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_14, DSP563BLM } ,
    { "mddbn13", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_13, DSP563BLM } ,
    { "mddbn12", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_12, DSP563BLM } ,
    { "mddbn11", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_11, DSP563BLM } ,
    { "mddbn10", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_10, DSP563BLM } ,
    { "mddbn9", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_9, DSP563BLM } ,
    { "mddbn8", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_8, DSP563BLM } ,
    { "mddbn7", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_7, DSP563BLM } ,
    { "mddbn6", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_6, DSP563BLM } ,
    { "mddbn5", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_5, DSP563BLM } ,
    { "mddbn4", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_4, DSP563BLM } ,
    { "mddbn3", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_3, DSP563BLM } ,
    { "mddbn2", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_2, DSP563BLM } ,
    { "mddbn1", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_1, DSP563BLM } ,
    { "mddbn0", NULL, NULL, DSP_PORT_MDDBN, DSP_BIT_0, DSP563BLM } ,

    { "mdrqn21", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_21, DSP563BLM } ,
    { "mdrqn20", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_20, DSP563BLM } ,
    { "mdrqn19", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_19, DSP563BLM } ,
    { "mdrqn18", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_18, DSP563BLM } ,
    { "mdrqn17", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_17, DSP563BLM } ,
    { "mdrqn16", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_16, DSP563BLM } ,
    { "mdrqn15", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_15, DSP563BLM } ,
    { "mdrqn14", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_14, DSP563BLM } ,
    { "mdrqn13", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_13, DSP563BLM } ,
    { "mdrqn12", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_12, DSP563BLM } ,
    { "mdrqn11", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_11, DSP563BLM } ,
    { "mdrqn10", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_10, DSP563BLM } ,
    { "mdrqn9", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_9, DSP563BLM } ,
    { "mdrqn8", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_8, DSP563BLM } ,
    { "mdrqn7", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_7, DSP563BLM } ,
    { "mdrqn6", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_6, DSP563BLM } ,
    { "mdrqn5", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_5, DSP563BLM } ,
    { "mdrqn4", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_4, DSP563BLM } ,
    { "mdrqn3", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_3, DSP563BLM } ,
    { "mdrqn2", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_2, DSP563BLM } ,
    { "mdrqn1", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_1, DSP563BLM } ,
    { "mdrqn0", NULL, NULL, DSP_PORT_MDRQN, DSP_BIT_0, DSP563BLM } ,

    
    { "dfmren22", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_22, DSP563BLM } ,
    { "dfmren21", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_21, DSP563BLM } ,
    { "dfmren20", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_20, DSP563BLM } ,
    { "dfmren19", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_19, DSP563BLM } ,
    { "dfmren18", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_18, DSP563BLM } ,
    { "dfmren17", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_17, DSP563BLM } ,
    { "dfmren16", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_16, DSP563BLM } ,
    { "dfmren15", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_15, DSP563BLM } ,
    { "dfmren14", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_14, DSP563BLM } ,
    { "dfmren13", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_13, DSP563BLM } ,
    { "dfmren12", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_12, DSP563BLM } ,
    { "dfmren11", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_11, DSP563BLM } ,
    { "dfmren10", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_10, DSP563BLM } ,
    { "dfmren9", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_9, DSP563BLM } ,
    { "dfmren8", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_8, DSP563BLM } ,
    { "dfmren7", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_7, DSP563BLM } ,
    { "dfmren6", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_6, DSP563BLM } ,
    { "dfmren5", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_5, DSP563BLM } ,
    { "dfmren4", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_4, DSP563BLM } ,
    { "dfmren3", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_3, DSP563BLM } ,
    { "dfmren2", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_2, DSP563BLM } ,
    { "dfmren1", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_1, DSP563BLM } ,
    { "dfmren0", NULL, NULL, DSP_PORT_DFMREN, DSP_BIT_0, DSP563BLM } ,

    { "mirqn21", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_21, DSP563BLM } ,
    { "mirqn20", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_20, DSP563BLM } ,
    { "mirqn19", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_19, DSP563BLM } ,
    { "mirqn18", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_18, DSP563BLM } ,

    { "mirqn11", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_11, DSP563BLM } ,
    { "mirqn10", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_10, DSP563BLM } ,
    { "mirqn9", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_9, DSP563BLM } ,
    { "mirqn8", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_8, DSP563BLM } ,
    { "mirqn7", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_7, DSP563BLM } ,
    { "mirqn6", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_6, DSP563BLM } ,
    { "mirqn5", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_5, DSP563BLM } ,
    { "mirqn4", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_4, DSP563BLM } ,
    { "mirqn3", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_3, DSP563BLM } ,
    { "mirqn2", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_2, DSP563BLM } ,
    { "mirqn1", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_1, DSP563BLM } ,
    { "mirqn0", NULL, NULL, DSP_PORT_MIRQN, DSP_BIT_0, DSP563BLM } ,

    { "vab7", NULL, NULL, DSP_PORT_VAB, DSP_BIT_7, DSP563BLM } ,
    { "vab6", NULL, NULL, DSP_PORT_VAB, DSP_BIT_6, DSP563BLM } ,
    { "vab5", NULL, NULL, DSP_PORT_VAB, DSP_BIT_5, DSP563BLM } ,
    { "vab4", NULL, NULL, DSP_PORT_VAB, DSP_BIT_4, DSP563BLM } ,
    { "vab3", NULL, NULL, DSP_PORT_VAB, DSP_BIT_3, DSP563BLM } ,
    { "vab2", NULL, NULL, DSP_PORT_VAB, DSP_BIT_2, DSP563BLM } ,
    { "vab1", NULL, NULL, DSP_PORT_VAB, DSP_BIT_1, DSP563BLM } ,
    { "vab0", NULL, NULL, DSP_PORT_VAB, DSP_BIT_0, DSP563BLM } ,

    { "pivsse11", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_11, DSP563BLM } ,
    { "pivsse10", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_10, DSP563BLM } ,
    { "pivsse9", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_9, DSP563BLM } ,
    { "pivsse8", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_8, DSP563BLM } ,
    { "pivsse7", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_7, DSP563BLM } ,
    { "pivsse6", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_6, DSP563BLM } ,
    { "pivsse5", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_5, DSP563BLM } ,
    { "pivsse4", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_4, DSP563BLM } ,
    { "pivsse3", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_3, DSP563BLM } ,
    { "pivsse2", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_2, DSP563BLM } ,
    { "pivsse1", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_1, DSP563BLM } ,
    { "pivsse0", NULL, NULL, DSP_PORT_PIVSSE, DSP_BIT_0, DSP563BLM } ,

    {"mcselx", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCSELX_563, DSP563BLM},
    {"mcsely", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCSELY_563, DSP563BLM},
    {"mcselxe", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCSELXE_563, DSP563BLM},
    {"mcselye", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCSELYE_563, DSP563BLM},
    {"mrdinh", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MRDINH_563, DSP563BLM},

    {"mdselx", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MDSELX_563, DSP563BLM},
    {"mdsely", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MDSELY_563, DSP563BLM},
    {"mdselxe", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MDSELXE_563, DSP563BLM},
    {"mdselye", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MDSELYE_563, DSP563BLM},
    {"mdrd", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MDRD_563, DSP563BLM},

    {"mnmirq", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MNMIRQ_563, DSP563BLM},
    {"pivrd", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_PIVRD_563, DSP563BLM},
    {"pivack", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_PIVACK_563, DSP563BLM},
    {"pinmivse", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_PINMIVSE_563, DSP563BLM},
    {"bcstop", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_BCSTOP_563, DSP563BLM},
    {"gclkw", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_GCLKW_563, DSP563BLM},
    {"pires", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_PIRES_563, DSP563BLM},
    {"pilock0", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_PILOCK0_563, DSP563BLM},
    {"mcdis0", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCDIS0_563, DSP563BLM},
    {"mcdis1", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_MCDIS1_563, DSP563BLM},
    {"tsecure", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_TSECURE_563, DSP563BLM},
    {"ngtm", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_NGTM_563, DSP563BLM},
    {"nsertst", NULL, NULL, DSP_PORT_PMB, DSPT_PIM_NSERTST_563, DSP563BLM},

};

#ifndef	M24
#define	M24	0xffffff
#endif

#define		A_O_R	(DSP_MEMA_DON | DSP_MEMA_REAL)
#define		A_O_R_D	(DSP_MEMA_DON | DSP_MEMA_REAL | DSP_MEMA_DISP)
#define		A_R_D_B (DSP_MEMA_REAL | DSP_MEMA_DISP | DSP_MEMA_BRK)
#define		A_O_R_D_B (DSP_MEMA_DON | A_R_D_B)
#define		A_O_R_D_B_E (DSP_MEMA_EXT |A_O_R_D_B)
#define		A_24W1		M24, (DSP_MEMW_SIZE24 | DSP_MEMW_WRD1), 1
#define		A_48W2		M24, (DSP_MEMW_SIZE48 | DSP_MEMW_WRD2), 1
#define		A_R_P	(DSP_MEMA_ROM | DSP_MEMA_WR_PROT)
#define		A_O_P_B	(DSP_MEMA_DON | A_R_P | A_R_D_B)
#define		A_EXEC	DSP_MEMA_EXEC

#define		A_MSIZE(START,SIZE)	START,START+(SIZE)-1, SIZE
#define		A_TYPE(T1,T2)	#T1, memory_map_ ## T1, DSP_MEM_ ## T2
#define		A_ALLMEM	0l, M24, 0

#if ADSx
static unsigned long bootrom56301[1];
static unsigned long bootrom56302[1];
static unsigned long bootrom56305[1];
static unsigned long sc3_yrom56305[1];
#else
static unsigned long bootrom56301[] =
{
0x240A13, 0x0AFA02, 0xFF0087, 0x0AFA01, 0xFF0023, 0x0AFA00, 0xFF000A, 0x08F485, 
0x3E2000, 0x050C03, 0x08F485, 0x3E0000, 0x060680, 0xFF0011, 0x0A8982, 0xFF000E, 
0x084A0B, 0x0C1C10, 0x219000, 0x219100, 0x06C800, 0xFF0021, 0x060380, 0xFF0020, 
0x0A89A2, 0xFF001F, 0x0A8983, 0xFF0018, 0x00008C, 0x00008C, 0x050C04, 0x084A0B, 
0x0C1C10, 0x07588C, 0x050D16, 0x0AFA00, 0xFF0075, 0x08F485, 0x5A0000, 0x08F487, 
0x00002F, 0x0604A0, 0x08C408, 0x08C405, 0x47F400, 0x010020, 0x08F485, 0x3A0000, 
0x062080, 0xFF003C, 0x0A8982, 0xFF0032, 0x084C0B, 0x0140C6, 0x00FFFF, 0x017785, 
0x0AF0AA, 0xFF003C, 0x00008C, 0x050FD5, 0x000000, 0x0A8982, 0xFF003D, 0x084C0B, 
0x08C405, 0x08CC07, 0x08F485, 0x5A0000, 0x0604A0, 0x08C408, 0x08C405, 0x45F400, 
0x010010, 0x08F485, 0x3A0010, 0x0A8982, 0xFF004B, 0x08480B, 0x0A8982, 0xFF004E, 
0x08440B, 0x0A8982, 0xFF0051, 0x08460B, 0x0C1B4C, 0x0C1B5E, 0x219000, 0x210C00, 
0x221123, 0x06CC00, 0xFF0073, 0x0A89A2, 0xFF0061, 0x0A8983, 0xFF005B, 0x00008C, 
0x050C14, 0x08480B, 0x0A89A2, 0xFF0068, 0x0A8983, 0xFF0062, 0x00008C, 0x050C0D, 
0x08440B, 0x0A89A2, 0xFF006F, 0x0A8983, 0xFF0069, 0x00008C, 0x050C06, 0x08460B, 
0x0C1B4C, 0x0C1B5E, 0x075888, 0x07588C, 0x050C84, 0x0A8534, 0x0A8982, 0xFF0076, 
0x08480B, 0x0A8982, 0xFF0079, 0x08500B, 0x221100, 0x06C800, 0xFF0085, 0x0A89A2, 
0xFF0085, 0x0A8983, 0xFF007F, 0x00008C, 0x050C02, 0x08584B, 0x050C52, 0x0AFA01, 
0xFF00A7, 0x07F41C, 0x000302, 0x07F41B, 0x00C000, 0x07F41F, 0x000007, 0x060680, 
0xFF0097, 0x019382, 0xFF0091, 0x044A98, 0x019381, 0xFF0094, 0x04CA95, 0x0C1C10, 
0x219000, 0x219100, 0x06C800, 0xFF00A5, 0x060380, 0xFF00A4, 0x019382, 0xFF009E, 
0x044A98, 0x019381, 0xFF00A1, 0x04CA95, 0x0C1C10, 0x07588C, 0x050C12, 0x62F400, 
0xD00000, 0x08F4B8, 0xD00409, 0x060680, 0xFF00AE, 0x07DA8A, 0x0C1C10, 0x219000, 
0x219100, 0x06C800, 0xFF00B7, 0x060380, 0xFF00B6, 0x07DA8A, 0x0C1C10, 0x07588C, 
0x0000B9, 0x0AE180, 
};

static unsigned long bootrom56302[] =
{
0x240a13, 0x0afa02, 0xff0028, 0x0afa01, 0xff0009, 0x0afa00, 0xff0011, 0x0af080,
0xff0014, 0x0afa20, 0xff000e, 0x08f484, 0x005018, 0x050c09, 0x08f484, 0x000218,
0x050c06, 0x08f484, 0x001c1e, 0x050c03, 0x08f484, 0x000038, 0x0a8426, 0x0a8380,
0xff0017, 0x084806, 0x0a8380, 0xff001a, 0x085006, 0x221100, 0x06c800, 0xff0026,
0x0a83a0, 0xff0026, 0x0a8383, 0xff0020, 0x00008c, 0x050c02, 0x085846, 0x050c52,
0x0afa01, 0xff0048, 0x07f41c, 0x000302, 0x07f41b, 0x00c000, 0x07f41f, 0x000007,
0x060680, 0xff0038, 0x019382, 0xff0032, 0x044a98, 0x019381, 0xff0035, 0x04ca95,
0x0c1c10, 0x219000, 0x219100, 0x06c800, 0xff0046, 0x060380, 0xff0045, 0x019382,
0xff003f, 0x044a98, 0x019381, 0xff0042, 0x04ca95, 0x0c1c10, 0x07588c, 0x050c12,
0x62f400, 0xd00000, 0x08f4b8, 0xd00409, 0x060680, 0xff004f, 0x07da8a, 0x0c1c10,
0x219000, 0x219100, 0x06c800, 0xff0058, 0x060380, 0xff0057, 0x07da8a, 0x0c1c10,
0x07588c, 0x0000b9, 0x0ae180,
};

static unsigned long bootrom56305[] =
{
0x0AFA03, 0xFF0800, 0x240A13, 0x253E00, 0x0AFA02, 0xFF0083, 0x0AFA01, 0xFF0023, 
0x0AFA00, 0xFF000B, 0x0AC56D, 0x08C505, 0x060680, 0xFF0011, 0x0A8982, 0xFF000E, 
0x084A0B, 0x0C1C10, 0x219000, 0x219100, 0x06C800, 0xFF0021, 0x060380, 0xFF001F, 
0x0A89A2, 0xFF001E, 0x0A8983, 0xFF0018, 0x00008C, 0x050D1F, 0x084A0B, 0x0C1C10, 
0x07588C, 0x000000, 0x050D1B, 0x0AFA00, 0xFF0071, 0x2F5A00, 0x08CD05, 0x08F487, 
0x00002F, 0x0604A0, 0x08C408, 0x08C405, 0x47F400, 0x010020, 0x08F485, 0x3A0000, 
0x062080, 0xFF003B, 0x0A8982, 0xFF0032, 0x084C0B, 0x0140C6, 0x00FFFF, 0x017785, 
0x05A403, 0x00008C, 0x050FD6, 0x000000, 0x0A8982, 0xFF003C, 0x084C0B, 0x08C405, 
0x08CC07, 0x08CD05, 0x0604A0, 0x08C408, 0x08C405, 0x45F400, 0x010010, 0x08F485, 
0x3A0010, 0x0A8982, 0xFF0049, 0x08480B, 0x0A8982, 0xFF004C, 0x08440B, 0x0A8982, 
0xFF004F, 0x08460B, 0x0C1B4C, 0x0C1B5E, 0x219000, 0x210C00, 0x221123, 0x06CC00, 
0xFF006F, 0x0A89A2, 0xFF005E, 0x0A8983, 0xFF0059, 0x050C9F, 0x08480B, 0x0A89A2, 
0xFF0064, 0x0A8983, 0xFF005F, 0x050C99, 0x08440B, 0x0A89A2, 0xFF006A, 0x0A8983, 
0xFF0065, 0x050C93, 0x08460B, 0x0C1B4C, 0x0C1B5E, 0x075888, 0x07588C, 0x000000, 
0x050C8D, 0x0A8534, 0x0A8982, 0xFF0072, 0x08480B, 0x0A8982, 0xFF0075, 0x08500B, 
0x221100, 0x06C800, 0xFF0081, 0x0A89A2, 0xFF0080, 0x0A8983, 0xFF007B, 0x050C5D, 
0x08584B, 0x000000, 0x050C5B, 0x0AFA01, 0xFF00A9, 0x0AFA00, 0xFF008A, 0x08F485, 
0x261000, 0x050FC9, 0x07F41C, 0x000302, 0x07F41B, 0x00C000, 0x07F41F, 0x000007, 
0x060680, 0xFF0098, 0x019382, 0xFF0092, 0x044A98, 0x019381, 0xFF0095, 0x04CA95, 
0x0C1C10, 0x219000, 0x219100, 0x06C800, 0xFF00A7, 0x060380, 0xFF00A5, 0x019382, 
0xFF009F, 0x044A98, 0x019381, 0xFF00A2, 0x04CA95, 0x0C1C10, 0x07588C, 0x000000, 
0x050C15, 0x62F400, 0xD00000, 0x08F4B8, 0xD00409, 0x060680, 0xFF00B0, 0x07DA8A, 
0x0C1C10, 0x219000, 0x219100, 0x06C800, 0xFF00BA, 0x060380, 0xFF00B8, 0x07DA8A, 
0x0C1C10, 0x07588C, 0x000000, 0x050C02, 0x00008C, 0x0000B9, 0x0AE180, 0x000000, 
};

static unsigned long sc3_yrom56305[] =
{
0x000000, 0xC0001F, 0x40001A, 0x800005, 0x000017, 0xC00008, 0x40000D, 0x800012, 
0xC00017, 0x000008, 0x80000D, 0x400012, 0xC00000, 0x00001F, 0x80001A, 0x400005, 
0xC0001A, 0x000005, 0x800000, 0x40001F, 0xC0000D, 0x000012, 0x800017, 0x400008, 
0x00000D, 0xC00012, 0x400017, 0x800008, 0x00001A, 0xC00005, 0x400000, 0x80001F, 
0x000005, 0xE0001A, 0xA0001F, 0x400000, 0x600012, 0x80000D, 0xC00008, 0x200017, 
0xA00012, 0x40000D, 0x000008, 0xE00017, 0xC00005, 0x20001A, 0x60001F, 0x800000, 
0xE0001F, 0x000000, 0x400005, 0xA0001A, 0x800008, 0x600017, 0x200012, 0xC0000D, 
0x400008, 0xA00017, 0xE00012, 0x00000D, 0x20001F, 0xC00000, 0x800005, 0x60001A, 
0x00001F, 0xFE0000, 0x5A0005, 0xA4001A, 0x360008, 0xC80017, 0x6C0012, 0x92000D, 
0xDA0008, 0x240017, 0x800012, 0x7E000D, 0xEC001F, 0x120000, 0xB60005, 0x48001A, 
0xFE0005, 0x00001A, 0xA4001F, 0x5A0000, 0xC80012, 0x36000D, 0x920008, 0x6C0017, 
0x240012, 0xDA000D, 0x7E0008, 0x800017, 0x120005, 0xEC001A, 0x48001F, 0xB60000, 
0x00001A, 0xFC0005, 0xB40000, 0x48001F, 0x6C000D, 0x900012, 0xD80017, 0x240008, 
0xB4000D, 0x480012, 0x000017, 0xFC0008, 0xD8001A, 0x240005, 0x6C0000, 0x90001F, 
0xFC0000, 0x00001F, 0x48001A, 0xB40005, 0x900017, 0x6C0008, 0x24000D, 0xD80012, 
0x480017, 0xB40008, 0xFC000D, 0x000012, 0x240000, 0xD8001F, 0x90001A, 0x6C0005, 
0x000000, 0x000086, 0x00010C, 0x000192, 0x000218, 0x00029E, 0x0002B2, 0x000338, 
0x0003BE, 0x000444, 0x0004CA, 0x000550, 0x000564, 0x0005EA, 0x000670, 0x0006F6, 
0x00077C, 0x000802, 0x000816, 0x000013, 0x000099, 0x00011F, 0x0001A5, 0x00022B, 
0x00023F, 0x0002C5, 0x00034B, 0x0003D1, 0x000457, 0x0004DD, 0x0004F1, 0x000577, 
0x0005FD, 0x000683, 0x000709, 0x00078F, 0x0007A3, 0x000829, 0x000026, 0x0000AC, 
0x000132, 0x0001B8, 0x0001CC, 0x000252, 0x0002D8, 0x00035E, 0x0003E4, 0x00046A, 
0x00047E, 0x000504, 0x00058A, 0x000610, 0x000696, 0x00071C, 0x000730, 0x0007B6, 
0x00083C, 0x000039, 0x0000BF, 0x000145, 0x000159, 0x0001DF, 0x000265, 0x0002EB, 
0x000371, 0x0003F7, 0x00040B, 0x000491, 0x000517, 0x00059D, 0x000623, 0x0006A9, 
0x0006BD, 0x000743, 0x0007C9, 0x00084F, 0x00004C, 0x0000D2, 0x0000E6, 0x00016C, 
0x0001F2, 0x000278, 0x0002FE, 0x000384, 0x000398, 0x00041E, 0x0004A4, 0x00052A, 
0x0005B0, 0x000636, 0x00064A, 0x0006D0, 0x000756, 0x0007DC, 0x000862, 0x00005F, 
0x000073, 0x0000F9, 0x00017F, 0x000205, 0x00028B, 0x000311, 0x000325, 0x0003AB, 
0x000431, 0x0004B7, 0x00053D, 0x0005C3, 0x0005D7, 0x00065D, 0x0006E3, 0x000769, 
0x0007EF, 0x000875, 0x000000, 0x000040, 0x000080, 0x0000C0, 0x000100, 0x000140, 
0x000180, 0x0001C0, 0x000038, 0x000078, 0x0000B8, 0x0000F8, 0x000138, 0x000178, 
0x0001B8, 0x000030, 0x000070, 0x0000B0, 0x0000F0, 0x000130, 0x000170, 0x0001B0, 
0x000028, 0x000068, 0x0000A8, 0x0000E8, 0x000128, 0x000168, 0x0001A8, 0x000020, 
0x000060, 0x0000A0, 0x0000E0, 0x000120, 0x000160, 0x0001A0, 0x000018, 0x000058, 
0x000098, 0x0000D8, 0x000118, 0x000158, 0x000198, 0x000010, 0x000050, 0x000090, 
0x0000D0, 0x000110, 0x000150, 0x000190, 0x000008, 0x000048, 0x000088, 0x0000C8, 
0x000108, 0x000148, 0x000188, 0x000039, 0x000079, 0x0000B9, 0x0000F9, 0x000139, 
0x000179, 0x0001B9, 0x000031, 0x000071, 0x0000B1, 0x0000F1, 0x000131, 0x000171, 
0x0001B1, 0x000029, 0x000069, 0x0000A9, 0x0000E9, 0x000129, 0x000169, 0x0001A9, 
0x000021, 0x000061, 0x0000A1, 0x0000E1, 0x000121, 0x000161, 0x0001A1, 0x000019, 
0x000059, 0x000099, 0x0000D9, 0x000119, 0x000159, 0x000199, 0x000011, 0x000051, 
0x000091, 0x0000D1, 0x000111, 0x000151, 0x000191, 0x000009, 0x000049, 0x000089, 
0x0000C9, 0x000109, 0x000149, 0x000189, 0x000001, 0x000041, 0x000081, 0x0000C1, 
0x000101, 0x000141, 0x000181, 0x0001C1, 0x000072, 0x0000B2, 0x0000F2, 0x000132, 
0x000172, 0x0001B2, 0x00002A, 0x00006A, 0x0000AA, 0x0000EA, 0x00012A, 0x00016A, 
0x0001AA, 0x000022, 0x000062, 0x0000A2, 0x0000E2, 0x000122, 0x000162, 0x0001A2, 
0x00001A, 0x00005A, 0x00009A, 0x0000DA, 0x00011A, 0x00015A, 0x00019A, 0x000012, 
0x000052, 0x000092, 0x0000D2, 0x000112, 0x000152, 0x000192, 0x00000A, 0x00004A, 
0x00008A, 0x0000CA, 0x00010A, 0x00014A, 0x00018A, 0x000002, 0x000042, 0x000082, 
0x0000C2, 0x000102, 0x000142, 0x000182, 0x0001C2, 0x00003A, 0x00007A, 0x0000BA, 
0x0000FA, 0x00013A, 0x00017A, 0x0001BA, 0x000032, 0x0000AB, 0x0000EB, 0x00012B, 
0x00016B, 0x0001AB, 0x000023, 0x000063, 0x0000A3, 0x0000E3, 0x000123, 0x000163, 
0x0001A3, 0x00001B, 0x00005B, 0x00009B, 0x0000DB, 0x00011B, 0x00015B, 0x00019B, 
0x000013, 0x000053, 0x000093, 0x0000D3, 0x000113, 0x000153, 0x000193, 0x00000B, 
0x00004B, 0x00008B, 0x0000CB, 0x00010B, 0x00014B, 0x00018B, 0x000003, 0x000043, 
0x000083, 0x0000C3, 0x000103, 0x000143, 0x000183, 0x0001C3, 0x00003B, 0x00007B, 
0x0000BB, 0x0000FB, 0x00013B, 0x00017B, 0x0001BB, 0x000033, 0x000073, 0x0000B3, 
0x0000F3, 0x000133, 0x000173, 0x0001B3, 0x00002B, 0x00006B, 0x0000E4, 0x000124, 
0x000164, 0x0001A4, 0x00001C, 0x00005C, 0x00009C, 0x0000DC, 0x00011C, 0x00015C, 
0x00019C, 0x000014, 0x000054, 0x000094, 0x0000D4, 0x000114, 0x000154, 0x000194, 
0x00000C, 0x00004C, 0x00008C, 0x0000CC, 0x00010C, 0x00014C, 0x00018C, 0x000004, 
0x000044, 0x000084, 0x0000C4, 0x000104, 0x000144, 0x000184, 0x0001C4, 0x00003C, 
0x00007C, 0x0000BC, 0x0000FC, 0x00013C, 0x00017C, 0x0001BC, 0x000034, 0x000074, 
0x0000B4, 0x0000F4, 0x000134, 0x000174, 0x0001B4, 0x00002C, 0x00006C, 0x0000AC, 
0x0000EC, 0x00012C, 0x00016C, 0x0001AC, 0x000024, 0x000064, 0x0000A4, 0x00011D, 
0x00015D, 0x00019D, 0x000015, 0x000055, 0x000095, 0x0000D5, 0x000115, 0x000155, 
0x000195, 0x00000D, 0x00004D, 0x00008D, 0x0000CD, 0x00010D, 0x00014D, 0x00018D, 
0x000005, 0x000045, 0x000085, 0x0000C5, 0x000105, 0x000145, 0x000185, 0x0001C5, 
0x00003D, 0x00007D, 0x0000BD, 0x0000FD, 0x00013D, 0x00017D, 0x0001BD, 0x000035, 
0x000075, 0x0000B5, 0x0000F5, 0x000135, 0x000175, 0x0001B5, 0x00002D, 0x00006D, 
0x0000AD, 0x0000ED, 0x00012D, 0x00016D, 0x0001AD, 0x000025, 0x000065, 0x0000A5, 
0x0000E5, 0x000125, 0x000165, 0x0001A5, 0x00001D, 0x00005D, 0x00009D, 0x0000DD, 
0x000156, 0x000196, 0x00000E, 0x00004E, 0x00008E, 0x0000CE, 0x00010E, 0x00014E, 
0x00018E, 0x000006, 0x000046, 0x000086, 0x0000C6, 0x000106, 0x000146, 0x000186, 
0x0001C6, 0x00003E, 0x00007E, 0x0000BE, 0x0000FE, 0x00013E, 0x00017E, 0x0001BE, 
0x000036, 0x000076, 0x0000B6, 0x0000F6, 0x000136, 0x000176, 0x0001B6, 0x00002E, 
0x00006E, 0x0000AE, 0x0000EE, 0x00012E, 0x00016E, 0x0001AE, 0x000026, 0x000066, 
0x0000A6, 0x0000E6, 0x000126, 0x000166, 0x0001A6, 0x00001E, 0x00005E, 0x00009E, 
0x0000DE, 0x00011E, 0x00015E, 0x00019E, 0x000016, 0x000056, 0x000096, 0x0000D6, 
0x000116, 0x00018F, 0x000007, 0x000047, 0x000087, 0x0000C7, 0x000107, 0x000147, 
0x000187, 0x0001C7, 0x00003F, 0x00007F, 0x0000BF, 0x0000FF, 0x00013F, 0x00017F, 
0x0001BF, 0x000037, 0x000077, 0x0000B7, 0x0000F7, 0x000137, 0x000177, 0x0001B7, 
0x00002F, 0x00006F, 0x0000AF, 0x0000EF, 0x00012F, 0x00016F, 0x0001AF, 0x000027, 
0x000067, 0x0000A7, 0x0000E7, 0x000127, 0x000167, 0x0001A7, 0x00001F, 0x00005F, 
0x00009F, 0x0000DF, 0x00011F, 0x00015F, 0x00019F, 0x000017, 0x000057, 0x000097, 
0x0000D7, 0x000117, 0x000157, 0x000197, 0x00000F, 0x00004F, 0x00008F, 0x0000CF, 
0x00010F, 0x00014F, 0x000000, 0x000026, 0x00004C, 0x000072, 0x000098, 0x0000BE, 
0x000012, 0x000038, 0x00005E, 0x000084, 0x0000AA, 0x0000D0, 0x000008, 0x00002E, 
0x000054, 0x00007A, 0x0000A0, 0x0000C6, 0x00001C, 0x000042, 0x000068, 0x00008E, 
0x0000B4, 0x0000DA, 0x000004, 0x00002A, 0x000050, 0x000076, 0x00009C, 0x0000C2, 
0x000016, 0x00003C, 0x000062, 0x000088, 0x0000AE, 0x0000D4, 0x00000C, 0x000032, 
0x000058, 0x00007E, 0x0000A4, 0x0000CA, 0x000022, 0x000048, 0x00006E, 0x000094, 
0x0000BA, 0x0000E0, 0x000010, 0x000036, 0x00005C, 0x000082, 0x0000A8, 0x0000CE, 
0x000024, 0x00004A, 0x000070, 0x000096, 0x0000BC, 0x0000E2, 0x00000E, 0x000034, 
0x00005A, 0x000080, 0x0000A6, 0x0000CC, 0x000020, 0x000046, 0x00006C, 0x000092, 
0x0000B8, 0x0000DE, 0x00000A, 0x000030, 0x000056, 0x00007C, 0x0000A2, 0x0000C8, 
0x00001E, 0x000044, 0x00006A, 0x000090, 0x0000B6, 0x0000DC, 0x000006, 0x00002C, 
0x000052, 0x000078, 0x00009E, 0x0000C4, 0x000018, 0x00003E, 0x000064, 0x00008A, 
0x0000B0, 0x0000D6, 0x000002, 0x000028, 0x00004E, 0x000074, 0x00009A, 0x0000C0, 
0x00001A, 0x000040, 0x000066, 0x00008C, 0x0000B2, 0x0000D8, 0x000014, 0x00003A, 
0x000060, 0x000086, 0x0000AC, 0x0000D2, 
0x0000BF, 0x000040, 0x00002B, 0x000008, 0x000005, 0x000000, 0x000102, 0x0000C0, 
0x000041, 0x000014, 0x000009, 0x000006, 0x0000C6, 0x0000C1, 0x000042, 0x00000A, 
0x000007, 0x0000C8, 0x0000C7, 0x000044, 0x00002C, 0x00000B, 0x0000C9, 0x000045, 
0x000032, 0x000015, 0x000103, 0x0000C2, 0x000033, 0x000016, 0x0000C3, 0x000046, 
0x00002D, 0x0000C5, 0x0000C4, 0x000043, 0x000038, 0x00002E, 0x000023, 0x00001F, 
0x00001B, 0x000017, 0x00000C, 0x000047, 0x000034, 0x000083, 0x00003C, 0x0000CA, 
0x000087, 0x00004B, 0x000027, 0x000010, 0x000001, 0x0000CE, 0x00008B, 0x00004F, 
0x0000CF, 0x00008C, 0x000050, 0x0000D0, 0x00008D, 0x000051, 0x0000D1, 0x00008E, 
0x000052, 0x0000D2, 0x00008F, 0x000053, 0x0000D3, 0x000090, 0x000054, 0x0000D4, 
0x000091, 0x000055, 0x0000D5, 0x000092, 0x000056, 0x0000D6, 0x000093, 0x000057, 
0x0000D7, 0x000094, 0x000058, 0x0000D8, 0x000095, 0x000059, 0x0000D9, 0x000096, 
0x00005A, 0x0000DA, 0x000097, 0x00005B, 0x000039, 0x00002F, 0x000024, 0x000020, 
0x00001C, 0x000018, 0x00000D, 0x000048, 0x000035, 0x000084, 0x00003D, 0x0000CB, 
0x000088, 0x00004C, 0x000028, 0x000011, 0x000002, 0x0000DB, 0x000098, 0x00005C, 
0x0000DC, 0x000099, 0x00005D, 0x0000DD, 0x00009A, 0x00005E, 0x0000DE, 0x00009B, 
0x00005F, 0x0000DF, 0x00009C, 0x000060, 0x0000E0, 0x00009D, 0x000061, 0x0000E1, 
0x00009E, 0x000062, 0x0000E2, 0x00009F, 0x000063, 0x0000E3, 0x0000A0, 0x000064, 
0x0000E4, 0x0000A1, 0x000065, 0x0000E5, 0x0000A2, 0x000066, 0x0000E6, 0x0000A3, 
0x000067, 0x0000E7, 0x0000A4, 0x000068, 0x00003A, 0x000030, 0x000025, 0x000021, 
0x00001D, 0x000019, 0x00000E, 0x000049, 0x000036, 0x000085, 0x00003E, 0x0000CC, 
0x000089, 0x00004D, 0x000029, 0x000012, 0x000003, 0x0000E8, 0x0000A5, 0x000069, 
0x0000E9, 0x0000A6, 0x00006A, 0x0000EA, 0x0000A7, 0x00006B, 0x0000EB, 0x0000A8, 
0x00006C, 0x0000EC, 0x0000A9, 0x00006D, 0x0000ED, 0x0000AA, 0x00006E, 0x0000EE, 
0x0000AB, 0x00006F, 0x0000EF, 0x0000AC, 0x000070, 0x0000F0, 0x0000AD, 0x000071, 
0x0000F1, 0x0000AE, 0x000072, 0x0000F2, 0x0000AF, 0x000073, 0x0000F3, 0x0000B0, 
0x000074, 0x0000F4, 0x0000B1, 0x000075, 0x00003B, 0x000031, 0x000026, 0x000022, 
0x00001E, 0x00001A, 0x00000F, 0x00004A, 0x000037, 0x000086, 0x00003F, 0x0000CD, 
0x00008A, 0x00004E, 0x00002A, 0x000013, 0x000004, 0x0000F5, 0x0000B2, 0x000076, 
0x0000F6, 0x0000B3, 0x000077, 0x0000F7, 0x0000B4, 0x000078, 0x0000F8, 0x0000B5, 
0x000079, 0x0000F9, 0x0000B6, 0x00007A, 0x0000FA, 0x0000B7, 0x00007B, 0x0000FB, 
0x0000B8, 0x00007C, 0x0000FC, 0x0000B9, 0x00007D, 0x0000FD, 0x0000BA, 0x00007E, 
0x0000FE, 0x0000BB, 0x00007F, 0x0000FF, 0x0000BC, 0x000080, 0x000100, 0x0000BD, 
0x000081, 0x000101, 0x0000BE, 0x000082, 
0x00005C, 0x00005B, 0x000059, 0x000000, 0x000026, 0x00005A, 0x000058, 0x000057, 
0x000056, 0x000055, 0x000049, 0x000048, 0x000047, 0x000046, 0x000045, 0x000006, 
0x000050, 0x00004F, 0x00004E, 0x000007, 0x000008, 0x000009, 0x00000A, 0x00000B, 
0x000040, 0x000001, 0x00000C, 0x00000D, 0x00000E, 0x00000F, 0x000010, 0x000011, 
0x000025, 0x000027, 0x00005E, 0x00005D, 0x00003B, 0x00003A, 0x000039, 0x000038, 
0x000037, 0x000036, 0x000035, 0x000034, 0x000033, 0x000032, 0x000031, 0x000030, 
0x00002F, 0x00002E, 0x000054, 0x00004D, 0x000002, 0x000044, 0x00003F, 0x00002D, 
0x00002C, 0x00002B, 0x00002A, 0x000029, 0x000028, 0x000012, 0x000013, 0x000014, 
0x000015, 0x000016, 0x000017, 0x000018, 0x000019, 0x000053, 0x00004C, 0x000003, 
0x000043, 0x00003E, 0x00001A, 0x00001B, 0x00001C, 0x00001D, 0x00001E, 0x00001F, 
0x000020, 0x000021, 0x000022, 0x000023, 0x000024, 0x00006F, 0x00006E, 0x00006D, 
0x000052, 0x00004B, 0x000004, 0x000042, 0x00003D, 0x00006C, 0x00006B, 0x00006A, 
0x000069, 0x000068, 0x000067, 0x000066, 0x000065, 0x000064, 0x000063, 0x000062, 
0x000061, 0x000060, 0x00005F, 0x000051, 0x00004A, 0x000005, 0x000041, 0x00003C, 
0x00005C, 0x00005B, 0x000053, 0x000048, 0x000041, 0x00005A, 0x000059, 0x000058, 
0x000057, 0x000052, 0x000051, 0x000050, 0x00004F, 0x000000, 0x000001, 0x000043, 
0x00004E, 0x00004D, 0x000002, 0x000003, 0x000004, 0x000040, 0x00003D, 0x000031, 
0x00002D, 0x000042, 0x00003F, 0x00003E, 0x00003C, 0x00003B, 0x00003A, 0x000030, 
0x00002E, 0x00002C, 0x00005E, 0x00005D, 0x000056, 0x000055, 0x000054, 0x00004C, 
0x00004B, 0x000047, 0x000039, 0x000035, 0x000011, 0x000012, 0x000013, 0x000014, 
0x000015, 0x000016, 0x000017, 0x000018, 0x000019, 0x000005, 0x000009, 0x00000D, 
0x000024, 0x000028, 0x00004A, 0x000046, 0x000038, 0x000034, 0x00001A, 0x00001B, 
0x00001C, 0x00001D, 0x000022, 0x000023, 0x00001E, 0x00001F, 0x000020, 0x000006, 
0x00000A, 0x00000E, 0x000025, 0x000029, 0x000049, 0x000045, 0x000037, 0x000033, 
0x000021, 0x00006F, 0x00006E, 0x00006D, 0x00006C, 0x00006B, 0x00006A, 0x000069, 
0x000068, 0x000007, 0x00000B, 0x00000F, 0x000026, 0x00002A, 0x000044, 0x000036, 
0x000032, 0x00002F, 0x000067, 0x000066, 0x000065, 0x000064, 0x000063, 0x000062, 
0x000061, 0x000060, 0x00005F, 0x000008, 0x00000C, 0x000010, 0x000027, 0x00002B, 
0x838005, 0xE1E008, 0x1000E2, 0x00B0C5, 0x862C31, 0x619E14, 0xF3A79D, 0x3CE9E6, 
0x9B429E, 0x74F3A7, 0x9D3CE0, 
0xA443A4, 0x000003, 0xB47BB4, 0x000003, 0xC25DC2, 0x000001, 0xE22DE2, 0x000001, 
0x582758, 0x000003, 0x720D72, 0x000001, 0xE51BE5, 0x000003, 0xF748F7, 0x000000, 
0x20469D, 0xA2B4F0, 0x00D86E, 0x00005C, 0x99FED2, 0x003C55, 0x506EDF, 0x089072, 
0x14B8F8, 0xE5E733, 0x057D23, 
0x000030, 0x000062, 0x00003F, 0x000001, 0x000024, 0x00005F, 0x00004E, 0x000066, 
0x00005E, 0x000049, 0x000000, 0x000040, 0x000019, 0x000051, 0x00004C, 0x00003B, 
0x00007C, 0x000017, 0x000068, 0x000064, 0x000065, 0x00002F, 0x000076, 0x000055, 
0x000012, 0x000038, 0x000060, 0x000056, 0x000036, 0x000002, 0x000050, 0x000022, 
0x00007F, 0x00000D, 0x000006, 0x000059, 0x000039, 0x000067, 0x00000C, 0x00004A, 
0x000037, 0x00006F, 0x00004B, 0x000026, 0x00006D, 0x000047, 0x000070, 0x00001D, 
0x00000B, 0x000058, 0x000057, 0x000013, 0x000003, 0x000044, 0x00006E, 0x00001A, 
0x000021, 0x00001F, 0x000008, 0x00002D, 0x000052, 0x00003A, 0x000028, 0x00006B, 
0x000020, 0x000005, 0x00006A, 0x00005C, 0x00003E, 0x000043, 0x00004D, 0x00006C, 
0x00007A, 0x000025, 0x00003C, 0x000042, 0x000079, 0x00002A, 0x000033, 0x00007E, 
0x000075, 0x000072, 0x000004, 0x00005A, 0x00002B, 0x000034, 0x000035, 0x000071, 
0x000078, 0x000048, 0x000010, 0x000031, 0x000007, 0x00004F, 0x000077, 0x00003D, 
0x000016, 0x000054, 0x000009, 0x000061, 0x00005B, 0x00000F, 0x000015, 0x000018, 
0x00002E, 0x000027, 0x00005D, 0x000069, 0x000041, 0x000046, 0x00007D, 0x000063, 
0x000011, 0x00007B, 
 /* 
   1240 empty words 
 */
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 /*
   org     y:$FF0A80     ; location of one_over_n table
 */
0x000000, 0x7FFFFF, 0x400000, 0x2AAAAB, 0x200000, 0x19999A, 0x155555, 0x124925, 
0x100000, 0x0E38E4, 0x0CCCCD, 0x0BA2E9, 0x0AAAAB, 0x09D89E, 0x092492, 0x088889, 
0x080000, 0x078788, 0x071C72, 0x06BCA2, 0x066666, 0x061862, 0x05D174, 0x0590B2, 
0x055555, 0x051EB8, 0x04EC4F, 0x04BDA1, 0x049249, 0x0469EE, 0x044444, 0x042108, 
0x040000, 0x03E0F8, 0x03C3C4, 0x03A83B, 0x038E39, 0x03759F, 0x035E51, 0x034835, 
0x033333, 0x031F38, 0x030C31, 0x02FA0C, 0x02E8BA, 0x02D82E, 0x02C859, 0x02B931, 
0x02AAAB, 0x029CBC, 0x028F5C, 0x028283, 0x027627, 0x026A44, 0x025ED1, 0x0253C8, 
0x024925, 0x023EE1, 0x0234F7, 0x022B64, 0x022222, 0x02192E, 0x021084, 0x020821, 
0x020000, 0x01F820, 0x01F07C, 0x01E913, 0x01E1E2, 0x01DAE6, 0x01D41D, 0x01CD85, 
0x01C71C, 0x01C0E0, 0x01BAD0, 0x01B4E8, 0x01AF28, 0x01A98F, 0x01A41A, 0x019EC9, 
0x01999A, 0x01948B, 0x018F9C, 0x018ACC, 0x018618, 0x018182, 0x017D06, 0x0178A5, 
0x01745D, 0x01702E, 0x016C17, 0x016817, 0x01642D, 0x016058, 0x015C99, 0x0158ED, 
0x015555, 0x0151D0, 0x014E5E, 0x014AFD, 0x0147AE, 0x014470, 0x014141, 0x013E23, 
0x013B14, 0x013814, 0x013522, 0x01323E, 0x012F68, 0x012CA0, 0x0129E4, 0x012735, 
0x012492, 0x0121FB, 0x011F70, 0x011CF0, 0x011A7C, 0x011812, 0x0115B2, 0x01135D, 
0x011111, 0x010ECF, 0x010C97, 0x010A68, 0x010842, 0x010625, 0x010410, 0x010204, 
0x000000, 0x03242B, 0x0647D9, 0x096A90, 0x0C8BD3, 0x0FAB27, 0x12C810, 0x15E214, 
0x18F8B8, 0x1C0B82, 0x1F19F9, 0x2223A5, 0x25280C, 0x2826B9, 0x2B1F35, 0x2E110A, 
0x30FBC5, 0x33DEF3, 0x36BA20, 0x398CDD, 0x3C56BA, 0x3F174A, 0x41CE1E, 0x447ACD, 
0x471CED, 0x49B415, 0x4C3FE0, 0x4EBFE9, 0x5133CD, 0x539B2B, 0x55F5A5, 0x5842DD, 
0x5A827A, 0x5CB421, 0x5ED77D, 0x60EC38, 0x62F202, 0x64E889, 0x66CF81, 0x68A69F, 
0x6A6D99, 0x6C2429, 0x6DCA0D, 0x6F5F03, 0x70E2CC, 0x72552D, 0x73B5EC, 0x7504D3, 
0x7641AF, 0x776C4F, 0x788484, 0x798A24, 0x7A7D05, 0x7B5D04, 0x7C29FC, 0x7CE3CF, 
0x7D8A5F, 0x7E1D94, 0x7E9D56, 0x7F0992, 0x7F6237, 0x7FA737, 0x7FD888, 0x7FF622, 
0x7FFFFF, 0x7FF622, 0x7FD888, 0x7FA737, 0x7F6237, 0x7F0992, 0x7E9D56, 0x7E1D94, 
0x7D8A5F, 0x7CE3CF, 0x7C29FC, 0x7B5D04, 0x7A7D05, 0x798A24, 0x788484, 0x776C4F, 
0x7641AF, 0x7504D3, 0x73B5EC, 0x72552D, 0x70E2CC, 0x6F5F03, 0x6DCA0D, 0x6C2429, 
0x6A6D99, 0x68A69F, 0x66CF81, 0x64E889, 0x62F202, 0x60EC38, 0x5ED77D, 0x5CB421, 
0x5A827A, 0x5842DD, 0x55F5A5, 0x539B2B, 0x5133CD, 0x4EBFE9, 0x4C3FE0, 0x49B415, 
0x471CED, 0x447ACD, 0x41CE1E, 0x3F174A, 0x3C56BA, 0x398CDD, 0x36BA20, 0x33DEF3, 
0x30FBC5, 0x2E110A, 0x2B1F35, 0x2826B9, 0x25280C, 0x2223A5, 0x1F19F9, 0x1C0B82, 
0x18F8B8, 0x15E214, 0x12C810, 0x0FAB27, 0x0C8BD3, 0x096A90, 0x0647D9, 0x03242B, 
0x000000, 0xFCDBD5, 0xF9B827, 0xF69570, 0xF3742D, 0xF054D9, 0xED37F0, 0xEA1DEC, 
0xE70748, 0xE3F47E, 0xE0E607, 0xDDDC5B, 0xDAD7F4, 0xD7D947, 0xD4E0CB, 0xD1EEF6, 
0xCF043B, 0xCC210D, 0xC945E0, 0xC67323, 0xC3A946, 0xC0E8B6, 0xBE31E2, 0xBB8533, 
0xB8E313, 0xB64BEB, 0xB3C020, 0xB14017, 0xAECC33, 0xAC64D5, 0xAA0A5B, 0xA7BD23, 
0xA57D86, 0xA34BDF, 0xA12883, 0x9F13C8, 0x9D0DFE, 0x9B1777, 0x99307F, 0x975961, 
0x959267, 0x93DBD7, 0x9235F3, 0x90A0FD, 0x8F1D34, 0x8DAAD3, 0x8C4A14, 0x8AFB2D, 
0x89BE51, 0x8893B1, 0x877B7C, 0x8675DC, 0x8582FB, 0x84A2FC, 0x83D604, 0x831C31, 
0x8275A1, 0x81E26C, 0x8162AA, 0x80F66E, 0x809DC9, 0x8058C9, 0x802778, 0x8009DE, 
0x800000, 0x8009DE, 0x802778, 0x8058C9, 0x809DC9, 0x80F66E, 0x8162AA, 0x81E26C, 
0x8275A1, 0x831C31, 0x83D604, 0x84A2FC, 0x8582FB, 0x8675DC, 0x877B7C, 0x8893B1, 
0x89BE51, 0x8AFB2D, 0x8C4A14, 0x8DAAD3, 0x8F1D34, 0x90A0FD, 0x9235F3, 0x93DBD7, 
0x959267, 0x975961, 0x99307F, 0x9B1777, 0x9D0DFE, 0x9F13C8, 0xA12883, 0xA34BDF, 
0xA57D86, 0xA7BD23, 0xAA0A5B, 0xAC64D5, 0xAECC33, 0xB14017, 0xB3C020, 0xB64BEB, 
0xB8E313, 0xBB8533, 0xBE31E2, 0xC0E8B6, 0xC3A946, 0xC67323, 0xC945E0, 0xCC210D, 
0xCF043B, 0xD1EEF6, 0xD4E0CB, 0xD7D947, 0xDAD7F4, 0xDDDC5B, 0xE0E607, 0xE3F47E, 
0xE70748, 0xEA1DEC, 0xED37F0, 0xF054D9, 0xF3742D, 0xF69570, 0xF9B827, 0xFCDBD5, 
};

#endif
static
struct dt_memory mem_56301[] =
{
    {A_TYPE (p, PG), A_ALLMEM, A_EXEC | DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (pe, PE), A_ALLMEM, A_EXEC | A_O_R_D_B_E, NULL, A_24W1},

    {A_TYPE (pi, PIC), A_MSIZE (0x400, 0x400), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0, 0x400), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0x400, 0x800), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PIC), A_MSIZE (0xc00, 0x400), A_EXEC | A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (pr, PR), A_MSIZE (0xff0000l, sizeof(bootrom56301)), A_EXEC | A_O_P_B, bootrom56301, A_24W1},
    {A_TYPE (x, XG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (xe, XE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0, DSP_XI_SIZE_56301), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0x800, 0x400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), 0x1000000l - DSP_XP_SIZE_56301, M24, 0l, DSP_MEMA_PERIPH | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xr, XR), A_MSIZE (0xff0000l, DSP_XR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (y, YG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (ye, YE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0, 0x800),DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0x800, 0x400), A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yr, YR), A_MSIZE (0xff0000l, DSP_YR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (l, LG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_48W2},
    {A_TYPE (le, LE), A_ALLMEM, DSP_MEMA_EXT | A_R_D_B, NULL, A_48W2},
    {A_TYPE (li, LI), 0l, DSP_YI_SIZE_56301 - 1l, 0, A_R_D_B, NULL, A_48W2},
#if !ADSx
    {A_TYPE (pf, PF), A_MSIZE (0, DSP_PF_SIZE_56301), A_O_R, NULL, A_24W1},
    {A_TYPE (pt, PT), A_MSIZE (0, DSP_PT_SIZE_56301), A_O_R, NULL, A_24W1},
#endif /* !ADSx */    
};

static
struct dt_memory mem_56302[] =
{
    {A_TYPE (p, PG), A_ALLMEM, A_EXEC | DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (pe, PE), A_ALLMEM, A_EXEC | A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0, 0x4C00), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (pb, PIC),0x4C00, 0x5000-1, 0x400, A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pa, PI), 0, 0x3ff, 0x400, A_EXEC | A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (pi, PI), 0x5000, 0x5400-1, 0, A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), 0x5400, 0x5c00-1, 0, A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pb, PIC),0x5c00,0x6000-1,0x400, A_EXEC | DSP_MEMA_MULT |A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (pr, PR), A_MSIZE (0xff0000l, sizeof(bootrom56302)), A_EXEC | A_O_P_B, bootrom56302, A_24W1},
    {A_TYPE (x, XG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (xe, XE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0, 0x1400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0x1400, 0x400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0x1800, 0x400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), 0x1000000l - DSP_XP_SIZE_56301, M24, 0l, DSP_MEMA_PERIPH | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xr, XR), A_MSIZE (0xff0000l, DSP_XR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (y, YG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (ye, YE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0, 0x1400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0x1400, 0x800), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yr, YR), A_MSIZE (0xff0000l, DSP_YR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (l, LG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_48W2},
    {A_TYPE (le, LE), A_ALLMEM, DSP_MEMA_EXT | A_R_D_B, NULL, A_48W2},
    {A_TYPE (li, LI), 0l,0x1c00-1, 0, A_R_D_B, NULL, A_48W2},
#if !ADSx
    {A_TYPE (pf, PF), A_MSIZE (0, DSP_PF_SIZE_56301), A_O_R, NULL, A_24W1},
    {A_TYPE (pt, PT), A_MSIZE (0, DSP_PT_SIZE_56301), A_O_R, NULL, A_24W1},
#endif /* !ADSx */    
};

static
struct dt_memory mem_56303[] =
{
    {A_TYPE (p, PG), A_ALLMEM, A_EXEC | DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (pe, PE), A_ALLMEM, A_EXEC | A_O_R_D_B_E, NULL, A_24W1},

    {A_TYPE (pi, PIC), A_MSIZE (0x400, 0x400), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0, 0x400), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0x400, 0x800), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PIC), A_MSIZE (0xc00, 0x400), A_EXEC | A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (pr, PR), A_MSIZE (0xff0000l, sizeof(bootrom56301)), A_EXEC | A_O_P_B, bootrom56301, A_24W1},
    {A_TYPE (x, XG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (xe, XE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0, DSP_XI_SIZE_56301), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), A_MSIZE (0x800, 0x400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xi, XI), 0x1000000l - DSP_XP_SIZE_56301, M24, 0l, DSP_MEMA_PERIPH | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (xr, XR), A_MSIZE (0xff0000l, DSP_XR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (y, YG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (ye, YE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0, 0x800),DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0x800, 0x400), A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yr, YR), A_MSIZE (0xff0000l, DSP_YR_SIZE_56301), A_R_P | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (l, LG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_48W2},
    {A_TYPE (le, LE), A_ALLMEM, DSP_MEMA_EXT | A_R_D_B, NULL, A_48W2},
    {A_TYPE (li, LI), 0l, DSP_YI_SIZE_56301 - 1l, 0, A_R_D_B, NULL, A_48W2},
#if !ADSx
    {A_TYPE (pf, PF), A_MSIZE (0, DSP_PF_SIZE_56301), A_O_R, NULL, A_24W1},
    {A_TYPE (pt, PT), A_MSIZE (0, DSP_PT_SIZE_56301), A_O_R, NULL, A_24W1},
#endif /* !ADSx */    
};

/* last update mem_56305 according to DSP56305 RevX.X spec */
static
struct dt_memory mem_56305[] =
{
    /*--------------------------- P memory --------------------------------*/

    {A_TYPE (p, PG), A_ALLMEM, A_EXEC | DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (pe, PE), A_ALLMEM, A_EXEC | A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (pb, PIC),A_MSIZE (0x1600, 0x400), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1} ,
    {A_TYPE (pb, PIC),A_MSIZE (0x1a00, 0x400), A_EXEC | A_O_R_D_B, NULL, A_24W1} ,
    {A_TYPE (pi, PI), A_MSIZE (0, 0x1600), A_EXEC | DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pi, PI), A_MSIZE (0x1600, 0x400), A_EXEC | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (pr, PR), A_MSIZE (0xff0000l, sizeof(bootrom56305)/4), A_EXEC |DSP_MEMA_MULT | A_O_P_B, bootrom56305, A_24W1},
    /* NEW 6K Internal program ROM */
    {A_TYPE (pr, PR), A_MSIZE (0xff0800l, 0x1800), A_EXEC | A_O_R_D_B, NULL, A_24W1 } ,

    /*--------------------------- X memory --------------------------------*/

    { A_TYPE (x, XG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1 } ,
    { A_TYPE (xe, XE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1 } ,
    { A_TYPE (xi, XI), A_MSIZE (0x000, 0xb00), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1 } ,
    { A_TYPE (xi, XI), A_MSIZE (0xb00, 0x400), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1 } ,
    { A_TYPE (xi, XI), 0x1000000l - DSP_XP_SIZE_56305, M24, 0l, DSP_MEMA_PERIPH | A_O_R_D_B, NULL, A_24W1 } ,

    /* New 6k internal data rom */
    { A_TYPE (xr, XR), A_MSIZE (0xff0000l, 0x1800), A_R_P | A_O_R_D_B, NULL, A_24W1 } ,
    { A_TYPE (xr, XR), A_MSIZE (0xff1800l, 0xd800), A_R_P | A_O_R_D_B, NULL, A_24W1 } ,

    /*--------------------------- Y memory --------------------------------*/

    {A_TYPE (y, YG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_24W1},
    {A_TYPE (ye, YE), A_ALLMEM, A_O_R_D_B_E, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0, DSP_YI_SIZE_56301), DSP_MEMA_MULT | A_O_R_D_B, NULL, A_24W1},
    {A_TYPE (yi, YI), A_MSIZE (0xffff80, 64), DSP_MEMA_PERIPH | A_O_R_D_B, NULL, A_24W1},

    {A_TYPE (yr, YR), A_MSIZE (0xff0000l, DSP_YR_SIZE_56305), A_R_P | A_O_R_D_B, sc3_yrom56305, A_24W1},

    /*--------------------------- L memory --------------------------------*/
    { A_TYPE (l, LG), A_ALLMEM, DSP_MEMA_BRK, NULL, A_48W2 } ,
    { A_TYPE (le, LE), A_ALLMEM, DSP_MEMA_EXT | A_R_D_B, NULL, A_48W2 } ,
    { A_TYPE (li, LI), 0l, DSP_YI_SIZE_56305 - 1l, 0, A_R_D_B, NULL, A_48W2 } ,
#if !ADSx
    { A_TYPE (pf, PF), A_MSIZE (0, DSP_PF_SIZE_56305), A_O_R, NULL, A_24W1 } ,
    { A_TYPE (pt, PT), A_MSIZE (0, DSP_PT_SIZE_56305), A_O_R, NULL, A_24W1 } ,
#endif /* !ADSx */
};

#undef	A_O_R
#undef	A_O_R_D
#undef	A_R_D_B
#undef	A_O_R_D_B
#undef	A_O_R_D_B_E
#undef	A_24W1
#undef	A_48W2
#undef	A_R_P
#undef	A_O_P_B
#undef	A_EXEC

#undef	A_MSIZE
#undef	A_TYPE
#undef	A_TYPE2
#undef	A_ALLMEM

/* BG not in RESET_IN_DATA, i.e. wake up with bus is granted */
#define		RESET_IN_DATA_56301	\
	    (Bpin(RESET)|Bpin(IRQx)|Bpin(BB))

#define		RESET_IN_FORCE_56301	\
	    (Bpin(RESET)|Bpin(IRQx)|Bpin(TA)|Bpin(BB)|Bpin(BG))

static
struct dev_xpdata pval_56301[] =
{
    {
	RESET_IN_DATA_56301,
	RESET_IN_FORCE_56301,
	MASTER_OUT_DATA_56301,
	MASTER_OUT_FORCE_56301,
	0l},			/* DSP_PORT_M */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_A */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_B */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_C */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_D */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_E */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_B1 */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_DATA */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_X */

};				/* pval_56301 */
static
struct dev_xpdata pval_563blm[] =
{
    {
	RESET_IN_DATA_56301,
	RESET_IN_FORCE_56301,
	MASTER_OUT_DATA_56301,
	MASTER_OUT_FORCE_56301,
	0l},			/* DSP_PORT_M */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_A */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_B */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_C */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_D */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_E */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_B1 */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_DATA */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_X */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_PMB */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_MCAB */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_GDB */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_MDAB */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_MDDBN */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_MDRQN */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_DFMREN */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_MIRQN */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_VAB */
    {0l, 0l, 0l, 0l, 0l},	/* DSP_PORT_PIVSSE */

};				/* pval_56301 */

static
struct dt_xpid xports_56301[] =
{
    {"ctrl", DSP_PORT_M, DSPT_POM_CTRL_563},
    {"porta", DSP_PORT_A, M24},
    {"portb0", DSP_PORT_B, 0xffffffffL},
    {"portb1", DSP_PORT_B1, 0x3ffffL},
    {"addr", DSP_PORT_A, M24},
    {"abus", DSP_PORT_A, M24},
    {"dbus", DSP_PORT_DATA, 0xffffffl},
    {"data", DSP_PORT_DATA, 0xffffffl},
    {"imc", DSP_PORT_M, DSPT_POM_IMC_563}
};				/* xports_56301 */

static
struct dt_xpid xports_56302[] =
{
    {"ctrl", DSP_PORT_M, DSPT_POM_CTRL_563},
    {"porta", DSP_PORT_A, M18},
    {"portb0", DSP_PORT_B, M16},
    {"addr", DSP_PORT_A, M18},
    {"abus", DSP_PORT_A, M18},
    {"dbus", DSP_PORT_DATA, 0x24},
    {"data", DSP_PORT_DATA, 0x24},
    {"imc", DSP_PORT_M, DSPT_POM_IMC_563}
};				/* xports_56302 */

static
struct dt_xpid xports_56305[] =
{
    { "ctrl", DSP_PORT_M, DSPT_POM_CTRL_563 } ,
    { "porta", DSP_PORT_A, M24 } ,
    { "portb0", DSP_PORT_B, 0xffffffffL } ,
    { "portb1", DSP_PORT_B1, 0x3ffffL } ,
    { "addr", DSP_PORT_A, M24 } ,
    { "abus", DSP_PORT_A, M24 } ,
    { "dbus", DSP_PORT_DATA, 0xffffffl } ,
    { "data", DSP_PORT_DATA, 0xffffffl } ,
    { "imc", DSP_PORT_M, DSPT_POM_IMC_563 }
};

static
struct dt_xpid xports_563blm[] =
{
    {"ctrl", DSP_PORT_M, DSPT_POM_CTRL_563},
    {"porta", DSP_PORT_A, M24},
    {"portb0", DSP_PORT_B, 0xffffffffL},
    {"portb1", DSP_PORT_B1, 0x3ffffL},
    {"addr", DSP_PORT_A, M24},
    {"abus", DSP_PORT_A, M24},
    {"dbus", DSP_PORT_DATA, 0xffffffl},
    {"data", DSP_PORT_DATA, 0xffffffl},
    {"imc", DSP_PORT_M, DSPT_POM_IMC_563},
    {"pmb"   , DSP_PORT_PMB   , 0xffffffl},
    {"mcab"  , DSP_PORT_MCAB  , 0xffffffl},
    {"gdb"   , DSP_PORT_GDB   , 0xffffffl},
    {"mdab"  , DSP_PORT_MDAB  , 0xffffffl},
    {"mddbn" , DSP_PORT_MDDBN , 0xffffffl},
    {"mdrqn" , DSP_PORT_MDRQN , 0xffffffl},
    {"dfmren", DSP_PORT_DFMREN, 0xffffffl},
    {"mirqn" , DSP_PORT_MIRQN , 0xffffffl},
    {"vab"   , DSP_PORT_VAB   , 0xffffffl},
    {"pivsse", DSP_PORT_PIVSSE, 0xffffffl}

};				/* xports_563blm */

extern
struct dt_mfunc dx_mfunc_563,dx_mfunc_56302,dx_mfunc_56305;

static 
unsigned long
alternate_magic_563[]={M56KMAGIC,0L};
public
struct dt_var dx_56301 =
{				/* one of these for each device type */
    "56301",			/* name for this device type */
    M563MAGIC,
    DSP56301,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_56301) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_56301,		/* pointer to array of peripherals */
    sizeof (mem_56301) / sizeof (struct dt_memory),	/* nummemory */
    mem_56301,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_563,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_56301) / sizeof (struct dev_xpdata),
    pval_56301,			/* initial input port values */
    (sizeof (xpin_56301)) / (sizeof (struct dt_xpin)),
    xpin_56301,			/* pointer to array of external pin name structures */
    (sizeof (xports_56301)) / (sizeof (struct dt_xpid)),
    xports_56301,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};
public
struct dt_var dx_56301b =
{				/* one of these for each device type */
    "56301b",			/* name for this device type */
    M563MAGIC,
    DSP56301B,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_56301b) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_56301b,		/* pointer to array of peripherals */
    sizeof (mem_56301) / sizeof (struct dt_memory),	/* nummemory */
    mem_56301,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_563,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_56301) / sizeof (struct dev_xpdata),
    pval_56301,			/* initial input port values */
    (sizeof (xpin_56301b)) / (sizeof (struct dt_xpin)),
    xpin_56301b,			/* pointer to array of external pin name structures */
    (sizeof (xports_56301)) / (sizeof (struct dt_xpid)),
    xports_56301,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};

public
struct dt_var dx_56302 =
{				/* one of these for each device type */
    "56302",			/* name for this device type */
    M563MAGIC,
    DSP56302,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_56302) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_56302,		/* pointer to array of peripherals */
    sizeof (mem_56302) / sizeof (struct dt_memory),	/* nummemory */
    mem_56302,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_56302,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_56301) / sizeof (struct dev_xpdata),
    pval_56301,			/* initial input port values */
    (sizeof (xpin_56302)) / (sizeof (struct dt_xpin)),
    xpin_56302,			/* pointer to array of external pin name structures */
    (sizeof (xports_56302)) / (sizeof (struct dt_xpid)),
    xports_56302,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};

public
struct dt_var dx_56303 =
{				/* one of these for each device type */
    "56303",			/* name for this device type */
    M563MAGIC,
    DSP56303,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_56302) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_56302,		/* pointer to array of peripherals */
    sizeof (mem_56303) / sizeof (struct dt_memory),	/* nummemory */
    mem_56303,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_563,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_56301) / sizeof (struct dev_xpdata),
    pval_56301,			/* initial input port values */
    (sizeof (xpin_56302)) / (sizeof (struct dt_xpin)),
    xpin_56302,			/* pointer to array of external pin name structures */
    (sizeof (xports_56302)) / (sizeof (struct dt_xpid)),
    xports_56302,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};

public
struct dt_var dx_56305 =
{				/* one of these for each device type */
    "56305",			/* name for this device type */
    M563MAGIC,
    DSP56301,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_56305) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_56305,		/* pointer to array of peripherals */
    sizeof (mem_56305) / sizeof (struct dt_memory),	/* nummemory */
    mem_56305,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_56305,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_56301) / sizeof (struct dev_xpdata),
    pval_56301,			/* initial input port values */
     (sizeof (xpin_56305)) / (sizeof (struct dt_xpin)),
    xpin_56305,			/* pointer to array of external pin name structures */
     (sizeof (xports_56305)) / (sizeof (struct dt_xpid)),
    xports_56305,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};

public
struct dt_var dx_563blm =
{				/* one of these for each device type */
    "56300",			/* name for this device type */
    M563MAGIC,
    DSP563BLM,
    DSP_WRD24 | DSP_ADDR24,
    0,				/* default startup operating mode */
    sizeof (dx_periph_563blm) / sizeof (struct dt_mperiph),	/* number of periphs */
    dx_periph_563blm,		/* pointer to array of peripherals */
    sizeof (mem_56301) / sizeof (struct dt_memory),	/* nummemory */
    mem_56301,			/* pointer to array of memory structures */
    "DSPMEM",			/* virtual memory file prefix */
    &dx_mfunc_563,		/* pointer to functions which operate on mem */
    sizeof (struct dt_gsig_563) / sizeof (unsigned long),
    sizeof (pval_563blm) / sizeof (struct dev_xpdata),
    pval_563blm,			/* initial input port values */
    (sizeof (xpin_563blm)) / (sizeof (struct dt_xpin)),
    xpin_563blm,			/* pointer to array of external pin name structures */
    (sizeof (xports_563blm)) / (sizeof (struct dt_xpid)),
    xports_563blm,		/* pointer to array of external ports name stuctures */
    alternate_magic_563
};


#if FULLSIM
static
int mem_dispfw563[] =
{				/* display field widths for memory types */
    15,				/* p?? */
    15,				/* x */
    15,				/* y */
    19,				/* l */
    15,				/* none */
    19,				/* laa */
    19,				/* lab */
    19,				/* lba */
    19,				/* lbb */
    19,				/* le */
    19,				/* li */
    15,				/* pa */
    15,				/* pb */
    15,				/* pe */
    15,				/* pi */
    15,				/* pr */
    15,				/* xa */
    15,				/* xb */
    15,				/* xe */
    15,				/* xi */
    15,				/* xr */
    15,				/* ya */
    15,				/* yb */
    15,				/* ye */
    15,				/* yi */
    15,				/* yr */
    15,				/* ic */
    15,				/* pf */
    15				/* emi */
};

static
char *mem_help563[] =
{				/* display field widths for memory types */
    "pe, pi or pr depending upon address and omr value.",	/* p?? */
    "xi, xe or xr depending upon address and omr values",	/* x */
    "yi, ye or yr depending upon address and omr values",	/* y */
    "li or le depending upon address and omr values",	/* l */
    NULL,			/* none */
    NULL,			/* laa */
    NULL,			/* lab */
    NULL,			/* lba */
    NULL,			/* lbb */
    "external long data memory",	/* le */
    "on-chip long data ram",	/* li */
    "pi or icache",	        /* pa */
    "pi or icache",	        /* pb */
    "external program memory",	/* pe */
    "internal program ram or program rom",	/* pi */
    "internal bootstrap rom or program rom",	/* pr */
    NULL,			/* xa */
    NULL,			/* xb */
    "external x data memory",	/* xe */
    "on-chip x data ram",	/* xi */
    "on-chip x data rom",	/* xr */
    NULL,			/* ya */
    NULL,			/* yb */
    "external y data memory",	/* ye */
    "internal y data ram",	/* yi */
    "internal y data rom",	/* yr */
    "pi or icache, depending upon address and sr values",	/* ic */
    "icache flags", /* pf */
    NULL,		/* emi */
    NULL,		/* e0 */
    NULL,	/* e1 */
    NULL,	/* e2 */
    NULL,	/* e3 */
    NULL,	/* e4 */
    NULL,	/* e5 */
    NULL,	/* e6 */
    NULL,	/* e7 */
    NULL,	/* e8 */
    NULL,	/* e9 */
    NULL,	/* e10 */
    NULL,		/* e11 */
    NULL,	/* e12 */
    NULL,		/* e13 */
    NULL,	/* e14 */
    NULL,	/* e15 */
    NULL,	/* e16 */
    NULL,	/* e17 */
    NULL,	/* e18 */
    NULL,		/* e19 */
    NULL,	/* e20 */
    NULL,		/* e21 */
    NULL,	/* e22 */
    NULL,	/* e23 */
    NULL,		/* e24 */
    NULL,	/* e25 */
    NULL,	/* e26 */
    NULL,	/* e27 */
    NULL,	/* e28 */
    NULL,	/* e29 */
    NULL,	/* e30 */
    NULL,	/* e31 */
    NULL,	/* e32 */
    NULL,	/* e33 */
};

extern
struct st_periph
 sx_core_563,
#if !ADSx    
 sx_csim_563,
#endif    
 sx_timer_563,
 sx_host_563,
 sx_host_56302,
 sx_ssi_563,
 sx_sci_563,
 sx_portb_563,
 sx_portb_56302,
 sx_portc_563,
 sx_prescaler_563,
 sx_timer_563,
 sx_count_563,
 sx_vcop_56305,
 sx_fcop_56305,
 sx_ccop_56305;


#if ADSx
extern struct st_periph sx_once_563;
extern struct st_periph sx_jtag_563;
#endif 

static
struct st_periph *sx_periph_56301[] =
{
    &sx_core_563,
#if !ADSx    
    &sx_csim_563,
#endif    
    &sx_host_563,
    &sx_ssi_563,
    &sx_ssi_563,
    &sx_sci_563,
    &sx_portb_563,
    &sx_portc_563,
    &sx_portc_563,
    &sx_portc_563,
    &sx_prescaler_563,
    &sx_timer_563,
    &sx_timer_563,
    &sx_timer_563,
#if ADSx
    &sx_once_563,
    &sx_jtag_563,
#endif    
    &sx_count_563,

};

static
struct st_periph *sx_periph_56302[] =
{
    &sx_core_563,
#if !ADSx    
    &sx_csim_563,
#endif    
    &sx_host_56302,
    &sx_ssi_563,
    &sx_ssi_563,
    &sx_sci_563,
    &sx_portb_56302,
    &sx_portc_563,
    &sx_portc_563,
    &sx_portc_563,
    &sx_prescaler_563,
    &sx_timer_563,
    &sx_timer_563,
    &sx_timer_563,
#if ADSx
    &sx_once_563,
    &sx_jtag_563,
#endif    
    &sx_count_563,

};

static
struct st_periph * sx_periph_56305[] =
{
    &sx_core_563,
#if !ADSx
    &sx_csim_563,
#endif
    &sx_host_563,
    &sx_ssi_563,
    &sx_ssi_563,
    &sx_sci_563,
    &sx_portb_563,
    &sx_portc_563,
    &sx_portc_563,
    &sx_portc_563,
    &sx_prescaler_563,
    &sx_timer_563,
    &sx_timer_563,
    &sx_timer_563,
#if ADSx
    &sx_once_563,
    &sx_jtag_563,
#endif
    &sx_vcop_56305,
    &sx_ccop_56305,
    &sx_fcop_56305,
    &sx_count_563,

};

static
struct st_periph *sx_periph_563blm[] =
{
    &sx_core_563,
#if !ADSx    
    &sx_csim_563,
#endif    
    &sx_count_563,

};

void dsptl_sasm_563 ();
int dspt_unasm_563 ();


#if !ADSx
extern struct st_prof st_prof_563;
#endif /* !ADSx */

extern struct st_help dsptl_hlp_56300;
extern struct st_help dsptl_hlp_56305;

public
struct st_var sx_56301 =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_56301,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56300,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};
public
struct st_var sx_56301b =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_56301,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56300,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};

public
struct st_var sx_56302 =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_56302,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56300,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};
struct st_var sx_56303 =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_56302,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56300,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};

public
struct st_var sx_56305 =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_56305,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56305,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};

public
struct st_var sx_563blm =
{				/* one of these for each device type */
    mem_dispfw563,		/* memory display field width */
    mem_help563,
    sx_periph_563blm,		/* pointer to array of peripherals */
    dsptl_sasm_563,		/* Simulator assembly functions */
    dspt_unasm_563,
    &dsptl_hlp_56300,
#if !ADSx    
    &st_prof_563
#else
    NULL
#endif /* !ADSx */    
};

#endif /* FULLSIM */
