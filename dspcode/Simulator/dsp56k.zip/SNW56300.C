/* $Id: snw56300.c,v 1.11 1995/06/08 22:20:25 jay Exp $ */
/* This example program creates a non-display version of the        */
/* simulator with three devices, loads the object file for a program */
/* named snwtest, executes 400 cycles on the three devices, then    */
/* saves the simulator state in the state file "snw56300.sim".       */
/* The state file can be loaded into a display version of the       */
/* simulator for examination of the results.                         */

#include "simcom.h"
#include "simdev.h"
#include "simusr.h"
#include "protocom.h"

void
main ()
{
    long i,
     numcycles = 400;
    int j,
     numdevices = 3;

    dsp_startup ();		/* Initialize simulator structures */
    for (j = 0; j < numdevices && dsp_new (j, "56301"); j++);	/* create the devices */
    numdevices = j;
    for (j = 0; j < numdevices; j++)
	dsp_ldmem (j, "snwtest.lod");	/* load program */

    for (i = 0; i < numcycles; i++)
    {				/* execute 400 clock cycles on each device */
	for (j = 0; j < numdevices; j++)
	    dsp_exec (j);
    }

    dsp_save ("snw56300.sim");	/* save the state of the devices */
}
