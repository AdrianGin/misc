/******************************************************************************
 *
 * FILE NAME     : $RCSfile: matdsp_api.h,v $
 * PROGRAMMER(S) : Ben Bongalon and Renato Sergi
 *
 * DESCRIPTION   : Header file for Matlab API functions
 *
 *
 ******************************************************************************
 *
 *  Copyright (C) 1999  Motorola Australia Pty. Ltd.
 *  All Rights Reserved
 *
 *  This is unpublished proprietary source code
 *  of Motorola Australia Pty. Ltd.
 *
 *  The copyright notice does not evidence any actual
 *  or intended publication of such source code.
 *
 * $Id: matdsp_api.h,v 1.2 2000/08/17 17:16:30 thartley Exp $
 * $Source: /src/tmw/matlab5/toolbox/motdsp/motdspmex/include/headers/56k/RCS/matdsp_api.h,v $
 *
 ******************************************************************************/

#ifndef MATDSP_API_H
#define MATDSP_API_H

#if defined(_HPUX_SOURCE) || defined(WIN32)
typedef unsigned long  ulong;          
#endif
  
                    
#if WIN32          
#undef n_name   
#undef N_BTMASK    
#undef N_TMASK
#undef N_BTSHFT
#undef N_TSHIFT
#undef REG_NONE   
#include <stdio.h>   
#include <stdlib.h>  
#include <assert.h>  
#include <string.h>  
#include <iostream.h>
#include <windows.h>
#endif 

#if UNIX
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/msg.h>
/* nasty workaround to remove definition of VMS as 0 in simcom.h, which
   them confuses pthread.h on HP into thinking it is being compiled on 
   a VAX. YUCK...
*/
#ifdef _HPUX_SOURCE 
#undef VMS
#endif
#include <pthread.h>
#endif

/* This CLAS simulator header file must be outside */
/* the 'extern "C"' block to avoid compiler errors */
#include "simcom.h"     

#ifdef __cplusplus
extern "C"	{
#endif

/* Header files for CLAS simulator data structure defs and function
   prototypes */
#include "simdev.h"
#include "simusr.h"
#include "protocom.h"

// Symbolic constants for the various data width supported by the
// StarCore DSP Architexture.
enum sc_data_widths {DWIDTH_DEF = 0};

/* General Definitions */
/* DSP device index for Matlab --> always use Device 0 !!! */
#define DSPM_DEVINDX			0

#define MAX_SYMBOL_LEN       	7  // ISS limitation
#define MAX_REGNAME_LEN      	32 // This is a guess, look up documentation
#define MAX_DEVNAME_LEN			5

#define BAD_SIZE -1 // Bad integer number.

/* Extensions to the CLAS simulator API functions (for Matlab) */
extern	int dspm_CheckExecute();
extern	int dspm_CheckMacroReady();
extern	int dspm_CheckCommandStatus();
extern	char *dspm_GetErrorMessage();

extern	int dspm_WriteMemBlkInt( enum memory_map mem_map, ulong mem_address,
                      int blksize, ulong *arrayPtr );

extern	int dspm_WriteMemBlkFrac( enum memory_map mem_map, ulong mem_address,
                      int blksize, double* arrayPtr );

extern	ulong* dspm_ReadMemBlkInt( enum memory_map mem_map, ulong mem_address, 
                      int blksize );

extern	double* dspm_ReadMemBlkFrac( enum memory_map mem_map, ulong mem_address,
                      int blksize );

extern	int dspm_GetSymbolCount();
extern	SYMENT* dspm_GetSymbolElement( int index );
extern 	int dspm_GetMemSpaceUsage(enum memory_map mem_space); 
extern   int dspm_GetProgramSpaceUsage(void);
extern   unsigned long *dspm_ReadReg(const char *reg_name);
extern   void dspm_init_profiler(char *cs);
extern   void dspm_UpdateProgramSize(int psize, int xsize, int ysize);
/* Conversion functions */

extern	ulong convert_double_to_fixed( double dval );
extern	ulong convert_double_to_fixed_8bit( double dval );
extern	double convert_fixed_to_double( ulong fixval );
extern	double convert_fixed_to_double_8bit( ulong fixval );

#ifdef __cplusplus
	}
#endif


#endif	/* MATDSP_API_H */


