/******************************************************************************
 *
 * FILE NAME     : $RCSfile: matsimm_api.h,v $
 * PROGRAMMER(S) : Ben Bongalon and Renato Sergi
 *
 * DESCRIPTION   : Header file for Matlab API functions
 *
 *
 ******************************************************************************
 *
 *  Copyright (C) 1999  Motorola Australia Pty. Ltd.
 *  All Rights Reserved
 *
 *  This is unpublished proprietary source code
 *  of Motorola Australia Pty. Ltd.
 * 
 *  The copyright notice does not evidence any actual
 *  or intended publication of such source code.
 *
 * $Id: matsimm_api.h,v 1.2 2000/08/17 17:16:30 thartley Exp $
 * $Source: /src/tmw/matlab5/toolbox/motdsp/motdspmex/include/headers/56k/RCS/matsimm_api.h,v $
 *
 ******************************************************************************/

#ifndef MATSIMM_API_H
#define MATSIMM_API_H

#include "matdsp_api.h"

#ifdef __cplusplus
extern "C"	{
#endif


/*---------------------------------------------- 
 | General Declarations and symbolic constants. |
 ----------------------------------------------*/

  /* Specify radix for decimal and hexidecimal numbers. */
#define BASE_10 10
#define BASE_16 16

#define MAX_DECODE_TOKEN_LEN 	3

FILE *fp_debug;

/* Symbolic radix types. i.e. either decimal or fractional  */
enum number_format {INT_TYPE = 0, FRAC_TYPE};

/* data types of Xfer = char, double, and unsigned long. */
enum xfer_type {CHAR_XFER = 0, DOUBLE_XFER, ULONG_XFER};

  /* Structure used to hold the data read from the pipe plus
     other useful information such as the data type and its
     size in words. */
struct _pBuffer
{
    enum xfer_type pType; /* data type. */ 
    int    pSize; /* size in words. */
    void * pData; /* actual data. */
};

// Maximum DSP Memory block 64K words. 
#define MAX_DSP_DATABLOCK      (64*1024)
#define MAX_DSP_PIPEXFER       (MAX_DSP_DATABLOCK*sizeof(double))


/* Declaration for IPC message queue data structures. */
#if UNIX
#define BUFSIZE 			1024
#define MSGQ_SEED 			'Z'
#define MSGQ_SIG_SEED 		'Y'
#define MSGQ_TYPE 			1L
#define MSGQ_TYPE_DEBUG 	2L
#define MSGQ_TYPE_EXIT  	3L
#define MSGQ_TYPE_MEXDONE	4L
#define MSGQ_TYPE_EVENT  	5L
#define MSGQ_CHAR_XFER  	6L
#define MSGQ_DOUBLE_XFER  	7L
#define MSGQ_ULONG_XFER  	8L
#define MSGQ_TYPE_SNAPSHOT  9L
#define MSGQ_TYPE_SNUDONE	10L

typedef struct {
	long msg_to; /* Placed in the queue for. */
	char buffer[BUFSIZE]; /* Actual message. */
} MESSAGE;
#endif

/*-------------------------------------------------------------------- 
 | Declare data structures and symbolic constants specific to Thread. |
 | WIN32: kernel threads.											  |	
 | UNIX:  POSIX PThreads	 										  |
 --------------------------------------------------------------------*/ 

  /* Exit code for thread - to confirm successful termination status of
     thread. */
#define THREAD_EXIT_CODE 250

#if WIN32
  extern int MOT_WIN9x; //for WIN 95/98
  extern int MOT_WINnt;
  HANDLE hInputThread; /* Handle to a thread object. */
  DWORD  InputThreadID; /* Thread ID number. */
  DWORD  InputMatlabData(LPVOID lpThreadParameter); /* Actual thread function. */
#endif

#if UNIX
	/* Thread Identifier */
	pthread_t InputThreadID;
	
	/* Thread routine. */
  	void *InputMatlabData(void *arg); /* Actual thread function. */
#endif



/* 
 * Declare data structures and symbolic constants specific to Pipes. 
 * WIN32: Named Pipes.
 * UNIX : Native Kernel unstreamed pipes.	
 */ 

  /* Stores the names for the pipe devices. */
#define MAX_LENGTH_PIPE_NAME 256
  char pipenameA[MAX_LENGTH_PIPE_NAME];
  char pipenameB[MAX_LENGTH_PIPE_NAME];

#if WIN32
  /* Pipe handle to a pipe used for transferring data from
     ISS process to Matlab/Simulink process. */
  extern HANDLE piperead; 
  HANDLE pipeIssToMatlab;
  /* Pipe handle to a pipe used for transferring data from
     Matlab/Simulink process to ISS process. */
  extern HANDLE pipewrite; 
  HANDLE pipeMatlabToIss;
  
  /* Number of data type supported for piep operations. */
#define NUM_RW_XFERS 		3   
#endif

#if UNIX
  	/* File descriptors for pipes */
  	extern int fds_Mat;
  	extern int fds_Iss;
	extern int thread_status;
#endif

/* 
 * Declare data structures and symbolic constants specific to 
 * IPC Synchronization events.
 * WIN32: Event Kernel objects.
 * UNIX : Message Queues.
 */ 
#if WIN32
  /* Handles to event objects. */
  HANDLE     hSimReadEv[NUM_RW_XFERS];
  HANDLE     hSimWriteEv[NUM_RW_XFERS];
  HANDLE     hRequestExitEvent;
  HANDLE       hMexDone;
  HANDLE     hIssReadCompleteEvent;
  HANDLE     hMatReadCompleteEvent;
  /* Specfiy number of general events. */
#define MAX_ISS_EVENT_HANDLES 5
  /* Handle to general events. */
  HANDLE     hSimEvent[MAX_ISS_EVENT_HANDLES];
  /* Indices of general events. */
  enum Iss_event_index {SIM_EXIT_EV=0, 
			SIM_SNAPSHOT_EV,
			SIM_CALLMATLAB_EV,
			SIM_DEBUG_EV,
			SIM_INIT_EV};
#endif
#if UNIX
	/* ID descriptor for message queue. */
  	extern int msgq_id;

	MESSAGE msg;
  	extern int msgq_sig_id;

	MESSAGE msg_sig;
#endif



/* Error Assertion macro plus prototypes. */
#ifdef WIN32
  /* Custom assertion function. */
#define SIMM_ASSERT(win32_func) if (!(win32_func)) \
        simm_AssertSystemError(#win32_func, __FILE__, __LINE__, GetLastError())
				
  /* Custom assertion function prototype. */
  void simm_AssertSystemError(LPSTR err_desc, 
			      LPSTR filename,
			      int lineno,
			      DWORD errnum);
#else
#define SIMM_ASSERT(unix_func) if (!(win32_func)) \
        simm_AssertSystemError(#unix_func, __FILE__, __LINE__, errno)
				
  /* Custom assertion function prototype. */
  void simm_AssertSystemError(char* err_desc, 
			      char* filename,
			      int lineno,
			      int errno);
#endif

  /* Function prototypes */
  void            simm_CreateEventObjects(void);
  void            simm_ConnectToPipe(void);
  void            debug_file_start(void);
  void            debug_file_exit(void);
  struct _pBuffer simm_ReadPipe(void);
  void            simm_Terminate(void);
  void            simm_print(struct _pBuffer pBuff);
  void            dspm_WriteReg(char *reg_name, unsigned long *reg_value);
  void            simm_WriteSymbolData(char* symbol_name, 
				       enum number_format num_format,
				       struct _pBuffer pBuffMem);
  int             simm_WritePipe(void *data_stream, int num_items, 
				 enum xfer_type x_type);
  enum memory_map simm_GetSymbolMap(char* symbol_name);
  unsigned long   simm_GetSymbolAddress(char* symbol_name);
  enum memory_map simm_ExtractMap(void);
  unsigned long   simm_ExtractItemAsSingleUlong(void);
  char*           simm_ExtractItemAsString(void);
  extern int      simm_ParseMatlabCmd(char *commandStr);
  extern void     simm_UpdateSnapshot(void);
  extern int      simm_SnapshotHandler(char *command_str);
  extern int      simm_CallMatlabHandler(char *command_str);
  extern void     simm_dumpSARP(void);
  unsigned long*  simm_ExtractItemAsVectorUlong(void);
  void            simm_WaitOnResultsTransfer(void);
  extern void     simm_SendAsString(char* a_string);
  enum memory_map simm_DecodeMap(char map_str);
  int             simm_DecodeRadixNumber( int radix, 
										  char* start_address,
										  char* end_address, 
										  unsigned long* start_pos,
										  unsigned long* block_size);
	void shift_manip(char *str, int rad);

#ifdef __cplusplus
}
#endif

#endif /* MATSIMM_API_H */


