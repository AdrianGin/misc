#include "simcom.h"
#include "simusr.h"
#include "protocom.h"

/* Simulator GUI main entry point */

int
main (int argc, char **argv)
{
    /* Let the gui take over */
    gui_startup (argc, argv, "56301");

    return (0);
}
