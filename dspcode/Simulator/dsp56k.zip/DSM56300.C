/* $Id: dsm56300.c,v 1.11 1995/06/08 22:19:05 jay Exp $ */
#include "simcom.h"
#include "simusr.h"
#include "protocom.h"
#include "proto563.h"



/* This sample program uses the disassembler function in the dsp_sim */
/* library to form a stand-alone disassembler command. */
void main (void)

{
    unsigned long ops[2];

    int numops;
    unsigned long srval,
     omrval;
    char strp[100];

    srval = omrval = 0L;
    do
    {
	ops[0] = ops[1] = 0l;		/* NOP instruction is default */
	(void) printf ("Enter hex opcodes (or return to exit):");
	(void) gets (strp);
	(void) sscanf (strp, "%lx %lx", &ops[0], &ops[1]);	/* command line argument */
	if (*strp)
	{
	    numops = dspt_unasm_563 (&ops[0], strp, srval, omrval, NULL);
	    (void) printf ("numops %d, decode=%s\n", numops, strp);
	}
    }
    while (*strp);
}
