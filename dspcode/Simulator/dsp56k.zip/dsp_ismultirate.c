/*
 * dsp_ismultirate.c 
 *
 * DSP Blockset helper function.
 *
 * Check if the block is multirate:
 * If any port has a different sample time,
 * then the block is multirate.
 *
 * Include this file to determine if block is multirate
 *
 * Copyright (c) 1995-1999 The MathWorks, Inc. All Rights Reserved.
 * $Revision: 1.3 $ $Date: 2000/08/17 17:16:38 $
 */

#if defined(MATLAB_MEX_FILE)

static boolean_T isInputMultiRate(SimStruct *S, int_T numIn)
{
    if (numIn < 1) return(false);
    {
        /* Compare all input ports */
        const real_T inTs_old = ssGetInputPortSampleTime(S, 0);
        int_T idx;

        for (idx = 1; idx < numIn; idx++) {
            const real_T inTs_new = ssGetInputPortSampleTime(S, idx);
            if (inTs_old != inTs_new) {
                return(true);
            }
        }
        return(false);
    }
}


static boolean_T isOutputMultiRate(SimStruct *S, int_T numOut)
{
    if (numOut < 1) return(false);
    {
        /* Compare all output ports */
        const real_T outTs_old = ssGetOutputPortSampleTime(S, 0);
        int_T idx;

        for (idx = 1; idx < numOut; idx++) {
            const real_T outTs_new = ssGetOutputPortSampleTime(S, idx);
            if (outTs_old != outTs_new) {
                return(true);
            }
        }
        return(false);
    }
}


static boolean_T isBlockMultiRate(
    SimStruct *S, 
    int_T numIn, 
    int_T numOut
)
{
    return((boolean_T)(isInputMultiRate(S,numIn)
           || isOutputMultiRate(S,numOut)
           || (ssGetInputPortSampleTime(S, 0) != ssGetOutputPortSampleTime(S, 0)) ));
}

static boolean_T isModelMultiTasking(SimStruct *S)
{
    return(boolean_T)(!ssIsVariableStepSolver(S) &&
           (ssGetSolverMode(S) == SOLVER_MODE_MULTITASKING)
          ); 

}
#endif

/* [EOF] dsp_ismultirate.c */
