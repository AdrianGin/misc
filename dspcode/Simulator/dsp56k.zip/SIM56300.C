/* $Id: sim56300.c,v 1.13 1996/07/03 14:43:52 jay Exp $ */

/* MODULE DESCRIPTION:                                               */
/*   This module contains the main entry point for the DSP56300      */
/* simulator SIM56300.                                               */

/* FUNCTIONS:                                                        */
/* main(argc,argv) - SIM56300, rev 4.4                               */

#include "simcom.h"
#include "simdev.h"
#include "simusr.h"
#include "protocom.h"
#include "proto563.h"
extern struct dev_const dv_const;
extern struct sev_const sv_const;

#if BLM
/* extern dsp_execp (int);      */
#endif

/* main simulator entry point */
int
main (int argc,
      char **argv)

{
    int i;
    struct sev_var *sv;
    struct dev_var *dv;
    char cmdstr[256];		/* Will hold command strings input from terminal */

#if MSDOS
    (void) _grow_handles (100);	/* attempt to increase file handles to 100 */
#endif
    dsp_startup ();		/* Initialize simulator windows and global structures */
    (void) dsp_new (0, "56301");
    simw_wscr (dv_const.revnum, 1);	/* Display the simulator version on device 0 window */
    /* Begin with execution of macros specified in command line */
    if (argc >= 2)
    {
	sim_docmd (0, argv[1]);	/* Execution of other macros <name>.cmd */
    }
#if macintosh
    simw_macstartup ();
#endif

    /* This is the main execution loop.  If the device is at a breakpoint, */
    /* the next command is requested from a macro file or from the terminal. */
    /* Commands that cause the device to begin executing will set the */
    /* "executing" flag in the hsp stat structure. */

    for (;;)
    {
	do
	{
	    /* get keyboard instructions until all devices are ready to go */
	    i = sv_const.viewdev;
	    sv = sv_const.sv[i];
	    if (sv && !sv->stat.executing);	/* stay until device is executing */
	    else
	    {
		for (i = 0; i < dv_const.maxdevices; i++)
		{		/* check all devices for break */
		    sv = sv_const.sv[i];
		    if (sv && !sv->stat.executing)
		    {
			sv_const.viewdev = sv_const.breakdev = i;
			simw_redo (i);
			break;
		    }
		}
	    }

	    if (i < dv_const.maxdevices)
	    {
		if (sv_const.in_macro)
		    sim_gmcmd (i, cmdstr);	/* get macro command */
		if (!sv_const.in_macro)
		    sim_gtcmd (i, cmdstr);	/* get terminal command */
		sim_docmd (i, cmdstr);
	    }
	}
	while (i < dv_const.maxdevices);

	for (i = 0; i < dv_const.maxdevices; i++)
	{
	    dv = dv_const.sv[i];
	    if (!dv || (dv->flg_stat & DSP_GOFF));	/* device not in use */
	    else
#if BLM
		dsp_execp (i);
#else
		dsp_exec (i);	/* execute until breakpoint is reached */
#endif
	}
    }
    return 0;
}				/* end of main */
